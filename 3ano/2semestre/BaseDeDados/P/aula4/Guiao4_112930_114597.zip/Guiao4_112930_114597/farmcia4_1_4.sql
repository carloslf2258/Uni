


use farmacia
go 

CREATE TABLE Farmaceutica (
    nRegNacional VARCHAR(20) PRIMARY KEY,
    nome VARCHAR(100),
    address VARCHAR(255),
    telefone VARCHAR(20)
);

CREATE TABLE Farmaco (
	formula VARCHAR (100)PRIMARY KEY,
    nome VARCHAR(100),
    Farm_nRegNacional VARCHAR(20)
);

CREATE TABLE Paciente (
    nUtente VARCHAR(20) PRIMARY KEY,
    nome VARCHAR(100),
    dataNasc DATE,
    address VARCHAR(255)
);

CREATE TABLE Medico (
    nSNS VARCHAR(20) PRIMARY KEY,
    nome VARCHAR(100),
    especialidade VARCHAR(100)
);

CREATE TABLE Farmacia (
    NIF VARCHAR(20) PRIMARY KEY,
    telefone VARCHAR(20),
    nome VARCHAR(100),
    address VARCHAR(255)
);

CREATE TABLE Prescricao (
    nPrescricao VARCHAR(20) PRIMARY KEY,
    data DATE,
    Paciente_NU VARCHAR(20),
    Medico_nSNS VARCHAR(20),
    Farmacia_NIF VARCHAR(20),
    dataProcessada DATE
);

CREATE TABLE constituidaPor (
    Formula_nome VARCHAR(100),
    nPrescricao VARCHAR(20),
    PRIMARY KEY (Formula_nome, nPrescricao)
);

-- Adicionando Foreign Keys
ALTER TABLE Farmaco
ADD CONSTRAINT fk_formula_farmaceutico FOREIGN KEY (Farm_nRegNacional) REFERENCES Farmaceutica(nRegNacional);

ALTER TABLE Prescricao 
ADD CONSTRAINT fk_prescricao_paciente FOREIGN KEY (Paciente_NU) REFERENCES Paciente(nUtente);

ALTER TABLE Prescricao 
ADD CONSTRAINT fk_prescricao_medico FOREIGN KEY (Medico_nSNS) REFERENCES Medico(nSNS);

ALTER TABLE Prescricao 
ADD CONSTRAINT fk_prescricao_farmacia FOREIGN KEY (Farmacia_NIF) REFERENCES Farmacia(NIF);

ALTER TABLE constituidaPor
ADD CONSTRAINT fk_prescricao_formula_prescricao FOREIGN KEY (nPrescricao) REFERENCES Prescricao(nPrescricao);

ALTER TABLE constituidaPor
ADD CONSTRAINT fk_prescricao_formula_formula FOREIGN KEY (Formula_nome) REFERENCES Farmaco(formula);


