--create database voos;
go
use voos;
go
--create schema voos;
go 



create table voos.flight(
	number int not null,
	airline varchar(50),
	weekdays varchar (30),
	primary key(number)
	);

create table voos.fare(
	flight_number int not null,
	code int not null,
	amount int not null,
	restrictions varchar(200)
	primary key (code,flight_number)
	);


create table voos.flight_leg(
	flight_number int not null,
	leg_no int not null,
	scheduled_dep_time varchar(200),
	scheduled_arr_time varchar(200),
	airport_code int not null,
	primary key(flight_number,leg_no)
	);

create table voos.leg_instance(
	flight_number int not null,
	leg_no int not null,
	date date,
	no_of_avail_seats int,
	airplane_id int not null,
	arr_time int not null,
	dep_time int not null,
	airport_code int not null,
	primary key(flight_number,leg_no,date)
	);


	
create table voos.airport(
    airport_code int not null,
    city varchar(50),
    state varchar(50),
    name varchar(100),
    primary key(airport_code)
);

create table voos.airplane(
    airplane_id int not null,
    total_no_of_seats int not null,
    airplane_type_name varchar(50) not null,
    primary key(airplane_id)
);

create table voos.airplane_type(
    type_name varchar(50) not null,
    company varchar(50),
    max_seats int not null,
    primary key(type_name)
);

create table voos.seat(
    flight_number int not null,
    leg_no int not null,
    date date not null,
    seat_no varchar(10) not null,
    customer_name varchar(100),
    cphone varchar(15),
    primary key(flight_number, leg_no, date, seat_no)
);


alter table voos.fare add constraint fk_fare_flight 
foreign key (flight_number) references voos.flight(number);

alter table voos.flight_leg add constraint fk_flight_leg_flight 
foreign key (flight_number) references voos.flight(number);

alter table voos.flight_leg add constraint fk_flight_leg_airport 
foreign key (airport_code) references voos.airport(airport_code);

alter table voos.leg_instance add constraint fk_leg_instance_flight 
foreign key (flight_number, leg_no) references voos.flight_leg(flight_number, leg_no);

alter table voos.leg_instance add constraint fk_leg_instance_airplane 
foreign key (airplane_id) references voos.airplane(airplane_id);

alter table voos.leg_instance add constraint fk_leg_instance_airport 
foreign key (airport_code) references voos.airport(airport_code);

alter table voos.airplane add constraint fk_airplane_type 
foreign key (airplane_type_name) references voos.airplane_type(type_name);

alter table voos.seat add constraint fk_seat_leg_instance 
foreign key (flight_number, leg_no, date) references voos.leg_instance(flight_number, leg_no, date);




	