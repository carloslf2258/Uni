use ArcadeDB;
go
-- Mostrar resumo das sess�es de jogo com informa��es de:
-- jogador, m�quina, pontua��o, e programa de fidelidade � �til para an�lise
CREATE VIEW arcade.vw_Sessoes_Resumo AS
SELECT 
    sj.ID_sessao,
    sj.Tempo_jogado,
    sj.Pontuacao_final,
    sj.Status_sessao,
    sj.Fichas,
    
    j.ID_jogador,
    j.Nome AS Nome_Jogador,
    j.Email,
    j.Telefone,
    j.Pontuacao_total,
    
    pf.Nome AS Programa_Fidelidade,
    pf.Tipo AS Tipo_Fidelidade,
    
    m.ID_maquina,
    m.Tipo AS Tipo_Maquina,
    m.Modelo,
    m.Fabricante

FROM arcade.Sessao_jogo sj
JOIN arcade.Jogador j ON sj.ID_jogador = j.ID_jogador
JOIN arcade.Programa_fidelidade pf ON j.ID_programa_fidelidade = pf.ID_programa_fidelidade
JOIN arcade.Maquina m ON sj.ID_maquina = m.ID_maquina;
