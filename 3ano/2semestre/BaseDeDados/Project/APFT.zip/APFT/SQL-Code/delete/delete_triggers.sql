USE ArcadeDB;
GO

-- Trigger que atualiza pontua��o total ap�s sess�o
DROP TRIGGER IF EXISTS arcade.trg_UpdatePontuacaoTotal;
GO

-- Trigger que atualiza fichas ap�s carregamento
DROP TRIGGER IF EXISTS arcade.trg_UpdateCardFichas;
GO

-- Trigger que decrementa fichas ao iniciar sess�o
DROP TRIGGER IF EXISTS arcade.trg_DecrementFichasAoIniciarSessao;
GO

-- Trigger que valida datas do evento
DROP TRIGGER IF EXISTS arcade.trg_ValidarDatasEvento;
GO

-- Trigger que valida e insere promo��es usufru�das
DROP TRIGGER IF EXISTS arcade.trg_ValidarUsufruiPromocao;
GO
