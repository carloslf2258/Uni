use ArcadeDB;
go

DROP VIEW IF EXISTS arcade.vw_Sessoes_Resumo;
