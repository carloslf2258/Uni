USE ArcadeDB;
GO

-- Remover �ndice da tabela Jogador
DROP INDEX IX_Jogador_IDPrograma ON arcade.Jogador;
GO

DROP INDEX IX_CardFichas_IDJogador ON arcade.Card_fichas;
GO

DROP INDEX IX_SessaoJogo_IDJogador ON arcade.Sessao_jogo;
GO

DROP INDEX IX_UsufruiPromocao_IDJogador ON arcade.Usufrui_promocao;
GO
