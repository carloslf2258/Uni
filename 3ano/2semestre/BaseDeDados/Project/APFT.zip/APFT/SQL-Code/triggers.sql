use ArcadeDB;
go

/*
Triggers
*/

-- Atualizar total de pontos ap�s nova sessao de jogo
CREATE TRIGGER trg_UpdatePontuacaoTotal
ON arcade.Sessao_jogo
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Atualiza a pontua��o total de cada jogador afetado
        UPDATE J
        SET J.Pontuacao_total = (
            SELECT SUM(ISNULL(SJ.Pontuacao_final, 0))
            FROM arcade.Sessao_jogo SJ
            WHERE SJ.ID_jogador = J.ID_jogador
        )
        FROM arcade.Jogador J
        INNER JOIN (
            SELECT DISTINCT ID_jogador
            FROM inserted
        ) AS I ON J.ID_jogador = I.ID_jogador;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();

        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
go

-- Aumenta numero de fichas ap�s Carrgamento
CREATE TRIGGER trg_UpdateCardFichas
ON arcade.Carregamento
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Primeiro, agregamos os cr�ditos por ID_card_fichas
        ;WITH CreditosPorCard AS (
            SELECT ID_card_fichas, SUM(Creditos) AS TotalCreditos
            FROM inserted
            GROUP BY ID_card_fichas
        )

        -- Atualizamos o saldo de fichas e a data do �ltimo carregamento
        UPDATE CF
        SET
            CF.Fichas_atuais = CF.Fichas_atuais + CP.TotalCreditos,
            CF.Data_ultimo_carregamento = CAST(GETDATE() AS DATE)
        FROM arcade.Card_fichas CF
        INNER JOIN CreditosPorCard CP ON CF.ID_card_fichas = CP.ID_card_fichas;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();

        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
go

-- Update creditos de Jogador ao utiliz�-las para jogar
CREATE TRIGGER trg_DecrementFichasAoIniciarSessao
ON arcade.Sessao_jogo
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Atualiza as fichas do Card_fichas diminuindo as fichas usadas na sess�o
        UPDATE CF
        SET CF.Fichas_atuais = CF.Fichas_atuais - I.Fichas
        FROM arcade.Card_fichas CF
        INNER JOIN inserted I ON CF.ID_jogador = I.ID_jogador;

        -- Opcional: verifica se as fichas n�o ficaram negativas (pode lan�ar erro)
        IF EXISTS (
            SELECT 1 FROM arcade.Card_fichas WHERE Fichas_atuais < 0
        )
        BEGIN
            RAISERROR('Fichas insuficientes no cart�o do jogador.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();

        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
go

-- assert(Data evento fim > Data evento in�cio) 
CREATE TRIGGER trg_ValidarDatasEvento
ON arcade.Evento
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1
        FROM inserted
        WHERE Data_fim < Data_inicio
    )
    BEGIN
        RAISERROR ('Data_fim deve ser maior ou igual a Data_inicio.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END
END;
GO

-- Valida e insere s� se data de Promo��o for v�lida e se o jogador j� n�o tiver a promo��o
CREATE TRIGGER trg_ValidarUsufruiPromocao
ON arcade.Usufrui_promocao
INSTEAD OF INSERT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO arcade.Usufrui_promocao (ID_jogador, ID_promocao)
    SELECT I.ID_jogador, I.ID_promocao
    FROM inserted I
    INNER JOIN arcade.Promocao P ON I.ID_promocao = P.ID_promocao
    LEFT JOIN arcade.Usufrui_promocao UP ON
        UP.ID_jogador = I.ID_jogador AND UP.ID_promocao = I.ID_promocao
    WHERE P.Data_fim >= CAST(GETDATE() AS DATE)
      AND UP.ID_jogador IS NULL;  -- N�o existe j� essa promo��o para o jogador
END;
go


