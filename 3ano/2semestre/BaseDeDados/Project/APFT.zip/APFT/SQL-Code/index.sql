use ArcadeDB;
go

-- Consultar todos os jogadores de um programa espec�fico.
CREATE INDEX IX_Jogador_IDPrograma
ON arcade.Jogador(ID_programa_fidelidade);

-- �ndices em tabelas que referenciam Jogador (d�o jeito)
CREATE INDEX IX_CardFichas_IDJogador
ON arcade.Card_fichas(ID_jogador);

CREATE INDEX IX_SessaoJogo_IDJogador
ON arcade.Sessao_jogo(ID_jogador);

CREATE INDEX IX_UsufruiPromocao_IDJogador
ON arcade.Usufrui_promocao(ID_jogador);

