﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Contacts
{
    public partial class Jogador: Form
    {
        string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";

        // ID do Jogador proveniente de Login
        public int IDJogador { get; set; }
        public Jogador()
        {
            InitializeComponent();
        }

        private void Jogador_Load(object sender, EventArgs e)
        {
            WelcomeJogador();
            Creditos_Load();
            PontuacaoTotal_Load();
        }

        private void WelcomeJogador()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand("SELECT arcade.udf_get_nome_jogador(@id)", conn))
                {
                    cmd.Parameters.AddWithValue("@id", IDJogador);

                    string nome = (string)cmd.ExecuteScalar();

                    // Texto formatado com nome a negrito
                    labelWelcome.Text = $"Welcome, {nome}!";
                }
            }
        }
        private void Creditos_Load()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT arcade.udf_get_credito_jogador(@id)", conn))
                {
                    cmd.Parameters.AddWithValue("@id", IDJogador);
                    object result = cmd.ExecuteScalar();
                    int creditos = (result != DBNull.Value) ? Convert.ToInt32(result) : 0;
                    labelCreditos.Text = $"Creditos: {creditos.ToString()}";
                }
            }
        }

        private void PontuacaoTotal_Load()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT arcade.udf_get_pontuacao_total(@id)", conn))
                {
                    cmd.Parameters.AddWithValue("@id", IDJogador);
                    object result = cmd.ExecuteScalar();
                    int pontos = (result != DBNull.Value) ? Convert.ToInt32(result) : 0;
                    labelPontuacaoTotal.Text = $"Pontuação Total: {pontos.ToString()}";
                }
            }
        }

        private void buttonPromos_Click(object sender, EventArgs e)
        {
            using (PromosAtivas form = new PromosAtivas())
            {
                form.ShowDialog(); 
            }
        }

        private void buttonEventos_Click_1(object sender, EventArgs e)
        {
            
            using (var form = new Eventos(readOnlyMode: true))
            {
                form.ShowDialog();
            }
        }
        private void buttonFidelidade_Click_1(object sender, EventArgs e)
        {
            // TO DO: Implementar read-only mode para Fidelidade assim como foi feito em Eventos
            using (Fidelidade form = new Fidelidade())
            {
                form.ShowDialog();
            }
        }

        private void buttonHistorico_Click(object sender, EventArgs e)
        {
            //Sessões de Jogos do Jogador
            HistoricoJogador form = new HistoricoJogador(IDJogador);
            form.ShowDialog();

        }


        private void TopJogadores_Click(object sender, EventArgs e)
        {
            // Top 5 Jogadores com mais pontos
            TopJogadores form = new TopJogadores(5);
            form.ShowDialog();
        }

    }
}
