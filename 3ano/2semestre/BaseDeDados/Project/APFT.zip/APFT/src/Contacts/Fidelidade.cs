﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Contacts
{
    public partial class Fidelidade : Form
    {
       
        string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";

        public Fidelidade()
        {
            InitializeComponent();
            this.Load += Fidelidade_Load;
        }

        private void Fidelidade_Load(object sender, EventArgs e)
        {
            CarregarProgramaFidelidade();
        }

        private void CarregarProgramaFidelidade()
        {
            string query = "SELECT * FROM arcade.udf_listar_fidelidades()";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        // Limpa a origem de dados anterior antes de recarregar
                        dataGridView1.DataSource = null;
                        dataGridView1.Rows.Clear();  // só necessário se AutoGenerateColumns for false
                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar programa de fidelidade: " + ex.Message);
            }
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
