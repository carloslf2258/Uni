﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Contacts
{
    public partial class TopJogadores: Form
    {
        public TopJogadores(int TopN)
        {
            InitializeComponent();
            CarregarTop(TopN);
        }

        private void CarregarTop(int TopN)
        {
            string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM arcade.udf_top_jogadores_pontuacao(@topN)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@topN", TopN);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable tabela = new DataTable();

                try
                {
                    conn.Open();
                    adapter.Fill(tabela);
                    dataGridView1.DataSource = tabela;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar Top: " + ex.Message);
                }
            }
        }

    }
}