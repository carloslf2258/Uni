﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Contacts
{
    public partial class HistoricoJogador : Form
    {
        public int IDJogador { get; set; }

        public HistoricoJogador(int idJogador)
        {
            InitializeComponent();
            IDJogador = idJogador;
            CarregarHistorico();
        }

        private void CarregarHistorico()
        {
            string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM arcade.udf_sessoes_por_jogador(@idJogador)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@idJogador", IDJogador);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable tabela = new DataTable();

                try
                {
                    conn.Open();
                    adapter.Fill(tabela);
                    dataGridView1.DataSource = tabela;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar histórico: " + ex.Message);
                }
            }
        }

    }
}
