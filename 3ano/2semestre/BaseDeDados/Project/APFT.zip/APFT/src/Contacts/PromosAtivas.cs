﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Contacts
{
    public partial class PromosAtivas : Form
    {
        private readonly string _connectionString =
            @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";

        public PromosAtivas()
        {
            InitializeComponent();
            this.Load += PromosAtivas_Load;
            // Associa o handler corretamente, usando o mesmo nome do método
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
        }

        private void PromosAtivas_Load(object sender, EventArgs e)
        {
            CarregarPromocoesAtivas();
        }

        private void CarregarPromocoesAtivas()
        {
            const string sql = @"
                SELECT 
                    ID_promocao,
                    Nome,
                    Tipo,
                    Data_inicio,
                    Data_fim,
                    Evento_associado
                FROM arcade.udf_listar_promocoes_ativas()
                ORDER BY Nome";

            var dt = new DataTable();
            using (var cn = new SqlConnection(_connectionString))
            using (var da = new SqlDataAdapter(sql, cn))
            {
                da.Fill(dt);
            }

            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("Não há promoções ativas.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                listBox1.DataSource = null;
                return;
            }

            listBox1.DataSource = dt;
            listBox1.DisplayMember = "Nome";
            listBox1.ValueMember = "ID_promocao";
        }

        // Handler com nome exato que o Designer espera
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem is DataRowView drv)
            {
                label1.Text = drv["ID_promocao"].ToString();
                label2.Text = drv["Nome"].ToString();
                label3.Text = drv["Tipo"].ToString();
                label4.Text = Convert.ToDateTime(drv["Data_inicio"]).ToString("dd/MM/yyyy");
                label5.Text = Convert.ToDateTime(drv["Data_fim"]).ToString("dd/MM/yyyy");
                label6.Text = drv["Evento_associado"].ToString();
            }
        }

        // Stubs para eventos de clique gerados pelo Designer
        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
    }
}
