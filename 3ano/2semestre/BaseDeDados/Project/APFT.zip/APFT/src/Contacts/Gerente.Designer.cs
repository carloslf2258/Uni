﻿namespace Contacts
{
    partial class Gerente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.buttonStats = new System.Windows.Forms.Button();
            this.JogadoresPremium = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(47, 94);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(141, 71);
            this.button1.TabIndex = 2;
            this.button1.Text = "Maquinas";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.buttonMaquinas_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(47, 232);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(145, 71);
            this.button2.TabIndex = 3;
            this.button2.Text = "Promos";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.buttonPromos_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(431, 232);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(132, 71);
            this.button3.TabIndex = 4;
            this.button3.Text = "Fidelidade";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.buttonFidelidade_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(239, 232);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(132, 71);
            this.button4.TabIndex = 5;
            this.button4.Text = "Eventos";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.buttonEventos_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(239, 94);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(132, 71);
            this.button5.TabIndex = 6;
            this.button5.Text = "Funcionarios";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.buttonFuncionarios_Click);
            // 
            // buttonStats
            // 
            this.buttonStats.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonStats.Location = new System.Drawing.Point(579, 350);
            this.buttonStats.Margin = new System.Windows.Forms.Padding(4);
            this.buttonStats.Name = "buttonStats";
            this.buttonStats.Size = new System.Drawing.Size(117, 57);
            this.buttonStats.TabIndex = 7;
            this.buttonStats.Text = "Estadísticas";
            this.buttonStats.UseVisualStyleBackColor = true;
            this.buttonStats.Click += new System.EventHandler(this.buttonStats_Click);
            // 
            // JogadoresPremium
            // 
            this.JogadoresPremium.Location = new System.Drawing.Point(556, 80);
            this.JogadoresPremium.Margin = new System.Windows.Forms.Padding(4);
            this.JogadoresPremium.Name = "JogadoresPremium";
            this.JogadoresPremium.Size = new System.Drawing.Size(140, 85);
            this.JogadoresPremium.TabIndex = 10;
            this.JogadoresPremium.Text = "Top 5 Jogadores (premium)";
            this.JogadoresPremium.UseVisualStyleBackColor = true;
            this.JogadoresPremium.Click += new System.EventHandler(this.JogadoresPremium_Click);
            // 
            // Gerente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(709, 429);
            this.Controls.Add(this.JogadoresPremium);
            this.Controls.Add(this.buttonStats);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Gerente";
            this.Text = "Gerente";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button buttonStats;
        private System.Windows.Forms.Button JogadoresPremium;
    }
}