﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Contacts
{
    public partial class Promos : Form
    {
        private readonly string _connectionString =
            @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";

        public Promos()
        {
            InitializeComponent();
            this.Load += Promos_Load;
            // wire o SelectedIndexChanged
            this.listBox1.SelectedIndexChanged += ListBox1_SelectedIndexChanged;
        }

        private void Promos_Load(object sender, EventArgs e)
        {
            CarregarPromocoes();
            foreach (var tb in new[]{ textBox1, textBox2, textBox3, textBox6 })
                tb.Visible = false;
            dataIni.Visible = false;
            datafim.Visible = false;
            OK.Visible = false; // Esconde o botão OK inicialmente
        }

        private void CarregarPromocoes()
        {
            const string sql = @"
            SELECT 
                ID_promocao,
                Nome,
                Tipo,
                Data_inicio,
                Data_fim,
                ID_evento
            FROM arcade.udf_listar_promocoes()
            ORDER BY Nome";

            try
            {
                var dt = new DataTable();
                using (var cn = new SqlConnection(_connectionString))
                using (var da = new SqlDataAdapter(sql, cn))
                    da.Fill(dt);

                listBox1.DataSource = dt;
                listBox1.DisplayMember = "Nome";
                listBox1.ValueMember = "ID_promocao";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar promoções: "
                                + ex.Message, "Erro",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem is DataRowView drv)
            {
                label1.Text = drv["ID_promocao"].ToString();
                label2.Text = drv["Nome"].ToString();
                label3.Text = drv["Tipo"].ToString();

                // formata datas
                if (DateTime.TryParse(drv["Data_inicio"].ToString(), out DateTime di))
                    label4.Text = di.ToString("dd/MM/yyyy");
                else
                    label4.Text = drv["Data_inicio"].ToString();

                if (DateTime.TryParse(drv["Data_fim"].ToString(), out DateTime df))
                    label5.Text = df.ToString("dd/MM/yyyy");
                else
                    label5.Text = drv["Data_fim"].ToString();

                label6.Text = drv["ID_evento"].ToString();
            }
        }

        private void Editar_Click(object sender, EventArgs e)
        {
            textBox1.Text = label1.Text;
            textBox2.Text = label2.Text;
            textBox3.Text = label3.Text;
            textBox6.Text = label6.Text;

            // 2) Esconda as Labels
            label1.Visible = true;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;

            // 3) Mostre as TextBox
            textBox1.Visible = false;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox6.Visible = true;
            dataIni.Visible = true;
            datafim.Visible = true;
            // 4) (Opcional) troque o Editar por um botão Salvar
            Editar.Visible = false;
            OK.Visible = true;
        }

        private void OK_Click(object sender, EventArgs e)
        {
            int idPromo = int.Parse(textBox1.Text);
            string nome = textBox2.Text;
            string tipo = textBox3.Text;
            DateTime di = dataIni.Value.Date;
            DateTime df = datafim.Value.Date;
            int idEvento = int.Parse(textBox6.Text);

            // 1) Atualiza no banco via SP
            using (var cn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand("arcade.sp_atualizar_promocao", cn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID_promocao", idPromo);
                cmd.Parameters.AddWithValue("@Nome", nome);
                cmd.Parameters.AddWithValue("@Tipo", tipo);
                cmd.Parameters.AddWithValue("@Data_inicio", di);
                cmd.Parameters.AddWithValue("@Data_fim", df);
                cmd.Parameters.AddWithValue("@ID_evento", idEvento);

                cn.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Promoção atualizada com sucesso!", "OK",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);

            // 2) Atualiza as labels para refletir o que ficou no banco
            label1.Text = idPromo.ToString();
            label2.Text = nome;
            label3.Text = tipo;
            label4.Text = di.ToString("dd/MM/yyyy");
            label5.Text = df.ToString("dd/MM/yyyy");
            label6.Text = idEvento.ToString();

            // 3) Sai do modo edição: mostra labels, esconde textboxes e datepickers
            label1.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            label6.Visible = true;

            textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox6.Visible = false;

            dataIni.Visible = false;
            datafim.Visible = false;

            // 4) Restaura os botões
            OK.Visible = false;
            Editar.Visible = true;

            // 5) (Opcional) Recarrega a lista para manter o datasource atualizado
            CarregarPromocoes();
        }

    }
}
