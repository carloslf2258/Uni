﻿namespace Contacts
{
    partial class Jogador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelWelcome = new System.Windows.Forms.Label();
            this.labelCreditos = new System.Windows.Forms.Label();
            this.labelPontuacaoTotal = new System.Windows.Forms.Label();
            this.buttonEventos = new System.Windows.Forms.Button();
            this.buttonFidelidade = new System.Windows.Forms.Button();
            this.buttonPromos = new System.Windows.Forms.Button();
            this.TopJogadores = new System.Windows.Forms.Button();
            this.buttonHistorico = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelWelcome
            // 
            this.labelWelcome.AutoSize = true;
            this.labelWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWelcome.Location = new System.Drawing.Point(34, 9);
            this.labelWelcome.Name = "labelWelcome";
            this.labelWelcome.Size = new System.Drawing.Size(150, 26);
            this.labelWelcome.TabIndex = 0;
            this.labelWelcome.Text = "labelWelcome";
            // 
            // labelCreditos
            // 
            this.labelCreditos.AutoSize = true;
            this.labelCreditos.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCreditos.Location = new System.Drawing.Point(35, 66);
            this.labelCreditos.Name = "labelCreditos";
            this.labelCreditos.Size = new System.Drawing.Size(119, 24);
            this.labelCreditos.TabIndex = 1;
            this.labelCreditos.Text = "labelCreditos";
            // 
            // labelPontuacaoTotal
            // 
            this.labelPontuacaoTotal.AutoSize = true;
            this.labelPontuacaoTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPontuacaoTotal.Location = new System.Drawing.Point(35, 99);
            this.labelPontuacaoTotal.Name = "labelPontuacaoTotal";
            this.labelPontuacaoTotal.Size = new System.Drawing.Size(181, 24);
            this.labelPontuacaoTotal.TabIndex = 2;
            this.labelPontuacaoTotal.Text = "labelPontuacaoTotal";
            // 
            // buttonEventos
            // 
            this.buttonEventos.Location = new System.Drawing.Point(236, 265);
            this.buttonEventos.Margin = new System.Windows.Forms.Padding(4);
            this.buttonEventos.Name = "buttonEventos";
            this.buttonEventos.Size = new System.Drawing.Size(132, 71);
            this.buttonEventos.TabIndex = 8;
            this.buttonEventos.Text = "Eventos";
            this.buttonEventos.UseVisualStyleBackColor = true;
            this.buttonEventos.Click += new System.EventHandler(this.buttonEventos_Click_1);
            // 
            // buttonFidelidade
            // 
            this.buttonFidelidade.Location = new System.Drawing.Point(434, 265);
            this.buttonFidelidade.Margin = new System.Windows.Forms.Padding(4);
            this.buttonFidelidade.Name = "buttonFidelidade";
            this.buttonFidelidade.Size = new System.Drawing.Size(132, 71);
            this.buttonFidelidade.TabIndex = 7;
            this.buttonFidelidade.Text = "Fidelidade";
            this.buttonFidelidade.UseVisualStyleBackColor = true;
            this.buttonFidelidade.Click += new System.EventHandler(this.buttonFidelidade_Click_1);
            // 
            // buttonPromos
            // 
            this.buttonPromos.Location = new System.Drawing.Point(38, 265);
            this.buttonPromos.Margin = new System.Windows.Forms.Padding(4);
            this.buttonPromos.Name = "buttonPromos";
            this.buttonPromos.Size = new System.Drawing.Size(132, 71);
            this.buttonPromos.TabIndex = 6;
            this.buttonPromos.Text = "Promos";
            this.buttonPromos.UseVisualStyleBackColor = true;
            this.buttonPromos.Click += new System.EventHandler(this.buttonPromos_Click);
            // 
            // TopJogadores
            // 
            this.TopJogadores.Location = new System.Drawing.Point(236, 159);
            this.TopJogadores.Margin = new System.Windows.Forms.Padding(4);
            this.TopJogadores.Name = "TopJogadores";
            this.TopJogadores.Size = new System.Drawing.Size(132, 66);
            this.TopJogadores.TabIndex = 9;
            this.TopJogadores.Text = "Top Jogadores (Pontos)";
            this.TopJogadores.UseVisualStyleBackColor = true;
            this.TopJogadores.Click += new System.EventHandler(this.TopJogadores_Click);
            // 
            // buttonHistorico
            // 
            this.buttonHistorico.Location = new System.Drawing.Point(38, 159);
            this.buttonHistorico.Margin = new System.Windows.Forms.Padding(4);
            this.buttonHistorico.Name = "buttonHistorico";
            this.buttonHistorico.Size = new System.Drawing.Size(132, 66);
            this.buttonHistorico.TabIndex = 10;
            this.buttonHistorico.Text = "Histórico";
            this.buttonHistorico.UseVisualStyleBackColor = true;
            this.buttonHistorico.Click += new System.EventHandler(this.buttonHistorico_Click);
            // 
            // Jogador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(635, 379);
            this.Controls.Add(this.buttonHistorico);
            this.Controls.Add(this.TopJogadores);
            this.Controls.Add(this.buttonEventos);
            this.Controls.Add(this.buttonFidelidade);
            this.Controls.Add(this.buttonPromos);
            this.Controls.Add(this.labelPontuacaoTotal);
            this.Controls.Add(this.labelCreditos);
            this.Controls.Add(this.labelWelcome);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Jogador";
            this.Text = "Jogador";
            this.Load += new System.EventHandler(this.Jogador_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelWelcome;
        private System.Windows.Forms.Label labelCreditos;
        private System.Windows.Forms.Label labelPontuacaoTotal;
        private System.Windows.Forms.Button buttonEventos;
        private System.Windows.Forms.Button buttonFidelidade;
        private System.Windows.Forms.Button buttonPromos;
        private System.Windows.Forms.Button TopJogadores;
        private System.Windows.Forms.Button buttonHistorico;
    }
}