﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Contacts
{
    public partial class Eventos : Form
    {
        string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";

        private readonly bool _readOnlyMode;

        // Construtor padrão (usado pelo Gerente)
        public Eventos() : this(readOnlyMode: false) { }

        // Construtor para o modo só-leitura (usado pelo Jogador)
        public Eventos(bool readOnlyMode)
        {
            InitializeComponent();
            _readOnlyMode = readOnlyMode;
        }

        private void Eventos_Load(object sender, EventArgs e)
        {
              
            textBoxID.Visible = textBoxNome.Visible = false;
            textBoxData_I.Visible = textBoxData_F.Visible = false;
            textBoxCapaciade.Visible = textBoxStatus.Visible = false;
            textBoxFuncionario.Visible = false;
            OK.Visible = false;
            OK2.Visible = false;
            dtpDataInit.Visible = dtpDataFim.Visible = false;
            OK.Visible = OK2.Visible = false;
            string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";

            string sql = "SELECT * FROM arcade.udf_listar_eventos()";

            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
            {
                cn.Open();
                da.Fill(dt);
            }

            listBox1.DataSource = dt;
            listBox1.DisplayMember = "Nome";         // o que aparece para o usuário
            listBox1.ValueMember = "ID_evento";    // o valor "interno" de cada item
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (listBox1.SelectedItem is DataRowView drv)
            {
                label1.Text = drv["ID_evento"].ToString();
                label2.Text = drv["Nome"].ToString();

                if (DateTime.TryParse(drv["Data_inicio"].ToString(), out DateTime dtInicio))
                    label3.Text = dtInicio.ToString("dd/MM/yyyy");
                else
                    label3.Text = drv["Data_inicio"].ToString();

                if (DateTime.TryParse(drv["Data_fim"].ToString(), out DateTime dtFim))
                    label4.Text = dtFim.ToString("dd/MM/yyyy");
                else
                    label4.Text = drv["Data_fim"].ToString();

                label5.Text = drv["Capacidade"].ToString();
                label6.Text = drv["Status"].ToString();
                label7.Text = drv["Responsavel"].ToString();
            }
            if (_readOnlyMode)
            {
                AjustarParaLeitura();
            }
        }
        private void AjustarParaLeitura()
        {
            Editar.Visible = false;
            Adicionar.Visible = false;
            OK.Visible = false;
            OK2.Visible = false;

            textBoxID.Visible = false;
            textBoxNome.Visible = false;
            dtpDataInit.Visible = false;
            dtpDataFim.Visible = false;
            textBoxCapaciade.Visible = false;
            textBoxStatus.Visible = false;
            textBoxFuncionario.Visible = false;

        }

        private void Editar_Click(object sender, EventArgs e)
        {
            // 1) Copia o texto das labels para as textboxes
            OK2.Visible = false;
            textBoxID.Text = label1.Text;
            textBoxNome.Text = label2.Text;
            textBoxData_I.Text = label3.Text;
            textBoxData_F.Text = label4.Text;
            textBoxCapaciade.Text = label5.Text;
            textBoxStatus.Text = label6.Text;
            textBoxFuncionario.Text = label7.Text;

            // 2) Esconde as labels
            label1.Visible = true;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;

            // 3) Mostra as textboxes
            textBoxID.Visible = false;
            textBoxNome.Visible = true;
            textBoxData_I.Visible = false;
            textBoxData_F.Visible = false;
            textBoxCapaciade.Visible = true;
            textBoxStatus.Visible = true;
            textBoxFuncionario.Visible = true;
            OK.Visible = true;
            dtpDataInit.Visible = dtpDataFim.Visible = true;
            Editar.Visible = false;


        }

        private void OK_Click(object sender, EventArgs e)
        {
            // 1) Lê e converte os valores das TextBoxes
            int idEvento = int.Parse(textBoxID.Text);
            string nome = textBoxNome.Text;
            DateTime dataI = dtpDataInit.Value.Date;
            DateTime dataF = dtpDataFim.Value.Date;
            int capacidade = int.Parse(textBoxCapaciade.Text);
            string status = textBoxStatus.Text;
            string respNome = textBoxFuncionario.Text;
            int idFuncionario;

            using (var cn = new SqlConnection(connectionString))
            {
                cn.Open();

                // 3) (Opcional) Obtém o ID do funcionário pelo nome
                using (var cmdFunc = new SqlCommand(
                    "SELECT ID_funcionario FROM arcade.Funcionario WHERE Nome = @Nome", cn))
                {
                    cmdFunc.Parameters.AddWithValue("@Nome", respNome);
                    object result = cmdFunc.ExecuteScalar();
                    if (result == null)
                    {
                        MessageBox.Show("Funcionário não encontrado!", "Erro",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    idFuncionario = (int)result;
                }

                // Stored procedure de UPDATE
                using (var cmdUpd = new SqlCommand("arcade.sp_atualizar_evento", cn))
                {
                    cmdUpd.CommandType = CommandType.StoredProcedure;
                    cmdUpd.Parameters.AddWithValue("@ID_evento", idEvento);
                    cmdUpd.Parameters.AddWithValue("@Nome", nome);
                    cmdUpd.Parameters.AddWithValue("@Data_inicio", dataI);
                    cmdUpd.Parameters.AddWithValue("@Data_fim", dataF);
                    cmdUpd.Parameters.AddWithValue("@Capacidade", capacidade);
                    cmdUpd.Parameters.AddWithValue("@Status", status);
                    cmdUpd.Parameters.AddWithValue("@ID_funcionario", idFuncionario);

                    cmdUpd.ExecuteNonQuery();
                }
            }

            // 5) Atualiza as labels na interface e volta ao modo somente-leitura
            label1.Text = textBoxID.Text;
            label2.Text = textBoxNome.Text;
            label3.Text = dataI.ToString("dd/MM/yyyy");
            label4.Text = dataF.ToString("dd/MM/yyyy");
            label5.Text = textBoxCapaciade.Text;
            label6.Text = textBoxStatus.Text;
            label7.Text = textBoxFuncionario.Text;

            dtpDataInit.Visible = dtpDataFim.Visible = false;

            foreach (var lbl in new[] { label1, label2, label3, label4, label5, label6, label7 })
                lbl.Visible = true;
            foreach (var tb in new[]{ textBoxID,textBoxNome,textBoxData_I,textBoxData_F,
                              textBoxCapaciade,textBoxStatus,textBoxFuncionario })
                tb.Visible = false;

            OK.Visible = false;
            Editar.Visible = true;

            MessageBox.Show("Evento atualizado com sucesso!", "OK",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Adicionar_Click(object sender, EventArgs e)
        {
            textBoxID.Text = "";
            textBoxNome.Text = "";
            textBoxCapaciade.Text = "";
            textBoxStatus.Text = "";
            textBoxFuncionario.Text = "";

            foreach (var lbl in new[] { label1, label2, label3, label4, label5, label6, label7 })
                lbl.Visible = false;

            foreach (var tb in new[]{ textBoxID, textBoxNome, 
                              textBoxCapaciade, textBoxStatus, textBoxFuncionario })
            {
                tb.Visible = true;
                tb.Enabled = true;    // caso queira desabilitar o ID, basta fazer tb.Enabled = false para textBoxID
            }

            dtpDataInit.Value = DateTime.Today;
            dtpDataFim.Value = DateTime.Today;
            dtpDataInit.Visible = dtpDataFim.Visible = true;

            OK2.Visible = true;
            Editar.Visible = false;
            Adicionar.Visible = false;
        }

        private void OK2_Click(object sender, EventArgs e)
        {
            // 1) Lê e converte os valores das TextBoxes
            int ID_funcionario = int.Parse(textBoxID.Text);

            string nome = textBoxNome.Text;
            DateTime dataI = dtpDataInit.Value.Date;
            DateTime dataF = dtpDataFim.Value.Date;
            int capacidade = int.Parse(textBoxCapaciade.Text);
            string status = textBoxStatus.Text;
            int idFuncionario = int.Parse(textBoxFuncionario.Text);

            // 2) Busca o ID do funcionário pelo nome (ou adapte se usar ComboBox já com IDs)
            using (var cn = new SqlConnection(connectionString))
            {
                cn.Open();

                // 3) Chama a stored procedure de INSERT
                using (var cmdIns = new SqlCommand("arcade.sp_add_evento", cn))
                {
                    cmdIns.CommandType = CommandType.StoredProcedure;

                    cmdIns.Parameters.AddWithValue("@ID_evento", ID_funcionario);
                    cmdIns.Parameters.AddWithValue("@Nome", nome);
                    cmdIns.Parameters.AddWithValue("@Data_inicio", dataI);
                    cmdIns.Parameters.AddWithValue("@Data_fim", dataF);
                    cmdIns.Parameters.AddWithValue("@Capacidade", capacidade);
                    cmdIns.Parameters.AddWithValue("@Status", status);
                    cmdIns.Parameters.AddWithValue("@ID_funcionario", idFuncionario);

                    
                    cmdIns.ExecuteNonQuery();

                    Eventos_Load(sender, e);

                }
            }

            // 4) Atualiza as labels e volta ao modo apenas-leitura
            label2.Text = textBoxNome.Text;
            label3.Text = dataI.ToString("dd/MM/yyyy");
            label4.Text = dataF.ToString("dd/MM/yyyy");
            label5.Text = textBoxCapaciade.Text;
            label6.Text = textBoxStatus.Text;
            label7.Text = textBoxFuncionario.Text;

            dtpDataInit.Visible = dtpDataFim.Visible = false;

            foreach (var lbl in new[] { label1, label2, label3, label4, label5, label6, label7 })
                lbl.Visible = true;
            foreach (var tb in new[]{ textBoxID,textBoxNome,textBoxData_I,textBoxData_F,
                              textBoxCapaciade,textBoxStatus,textBoxFuncionario })
                tb.Visible = false;

            OK2.Visible = false;
            Editar.Visible = true;
            Adicionar.Visible = true;

            

            MessageBox.Show("Evento criado com sucesso!", "OK",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}