﻿namespace Contacts
{
    partial class PromosAtivas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.ID_promocao = new System.Windows.Forms.Label();
            this.Nome = new System.Windows.Forms.Label();
            this.Tipo = new System.Windows.Forms.Label();
            this.Data_inicio = new System.Windows.Forms.Label();
            this.Data_fim = new System.Windows.Forms.Label();
            this.ID_evento = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(0, 1);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(362, 446);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // ID_promocao
            // 
            this.ID_promocao.AutoSize = true;
            this.ID_promocao.Location = new System.Drawing.Point(429, 63);
            this.ID_promocao.Name = "ID_promocao";
            this.ID_promocao.Size = new System.Drawing.Size(71, 13);
            this.ID_promocao.TabIndex = 1;
            this.ID_promocao.Text = "ID_promocao";
            // 
            // Nome
            // 
            this.Nome.AutoSize = true;
            this.Nome.Location = new System.Drawing.Point(429, 138);
            this.Nome.Name = "Nome";
            this.Nome.Size = new System.Drawing.Size(35, 13);
            this.Nome.TabIndex = 2;
            this.Nome.Text = "Nome";
            // 
            // Tipo
            // 
            this.Tipo.AutoSize = true;
            this.Tipo.Location = new System.Drawing.Point(429, 203);
            this.Tipo.Name = "Tipo";
            this.Tipo.Size = new System.Drawing.Size(28, 13);
            this.Tipo.TabIndex = 3;
            this.Tipo.Text = "Tipo";
            // 
            // Data_inicio
            // 
            this.Data_inicio.AutoSize = true;
            this.Data_inicio.Location = new System.Drawing.Point(429, 256);
            this.Data_inicio.Name = "Data_inicio";
            this.Data_inicio.Size = new System.Drawing.Size(60, 13);
            this.Data_inicio.TabIndex = 4;
            this.Data_inicio.Text = "Data_inicio";
            // 
            // Data_fim
            // 
            this.Data_fim.AutoSize = true;
            this.Data_fim.Location = new System.Drawing.Point(429, 308);
            this.Data_fim.Name = "Data_fim";
            this.Data_fim.Size = new System.Drawing.Size(49, 13);
            this.Data_fim.TabIndex = 5;
            this.Data_fim.Text = "Data_fim";
            // 
            // ID_evento
            // 
            this.ID_evento.AutoSize = true;
            this.ID_evento.Location = new System.Drawing.Point(429, 354);
            this.ID_evento.Name = "ID_evento";
            this.ID_evento.Size = new System.Drawing.Size(57, 13);
            this.ID_evento.TabIndex = 6;
            this.ID_evento.Text = "ID_evento";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(565, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "label1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(565, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "label2";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(565, 203);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "label3";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(565, 256);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "label4";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(565, 308);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "label5";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(565, 354);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "label6";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // PromosAtivas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ID_evento);
            this.Controls.Add(this.Data_fim);
            this.Controls.Add(this.Data_inicio);
            this.Controls.Add(this.Tipo);
            this.Controls.Add(this.Nome);
            this.Controls.Add(this.ID_promocao);
            this.Controls.Add(this.listBox1);
            this.Name = "PromosAtivas";
            this.Text = "PromosAtivas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label ID_promocao;
        private System.Windows.Forms.Label Nome;
        private System.Windows.Forms.Label Tipo;
        private System.Windows.Forms.Label Data_inicio;
        private System.Windows.Forms.Label Data_fim;
        private System.Windows.Forms.Label ID_evento;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}