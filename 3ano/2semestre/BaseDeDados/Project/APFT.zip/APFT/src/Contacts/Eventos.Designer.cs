﻿namespace Contacts
{
    partial class Eventos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.labelNome = new System.Windows.Forms.Label();
            this.labelID_Evento = new System.Windows.Forms.Label();
            this.Data_inicio = new System.Windows.Forms.Label();
            this.Data_fim = new System.Windows.Forms.Label();
            this.Capacidade = new System.Windows.Forms.Label();
            this.Funcionario = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Status = new System.Windows.Forms.Label();
            this.Editar = new System.Windows.Forms.Button();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.textBoxNome = new System.Windows.Forms.TextBox();
            this.textBoxData_I = new System.Windows.Forms.TextBox();
            this.textBoxData_F = new System.Windows.Forms.TextBox();
            this.textBoxCapaciade = new System.Windows.Forms.TextBox();
            this.textBoxStatus = new System.Windows.Forms.TextBox();
            this.textBoxFuncionario = new System.Windows.Forms.TextBox();
            this.OK = new System.Windows.Forms.Button();
            this.Adicionar = new System.Windows.Forms.Button();
            this.OK2 = new System.Windows.Forms.Button();
            this.dtpDataInit = new System.Windows.Forms.DateTimePicker();
            this.dtpDataFim = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(-1, 3);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(390, 446);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // labelNome
            // 
            this.labelNome.AutoSize = true;
            this.labelNome.Location = new System.Drawing.Point(431, 106);
            this.labelNome.Name = "labelNome";
            this.labelNome.Size = new System.Drawing.Size(35, 13);
            this.labelNome.TabIndex = 1;
            this.labelNome.Text = "Nome";
            // 
            // labelID_Evento
            // 
            this.labelID_Evento.AutoSize = true;
            this.labelID_Evento.Location = new System.Drawing.Point(431, 60);
            this.labelID_Evento.Name = "labelID_Evento";
            this.labelID_Evento.Size = new System.Drawing.Size(57, 13);
            this.labelID_Evento.TabIndex = 2;
            this.labelID_Evento.Text = "ID_evento";
            // 
            // Data_inicio
            // 
            this.Data_inicio.AutoSize = true;
            this.Data_inicio.Location = new System.Drawing.Point(431, 146);
            this.Data_inicio.Name = "Data_inicio";
            this.Data_inicio.Size = new System.Drawing.Size(60, 13);
            this.Data_inicio.TabIndex = 3;
            this.Data_inicio.Text = "Data_inicio";
            // 
            // Data_fim
            // 
            this.Data_fim.AutoSize = true;
            this.Data_fim.Location = new System.Drawing.Point(431, 197);
            this.Data_fim.Name = "Data_fim";
            this.Data_fim.Size = new System.Drawing.Size(49, 13);
            this.Data_fim.TabIndex = 4;
            this.Data_fim.Text = "Data_fim";
            // 
            // Capacidade
            // 
            this.Capacidade.AutoSize = true;
            this.Capacidade.Location = new System.Drawing.Point(431, 244);
            this.Capacidade.Name = "Capacidade";
            this.Capacidade.Size = new System.Drawing.Size(64, 13);
            this.Capacidade.TabIndex = 5;
            this.Capacidade.Text = "Capacidade";
            // 
            // Funcionario
            // 
            this.Funcionario.AutoSize = true;
            this.Funcionario.Location = new System.Drawing.Point(419, 347);
            this.Funcionario.Name = "Funcionario";
            this.Funcionario.Size = new System.Drawing.Size(62, 13);
            this.Funcionario.TabIndex = 6;
            this.Funcionario.Text = "Funcionario";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(526, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(526, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(526, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(526, 197);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(526, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "label5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(526, 292);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "label6";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(526, 347);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "label7";
            // 
            // Status
            // 
            this.Status.AutoSize = true;
            this.Status.Location = new System.Drawing.Point(431, 292);
            this.Status.Name = "Status";
            this.Status.Size = new System.Drawing.Size(37, 13);
            this.Status.TabIndex = 14;
            this.Status.Text = "Status";
            // 
            // Editar
            // 
            this.Editar.Location = new System.Drawing.Point(422, 411);
            this.Editar.Name = "Editar";
            this.Editar.Size = new System.Drawing.Size(96, 27);
            this.Editar.TabIndex = 15;
            this.Editar.Text = "Editar";
            this.Editar.UseVisualStyleBackColor = true;
            this.Editar.Click += new System.EventHandler(this.Editar_Click);
            // 
            // textBoxID
            // 
            this.textBoxID.Location = new System.Drawing.Point(508, 60);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.Size = new System.Drawing.Size(100, 20);
            this.textBoxID.TabIndex = 16;
            // 
            // textBoxNome
            // 
            this.textBoxNome.Location = new System.Drawing.Point(508, 103);
            this.textBoxNome.Name = "textBoxNome";
            this.textBoxNome.Size = new System.Drawing.Size(100, 20);
            this.textBoxNome.TabIndex = 17;
            // 
            // textBoxData_I
            // 
            this.textBoxData_I.Location = new System.Drawing.Point(508, 143);
            this.textBoxData_I.Name = "textBoxData_I";
            this.textBoxData_I.Size = new System.Drawing.Size(100, 20);
            this.textBoxData_I.TabIndex = 18;
            // 
            // textBoxData_F
            // 
            this.textBoxData_F.Location = new System.Drawing.Point(508, 190);
            this.textBoxData_F.Name = "textBoxData_F";
            this.textBoxData_F.Size = new System.Drawing.Size(100, 20);
            this.textBoxData_F.TabIndex = 19;
            // 
            // textBoxCapaciade
            // 
            this.textBoxCapaciade.Location = new System.Drawing.Point(508, 244);
            this.textBoxCapaciade.Name = "textBoxCapaciade";
            this.textBoxCapaciade.Size = new System.Drawing.Size(100, 20);
            this.textBoxCapaciade.TabIndex = 20;
            // 
            // textBoxStatus
            // 
            this.textBoxStatus.Location = new System.Drawing.Point(508, 292);
            this.textBoxStatus.Name = "textBoxStatus";
            this.textBoxStatus.Size = new System.Drawing.Size(100, 20);
            this.textBoxStatus.TabIndex = 21;
            // 
            // textBoxFuncionario
            // 
            this.textBoxFuncionario.Location = new System.Drawing.Point(508, 347);
            this.textBoxFuncionario.Name = "textBoxFuncionario";
            this.textBoxFuncionario.Size = new System.Drawing.Size(100, 20);
            this.textBoxFuncionario.TabIndex = 22;
            // 
            // OK
            // 
            this.OK.Location = new System.Drawing.Point(564, 415);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(75, 23);
            this.OK.TabIndex = 23;
            this.OK.Text = "OK";
            this.OK.UseVisualStyleBackColor = true;
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // Adicionar
            // 
            this.Adicionar.Location = new System.Drawing.Point(691, 413);
            this.Adicionar.Name = "Adicionar";
            this.Adicionar.Size = new System.Drawing.Size(75, 23);
            this.Adicionar.TabIndex = 24;
            this.Adicionar.Text = "Adicionar";
            this.Adicionar.UseVisualStyleBackColor = true;
            this.Adicionar.Click += new System.EventHandler(this.Adicionar_Click);
            // 
            // OK2
            // 
            this.OK2.Location = new System.Drawing.Point(499, 415);
            this.OK2.Name = "OK2";
            this.OK2.Size = new System.Drawing.Size(75, 23);
            this.OK2.TabIndex = 25;
            this.OK2.Text = "OK";
            this.OK2.UseVisualStyleBackColor = true;
            this.OK2.Click += new System.EventHandler(this.OK2_Click);
            // 
            // dtpDataInit
            // 
            this.dtpDataInit.Location = new System.Drawing.Point(508, 146);
            this.dtpDataInit.Name = "dtpDataInit";
            this.dtpDataInit.Size = new System.Drawing.Size(200, 20);
            this.dtpDataInit.TabIndex = 26;
            // 
            // dtpDataFim
            // 
            this.dtpDataFim.Location = new System.Drawing.Point(508, 191);
            this.dtpDataFim.Name = "dtpDataFim";
            this.dtpDataFim.Size = new System.Drawing.Size(200, 20);
            this.dtpDataFim.TabIndex = 27;
            // 
            // Eventos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dtpDataFim);
            this.Controls.Add(this.dtpDataInit);
            this.Controls.Add(this.OK2);
            this.Controls.Add(this.Adicionar);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.textBoxFuncionario);
            this.Controls.Add(this.textBoxStatus);
            this.Controls.Add(this.textBoxCapaciade);
            this.Controls.Add(this.textBoxData_F);
            this.Controls.Add(this.textBoxData_I);
            this.Controls.Add(this.textBoxNome);
            this.Controls.Add(this.textBoxID);
            this.Controls.Add(this.Editar);
            this.Controls.Add(this.Status);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Funcionario);
            this.Controls.Add(this.Capacidade);
            this.Controls.Add(this.Data_fim);
            this.Controls.Add(this.Data_inicio);
            this.Controls.Add(this.labelID_Evento);
            this.Controls.Add(this.labelNome);
            this.Controls.Add(this.listBox1);
            this.Name = "Eventos";
            this.Text = "Eventos";
            this.Load += new System.EventHandler(this.Eventos_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label labelNome;
        private System.Windows.Forms.Label labelID_Evento;
        private System.Windows.Forms.Label Data_inicio;
        private System.Windows.Forms.Label Data_fim;
        private System.Windows.Forms.Label Capacidade;
        private System.Windows.Forms.Label Funcionario;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label Status;
        private System.Windows.Forms.Button Editar;
        private System.Windows.Forms.TextBox textBoxID;
        private System.Windows.Forms.TextBox textBoxNome;
        private System.Windows.Forms.TextBox textBoxData_I;
        private System.Windows.Forms.TextBox textBoxData_F;
        private System.Windows.Forms.TextBox textBoxCapaciade;
        private System.Windows.Forms.TextBox textBoxStatus;
        private System.Windows.Forms.TextBox textBoxFuncionario;
        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button Adicionar;
        private System.Windows.Forms.Button OK2;
        private System.Windows.Forms.DateTimePicker dtpDataInit;
        private System.Windows.Forms.DateTimePicker dtpDataFim;
    }
}