use ArcadeDB;

DROP PROCEDURE arcade.sp_add_jogador;
DROP PROCEDURE sp_add_jogador;
DROP PROCEDURE arcade.sp_add_funcionario;
DROP PROCEDURE arcade.sp_add_gerente;
DROP PROCEDURE arcade.sp_add_manutencao;

