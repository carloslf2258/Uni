use ArcadeDB;
go

/*
Run Query -> Inserts to DB (+/- 3 of each one)
*/


-- 1. Maquina
INSERT INTO arcade.Maquina VALUES 
(1001, 'Corrida', 'SpeedRacer X', 'Namco', 'Operacional', '2023-06-15'),
(1002, 'Luta', 'Street Fighter V', 'Capcom', 'Manuten��o', '2022-11-10'),
(1003, 'Tiro', 'Time Crisis 4', 'Namco', 'Operacional', '2023-01-20'),
(1004, 'Corrida', 'Forza Horizon', 'Nintendo', 'Operacional', '2024-11-10'),
(1005, 'Tiro', 'Pac-man', 'Namco', 'Operacional', '2022-11-10'),
(1006, 'Luta', 'Mario Bros', 'Nintendo', 'Manuten��o', '2022-11-09');

-- 2. Programa_fidelidade
INSERT INTO arcade.Programa_fidelidade VALUES 
(2001, 'Bronze', 'Fidelidade b�sica', 'Pontos', 'Acumular 1000 pontos', '2023-01-01', '2024-12-31'),
(2002, 'Prata', 'N�vel m�dio', 'Pontos', 'Acumular 3000 pontos', '2023-01-01', '2024-12-31'),
(2003, 'Ouro', 'N�vel premium', 'Pontos', 'Acumular 5000 pontos', '2023-01-01', '2024-12-31');

-- 3. Jogador
INSERT INTO arcade.Jogador VALUES 
(3001, 'Pedro Silva', 'pedro@gmail.com', '912345678', 1500, 2001),
(3002, 'Rita Lopes', 'rita@gmail.com', '913456789', 3200, 2002),
(3003, 'Carlos Mendes', 'carlosm@gmail.com', '914567890', 5500, 2003),
(3004, 'Jo�o Correia', 'jotas@gmail.com', '232456745', 3100, 2002),
(3005, 'Mariana Lopes', 'marianl@gmail.com', '122456787', 200, 2001);

-- 4. Funcionario (FK Manuten��o pode ser NULL)
INSERT INTO arcade.Funcionario VALUES 
(4001, 'Jo�o Martins', 'T�cnico', 'Noite', 850, 'joao@arcade.pt', NULL),
(4002, 'Ana Costa', 'Atendimento', 'Dia', 750, 'ana@arcade.pt', NULL),
(4003, 'Carlos Verenzuela', 'Atendimento', 'Dia', 1000, 'carloslf2258@gmail.com', NULL),
(4004, 'Pedro Manuel', 'Atendimento', 'Dia', 600, 'pedmanu@arcade.pt', NULL);


-- 5. Manutencao 
--FK (Maq e Fun)
INSERT INTO arcade.Manutencao VALUES 
(5001, 'Preventiva', '2024-03-01', '2024-03-02', 'Verifica��o geral da m�quina 2', 'Conclu�do', 1002, 4001),
(5002, 'Corretiva', '2024-04-10', '2024-04-11', 'Substitui��o de cabos da m�quina 3', 'Conclu�do', 1003, 4002),
(5003, 'Corretiva', '2025-03-01', NULL, 'Arranjar bot�es', 'Ativa', 1006, 4003),
(5004, 'Corretiva', '2024-04-10', NULL, 'Substitui��o ecr�', 'Agendada', 1005, 4003);


-- 6. Evento
INSERT INTO arcade.Evento VALUES 
(6001, 'Torneio de Street Fighter', '2024-07-01', '2024-07-05', 50, 'Planeado', 4001),
(6002, 'Maratona de Jogos', '2024-08-10', '2024-08-12', 100, 'Confirmado', 4002);

-- 7. Promocao
INSERT INTO arcade.Promocao VALUES 
(7001, 'Promo F�rias', 'Desconto', '2024-07-01', '2024-07-31', 6001),
(7002, 'Promo Ver�o', 'B�nus', '2024-08-01', '2024-08-15', 6002);

-- 8. Gerente
INSERT INTO arcade.Gerente VALUES 
(8001, '2023-01-01', NULL, 'Organiza��o de eventos e supervis�o geral', 6001),
(8002, '2023-03-01', NULL, 'Gest�o de pessoal e manuten��o', 6002);


-- 9. Card_fichas
--FK(jogador,funcionario)
INSERT INTO arcade.Card_fichas VALUES 
(9001, 10.00, 30, 120, '2025-04-20', 3001, 4002),
(9002, 20.00, 50, 250, '2025-04-25', 3002, 4001),
(9003, 15.00, 40, 200, '2025-05-01', 3003, 4001);

-- 10. Carregamento
--FK (card_fichas, funcionario)
INSERT INTO arcade.Carregamento VALUES 
(10.00, 30, 9001, 4002),
(20.00, 50, 9002, 4001),
(15.00, 40, 9003, 4001);

-- 11. Sessao_jogo
--FK (maquina, jogador)
INSERT INTO arcade.Sessao_jogo VALUES 
(11001, '00:30:00', 500, 'Finalizada', 3, 1001, 3001),
(11002, '00:45:00', 800, 'Finalizada', 4, 1002, 3002),
(11003, '00:20:00', 300, 'Interrompida', 2, 1003, 3003);

-- 12. Usufrui_promocao
--(jogador, promo��o)
INSERT INTO arcade.Usufrui_promocao VALUES 
(3001, 7001),
(3002, 7002),
(3003, 7002);

-- 13. G_Tem_F
--(gerente,funcionario)
INSERT INTO arcade.G_Tem_F VALUES 
(8001, 4001),
(8001, 4002),
(8002, 4002);



--done

--Associar IDs de manuten��o aos Funcion�rios
UPDATE arcade.Funcionario
SET ID_manutencao = 5001
WHERE ID_funcionario = 4001;

UPDATE arcade.Funcionario
SET ID_manutencao = 5002
WHERE ID_funcionario = 4002;

UPDATE arcade.Funcionario
SET ID_manutencao = 5003
WHERE ID_funcionario = 4003;
