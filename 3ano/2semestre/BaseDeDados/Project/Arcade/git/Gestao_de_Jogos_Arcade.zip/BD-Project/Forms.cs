using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Contacts
{
    public partial class Form1 : Form
    {
        private SqlConnection cn;
        private int currentContact;
        private bool adding; // reservado para operações futuras

        public Form1()
        {
            InitializeComponent();

            if (bttnDelete != null)
                bttnDelete.Text = "Detalhes";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cn = GetSGBDConnection();
            loadCustomersToolStripMenuItem_Click(null, null);
        }

        #region Conexão SQL
        private SqlConnection GetSGBDConnection() =>
            new SqlConnection("data source=LAPTOP-AF0VHCF3\\SQLEXPRESS;integrated security=true;initial catalog=ArcadeDB");

        private bool VerifySGBDConnection()
        {
            if (cn == null)
                cn = GetSGBDConnection();
            if (cn.State != ConnectionState.Open)
                cn.Open();
            return cn.State == ConnectionState.Open;
        }
        #endregion

        #region Carregamento de Jogadores
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                currentContact = listBox1.SelectedIndex;
                ShowContact();
            }
        }

        private void loadCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!VerifySGBDConnection()) return;

            using (SqlCommand cmd = new SqlCommand("SELECT ID_jogador, Nome FROM arcade.Jogador", cn))
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                listBox1.Items.Clear();
                while (reader.Read())
                {
                    Contact c = new Contact
                    {
                        CustomerID = reader["ID_jogador"].ToString(),
                        ContactName = reader["Nome"].ToString()
                    };
                    listBox1.Items.Add(c);
                }
            }
            cn.Close();
            currentContact = 0;
            ShowContact();
        }
        #endregion

        #region Métodos de apoio (UI)
        private void LockControls() { txtID.ReadOnly = txtContact.ReadOnly = true; }
        private void UnlockControls() { txtID.ReadOnly = txtContact.ReadOnly = false; }
        private void ShowButtons() { LockControls(); bttnAdd.Visible = bttnDelete.Visible = true; }
        private void HideButtons() { UnlockControls(); bttnAdd.Visible = bttnDelete.Visible = false; }
        private void ClearFields() { txtID.Text = txtContact.Text = string.Empty; }
        private void ShowContact()
        {
            if (listBox1.Items.Count == 0 || currentContact < 0) return;
            Contact contact = (Contact)listBox1.Items[currentContact];
            txtID.Text = contact.CustomerID;
            txtContact.Text = contact.ContactName;
        }
        #endregion

        #region Event Handlers
        private void bttnAdd_Click(object sender, EventArgs e)
        {
            adding = true;
            ClearFields();
            HideButtons();
            listBox1.Enabled = false;
        }

        private void bttnDelete_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
            {
                MessageBox.Show("Selecione primeiro um jogador na lista.");
                return;
            }

            Contact contact = (Contact)listBox1.SelectedItem;

            // ─── Consulta completa com JOIN para Programa_fidelidade ───
            string nome = string.Empty, email = string.Empty, telefone = string.Empty;
            string pontuacao = string.Empty, programaNome = string.Empty, programaDesc = string.Empty;

            if (VerifySGBDConnection())
            {
                string sql = @"SELECT j.Nome, j.Email, j.Telefone, j.Pontuacao_total,
                                        pf.Nome AS NomePrograma, pf.Descricao
                                 FROM   arcade.Jogador            j
                                 LEFT JOIN arcade.Programa_fidelidade pf ON pf.ID_programa_fidelidade = j.ID_programa_fidelidade
                                 WHERE  j.ID_jogador = @id";

                using (SqlCommand cmd = new SqlCommand(sql, cn))
                {
                    cmd.Parameters.AddWithValue("@id", contact.CustomerID);
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        if (r.Read())
                        {
                            nome = r["Nome"].ToString();
                            email = r["Email"].ToString();
                            telefone = r["Telefone"].ToString();
                            pontuacao = r["Pontuacao_total"].ToString();
                            programaNome = r["NomePrograma"].ToString();
                            programaDesc = r["Descricao"].ToString();
                        }
                    }
                }
                cn.Close();
            }

            // ─── Cria formulário de detalhes ───
            Form detalhesForm = new Form
            {
                Text = $"Detalhes do Jogador #{contact.CustomerID}",
                Size = new Size(500, 400),
                MinimumSize = new Size(450, 300),
                StartPosition = FormStartPosition.CenterScreen
            };

            var tbl = new TableLayoutPanel
            {
                ColumnCount = 2,
                RowCount = 8,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Location = new Point(20, 20)
            };
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));

            void AddRow(string label, string value, int row, bool bold = true)
            {
                tbl.Controls.Add(new Label { Text = label, AutoSize = true, Anchor = AnchorStyles.Right }, 0, row);
                tbl.Controls.Add(new Label
                {
                    Text = value,
                    AutoSize = true,
                    Font = new Font(FontFamily.GenericSansSerif, 9, bold ? FontStyle.Bold : FontStyle.Regular),
                    MaximumSize = new Size(350, 0), // permite quebra de linha
                    Anchor = AnchorStyles.Left
                }, 1, row);
            }

            AddRow("ID:", contact.CustomerID, 0);
            AddRow("Nome:", nome, 1);
            AddRow("Email:", email, 2);
            AddRow("Telefone:", telefone, 3);
            AddRow("Pontuação Total:", pontuacao, 4);
            AddRow("Programa Fidelidade:", programaNome, 5);
            AddRow("Descrição Programa:", programaDesc, 6 );

            var btnFechar = new Button { Text = "Fechar", AutoSize = true, Anchor = AnchorStyles.Bottom | AnchorStyles.Right };
            const int margin = 20;
            btnFechar.Location = new Point(detalhesForm.ClientSize.Width - btnFechar.Width - margin, detalhesForm.ClientSize.Height - btnFechar.Height - margin);
            detalhesForm.Resize += (_, __) => btnFechar.Location = new Point(detalhesForm.ClientSize.Width - btnFechar.Width - margin, detalhesForm.ClientSize.Height - btnFechar.Height - margin);
            btnFechar.Click += (_, __) => detalhesForm.Close();

            detalhesForm.Controls.Add(tbl);
            detalhesForm.Controls.Add(btnFechar);
            detalhesForm.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e) => Application.Exit();
        private void panel3_Paint(object sender, PaintEventArgs e) { }
        #endregion

        private void button1_Click(object sender, EventArgs e)
        {
            (new Form2()).Show();
        }
    }
}
