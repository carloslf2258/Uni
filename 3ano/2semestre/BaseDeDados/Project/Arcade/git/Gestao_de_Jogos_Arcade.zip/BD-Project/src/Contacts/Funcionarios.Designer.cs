﻿namespace Contacts
{
    partial class Funcionarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonEliminar = new System.Windows.Forms.Button();
            this.buttonOk = new System.Windows.Forms.Button();
            this.buttonEditar = new System.Windows.Forms.Button();
            this.textBoxContacto = new System.Windows.Forms.TextBox();
            this.textBoxSalario = new System.Windows.Forms.TextBox();
            this.textBoxTurno = new System.Windows.Forms.TextBox();
            this.textBoxCargo = new System.Windows.Forms.TextBox();
            this.textBoxNome = new System.Windows.Forms.TextBox();
            this.labelContacto = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.labelSalario = new System.Windows.Forms.Label();
            this.labelTurno = new System.Windows.Forms.Label();
            this.labelCargo = new System.Windows.Forms.Label();
            this.labelTipo = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label_Cargo = new System.Windows.Forms.Label();
            this.labelNome = new System.Windows.Forms.Label();
            this.labelID = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listBoxFuncionarios = new System.Windows.Forms.ListBox();
            this.buttonAdicionar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.labelIDManutencao = new System.Windows.Forms.Label();
            this.textBoxIDManutencao = new System.Windows.Forms.TextBox();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonEliminar
            // 
            this.buttonEliminar.Location = new System.Drawing.Point(589, 496);
            this.buttonEliminar.Margin = new System.Windows.Forms.Padding(4);
            this.buttonEliminar.Name = "buttonEliminar";
            this.buttonEliminar.Size = new System.Drawing.Size(119, 36);
            this.buttonEliminar.TabIndex = 61;
            this.buttonEliminar.Text = "Eliminar";
            this.buttonEliminar.UseVisualStyleBackColor = true;
            this.buttonEliminar.Click += new System.EventHandler(this.buttonEliminar_Click_1);
            // 
            // buttonOk
            // 
            this.buttonOk.Location = new System.Drawing.Point(929, 496);
            this.buttonOk.Margin = new System.Windows.Forms.Padding(4);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(117, 38);
            this.buttonOk.TabIndex = 60;
            this.buttonOk.Text = "Ok";
            this.buttonOk.UseVisualStyleBackColor = true;
            this.buttonOk.Click += new System.EventHandler(this.buttonOk_Click_1);
            // 
            // buttonEditar
            // 
            this.buttonEditar.Location = new System.Drawing.Point(449, 497);
            this.buttonEditar.Margin = new System.Windows.Forms.Padding(4);
            this.buttonEditar.Name = "buttonEditar";
            this.buttonEditar.Size = new System.Drawing.Size(117, 38);
            this.buttonEditar.TabIndex = 59;
            this.buttonEditar.Text = "Editar";
            this.buttonEditar.UseVisualStyleBackColor = true;
            this.buttonEditar.Click += new System.EventHandler(this.buttonEditar_Click_1);
            // 
            // textBoxContacto
            // 
            this.textBoxContacto.Location = new System.Drawing.Point(535, 290);
            this.textBoxContacto.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxContacto.Name = "textBoxContacto";
            this.textBoxContacto.Size = new System.Drawing.Size(132, 22);
            this.textBoxContacto.TabIndex = 58;
            // 
            // textBoxSalario
            // 
            this.textBoxSalario.Location = new System.Drawing.Point(534, 232);
            this.textBoxSalario.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSalario.Name = "textBoxSalario";
            this.textBoxSalario.Size = new System.Drawing.Size(132, 22);
            this.textBoxSalario.TabIndex = 57;
            // 
            // textBoxTurno
            // 
            this.textBoxTurno.Location = new System.Drawing.Point(535, 193);
            this.textBoxTurno.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxTurno.Name = "textBoxTurno";
            this.textBoxTurno.Size = new System.Drawing.Size(132, 22);
            this.textBoxTurno.TabIndex = 56;
            // 
            // textBoxCargo
            // 
            this.textBoxCargo.Location = new System.Drawing.Point(535, 149);
            this.textBoxCargo.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxCargo.Name = "textBoxCargo";
            this.textBoxCargo.Size = new System.Drawing.Size(132, 22);
            this.textBoxCargo.TabIndex = 55;
            // 
            // textBoxNome
            // 
            this.textBoxNome.Location = new System.Drawing.Point(535, 107);
            this.textBoxNome.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxNome.Name = "textBoxNome";
            this.textBoxNome.Size = new System.Drawing.Size(132, 22);
            this.textBoxNome.TabIndex = 54;
            // 
            // labelContacto
            // 
            this.labelContacto.AutoSize = true;
            this.labelContacto.Location = new System.Drawing.Point(568, 293);
            this.labelContacto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelContacto.Name = "labelContacto";
            this.labelContacto.Size = new System.Drawing.Size(51, 16);
            this.labelContacto.TabIndex = 53;
            this.labelContacto.Text = "label12";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(446, 293);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 16);
            this.label11.TabIndex = 52;
            this.label11.Text = "Contacto";
            // 
            // labelSalario
            // 
            this.labelSalario.AutoSize = true;
            this.labelSalario.Location = new System.Drawing.Point(586, 235);
            this.labelSalario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSalario.Name = "labelSalario";
            this.labelSalario.Size = new System.Drawing.Size(51, 16);
            this.labelSalario.TabIndex = 51;
            this.labelSalario.Text = "label10";
            // 
            // labelTurno
            // 
            this.labelTurno.AutoSize = true;
            this.labelTurno.Location = new System.Drawing.Point(531, 196);
            this.labelTurno.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTurno.Name = "labelTurno";
            this.labelTurno.Size = new System.Drawing.Size(44, 16);
            this.labelTurno.TabIndex = 50;
            this.labelTurno.Text = "label9";
            // 
            // labelCargo
            // 
            this.labelCargo.AutoSize = true;
            this.labelCargo.Location = new System.Drawing.Point(558, 153);
            this.labelCargo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCargo.Name = "labelCargo";
            this.labelCargo.Size = new System.Drawing.Size(44, 16);
            this.labelCargo.TabIndex = 49;
            this.labelCargo.Text = "label8";
            // 
            // labelTipo
            // 
            this.labelTipo.AutoSize = true;
            this.labelTipo.Location = new System.Drawing.Point(558, 110);
            this.labelTipo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTipo.Name = "labelTipo";
            this.labelTipo.Size = new System.Drawing.Size(44, 16);
            this.labelTipo.TabIndex = 48;
            this.labelTipo.Text = "label7";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(446, 235);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 16);
            this.label6.TabIndex = 47;
            this.label6.Text = "Salário";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(446, 196);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 16);
            this.label5.TabIndex = 46;
            this.label5.Text = "Turno";
            // 
            // label_Cargo
            // 
            this.label_Cargo.AutoSize = true;
            this.label_Cargo.Location = new System.Drawing.Point(446, 153);
            this.label_Cargo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Cargo.Name = "label_Cargo";
            this.label_Cargo.Size = new System.Drawing.Size(44, 16);
            this.label_Cargo.TabIndex = 45;
            this.label_Cargo.Text = "Cargo";
            // 
            // labelNome
            // 
            this.labelNome.AutoSize = true;
            this.labelNome.Location = new System.Drawing.Point(442, 107);
            this.labelNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelNome.Name = "labelNome";
            this.labelNome.Size = new System.Drawing.Size(44, 16);
            this.labelNome.TabIndex = 44;
            this.labelNome.Text = "Nome";
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Location = new System.Drawing.Point(549, 52);
            this.labelID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(44, 16);
            this.labelID.TabIndex = 43;
            this.labelID.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(442, 55);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 16);
            this.label1.TabIndex = 42;
            this.label1.Text = "ID";
            // 
            // listBoxFuncionarios
            // 
            this.listBoxFuncionarios.FormattingEnabled = true;
            this.listBoxFuncionarios.ItemHeight = 16;
            this.listBoxFuncionarios.Location = new System.Drawing.Point(21, 19);
            this.listBoxFuncionarios.Name = "listBoxFuncionarios";
            this.listBoxFuncionarios.Size = new System.Drawing.Size(369, 516);
            this.listBoxFuncionarios.TabIndex = 41;
            // 
            // buttonAdicionar
            // 
            this.buttonAdicionar.Location = new System.Drawing.Point(929, 496);
            this.buttonAdicionar.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAdicionar.Name = "buttonAdicionar";
            this.buttonAdicionar.Size = new System.Drawing.Size(117, 39);
            this.buttonAdicionar.TabIndex = 40;
            this.buttonAdicionar.Text = "Adicionar";
            this.buttonAdicionar.UseVisualStyleBackColor = true;
            this.buttonAdicionar.Click += new System.EventHandler(this.buttonAdicionar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(446, 365);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 16);
            this.label2.TabIndex = 62;
            this.label2.Text = "ID Manutenção";
            // 
            // labelIDManutencao
            // 
            this.labelIDManutencao.AutoSize = true;
            this.labelIDManutencao.Location = new System.Drawing.Point(568, 365);
            this.labelIDManutencao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelIDManutencao.Name = "labelIDManutencao";
            this.labelIDManutencao.Size = new System.Drawing.Size(51, 16);
            this.labelIDManutencao.TabIndex = 63;
            this.labelIDManutencao.Text = "label12";
            // 
            // textBoxIDManutencao
            // 
            this.textBoxIDManutencao.Location = new System.Drawing.Point(551, 365);
            this.textBoxIDManutencao.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxIDManutencao.Name = "textBoxIDManutencao";
            this.textBoxIDManutencao.Size = new System.Drawing.Size(132, 22);
            this.textBoxIDManutencao.TabIndex = 64;
            // 
            // textBoxID
            // 
            this.textBoxID.Location = new System.Drawing.Point(534, 49);
            this.textBoxID.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.Size = new System.Drawing.Size(132, 22);
            this.textBoxID.TabIndex = 65;
            // 
            // Funcionarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.textBoxID);
            this.Controls.Add(this.textBoxIDManutencao);
            this.Controls.Add(this.labelIDManutencao);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonEliminar);
            this.Controls.Add(this.buttonOk);
            this.Controls.Add(this.buttonEditar);
            this.Controls.Add(this.textBoxContacto);
            this.Controls.Add(this.textBoxSalario);
            this.Controls.Add(this.textBoxTurno);
            this.Controls.Add(this.textBoxCargo);
            this.Controls.Add(this.textBoxNome);
            this.Controls.Add(this.labelContacto);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.labelSalario);
            this.Controls.Add(this.labelTurno);
            this.Controls.Add(this.labelCargo);
            this.Controls.Add(this.labelTipo);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label_Cargo);
            this.Controls.Add(this.labelNome);
            this.Controls.Add(this.labelID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBoxFuncionarios);
            this.Controls.Add(this.buttonAdicionar);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Funcionarios";
            this.Text = "Funcionarios";
            this.Load += new System.EventHandler(this.Funcionarios_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonEliminar;
        private System.Windows.Forms.Button buttonOk;
        private System.Windows.Forms.Button buttonEditar;
        private System.Windows.Forms.TextBox textBoxContacto;
        private System.Windows.Forms.TextBox textBoxSalario;
        private System.Windows.Forms.TextBox textBoxTurno;
        private System.Windows.Forms.TextBox textBoxCargo;
        private System.Windows.Forms.TextBox textBoxNome;
        private System.Windows.Forms.Label labelContacto;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label labelSalario;
        private System.Windows.Forms.Label labelTurno;
        private System.Windows.Forms.Label labelCargo;
        private System.Windows.Forms.Label labelTipo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label_Cargo;
        private System.Windows.Forms.Label labelNome;
        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBoxFuncionarios;
        private System.Windows.Forms.Button buttonAdicionar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelIDManutencao;
        private System.Windows.Forms.TextBox textBoxIDManutencao;
        private System.Windows.Forms.TextBox textBoxID;
    }
}