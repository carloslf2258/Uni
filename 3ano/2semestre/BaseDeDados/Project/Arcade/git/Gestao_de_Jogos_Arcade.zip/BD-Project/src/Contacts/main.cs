﻿using System;
using System.Windows.Forms;

namespace Contacts
{
    public partial class main: Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            Login loginForm = new Login();
            loginForm.Show();
        }

    }
}
