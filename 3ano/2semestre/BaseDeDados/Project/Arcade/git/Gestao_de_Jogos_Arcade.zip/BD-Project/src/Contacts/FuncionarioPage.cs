﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Contacts
{
    public partial class FuncionarioPage : Form
    {
        public int IDFuncionario { get; set; }
        string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";
        public FuncionarioPage()
        {
            InitializeComponent();
            LoadJogadores();
            
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;
            button2.Visible = false;

        }

        public class Jogador
        {
            public int ID { get; set; }
            public string Nome { get; set; }
            public string Email { get; set; }
            public string Telefone { get; set; }
            public int PontuacaoTotal { get; set; }
            public string ProgramaFidelidade { get; set; }

            public int FichasAtuais { get; set; }

            public override string ToString() => $"{ID} - {Nome} - {Email}";
        }


        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxJogadores.SelectedItem is Jogador jogador)
            {
                labelID.Text = $"{jogador.ID}";
                labelNome.Text = $" {jogador.Nome}";
                labelEmail.Text = $" {jogador.Email}";
                labelTelefone.Text = $" {jogador.Telefone}";
                labelPF.Text = $" {jogador.ProgramaFidelidade}";
                labelPT.Text = $" {jogador.PontuacaoTotal}";
                labelFichasAtuais.Text = $" {jogador.FichasAtuais}";
            }
        }

        private List<Jogador> jogadores = new List<Jogador>();

        private void LoadJogadores()
        {
            string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";
            string query = "SELECT * FROM arcade.udf_listar_jogadores()";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                try
                {
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        var jogador = new Jogador
                        {
                            ID = (int)reader["ID_jogador"],
                            Nome = reader["Nome"].ToString(),
                            Email = reader["Email"].ToString(),
                            Telefone = reader["Telefone"].ToString(),
                            PontuacaoTotal = (int)reader["Pontuacao_total"],
                            ProgramaFidelidade = reader["Programa_fidelidade"].ToString(),
                            FichasAtuais = (int)reader["Fichas_atuais"]
                        };
                        jogadores.Add(jogador);
                        listBoxJogadores.Items.Add(jogador);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar jogadores: " + ex.Message);
                }
                // Seleciona o primeiro jogador e carrega os dados
                if (listBoxJogadores.Items.Count > 0)
                {
                    listBoxJogadores.SelectedIndex = 0;
                }
            }
        }


        private void buttonEditar_Click(object sender, EventArgs e)
        {
            bool modoVisualizacao = !textBox2.Visible;

            if (modoVisualizacao)
            {
                textBox2.Text = labelNome.Text.Trim();
                textBox3.Text = labelEmail.Text.Trim();
                textBox4.Text = labelTelefone.Text.Trim();
                textBox6.Text = labelPT.Text.Trim(); // Pontuação
            }

            labelID.Visible = true;
            labelNome.Visible = !modoVisualizacao;
            labelEmail.Visible = !modoVisualizacao;
            labelTelefone.Visible = !modoVisualizacao;
            labelPF.Visible = true;
            labelPT.Visible = !modoVisualizacao;

            textBox2.Visible = modoVisualizacao;
            textBox3.Visible = modoVisualizacao;
            textBox4.Visible = modoVisualizacao;
            textBox6.Visible = modoVisualizacao;

            // Mostrar botão OK apenas em modo edição
            button2.Visible = modoVisualizacao;
        }


        private void buttonOK_Click(object sender, EventArgs e)
        {
            // Atualiza labels com os valores dos TextBoxes
            labelNome.Text = textBox2.Text.Trim();
            labelEmail.Text = textBox3.Text.Trim();
            labelTelefone.Text = textBox4.Text.Trim();
            labelPT.Text = textBox6.Text.Trim(); // Pontuação

            // Validação
            if (!int.TryParse(textBox6.Text.Trim(), out int pontuacao))
            {
                MessageBox.Show("Pontuação inválida.");
                return;
            }

            if (!int.TryParse(labelID.Text.Trim(), out int idJogador))
            {
                MessageBox.Show("ID do jogador inválido.");
                return;
            }

            string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("arcade.sp_atualizar_jogador", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ID_jogador", idJogador);
                cmd.Parameters.AddWithValue("@Nome", textBox2.Text.Trim());
                cmd.Parameters.AddWithValue("@Email", textBox3.Text.Trim());
                cmd.Parameters.AddWithValue("@Telefone", textBox4.Text.Trim());
                cmd.Parameters.AddWithValue("@Pontuacao_total", pontuacao);

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Jogador atualizado com sucesso.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao atualizar jogador: " + ex.Message);
                }
            }

            // Retornar ao modo visualização
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            textBox6.Visible = false;
            button2.Visible = false;


            labelNome.Visible = true;
            labelEmail.Visible = true;
            labelTelefone.Visible = true;
            labelPT.Visible = true;

            jogadores.Clear();
            listBoxJogadores.Items.Clear();
            LoadJogadores();
        }

        private void buttonAdicionar_Click(object sender, EventArgs e)
        {
            using (var addForm = new AddJogadorForm())
            {
                if (addForm.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        using (SqlConnection con = new SqlConnection(connectionString))
                        using (SqlCommand cmd = new SqlCommand("arcade.sp_add_jogador", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;

                            cmd.Parameters.AddWithValue("@ID_jogador", addForm.ID_jogador);
                            cmd.Parameters.AddWithValue("@Nome", addForm.Nome);

                            // Só adiciona se tiver valor, senão usa default (NULL no SQL)
                            if (!string.IsNullOrWhiteSpace(addForm.Email))
                                cmd.Parameters.AddWithValue("@Email", addForm.Email);

                            if (!string.IsNullOrWhiteSpace(addForm.Telefone))
                                cmd.Parameters.AddWithValue("@Telefone", addForm.Telefone);

                            // Se for diferente de null ou 0, então adiciona
                            if (addForm.PontuacaoTotal.HasValue)
                                cmd.Parameters.AddWithValue("@Pontuacao_total", addForm.PontuacaoTotal.Value);

                            if (addForm.ID_Programa_Fidelidade.HasValue)
                                cmd.Parameters.AddWithValue("@ID_programa_fidelidade", addForm.ID_Programa_Fidelidade.Value);

                            con.Open();
                            cmd.ExecuteNonQuery();
                        }

                        // Recarrega a lista de jogadores
                        jogadores.Clear();
                        listBoxJogadores.Items.Clear();
                        LoadJogadores();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro ao adicionar jogador: " + ex.Message);
                    }
                }
            }
        }


        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            // Confirmar com o utilizador antes de eliminar
            var confirm = MessageBox.Show("Tens a certeza que queres eliminar este jogador?",
                                          "Confirmar eliminação",
                                          MessageBoxButtons.YesNo,
                                          MessageBoxIcon.Warning);

            if (confirm == DialogResult.Yes)
            {
                try
                {
                    int idJogador = int.Parse(labelID.Text); // ID do jogador

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();

                        using (SqlCommand cmd = new SqlCommand("arcade.sp_eliminar_jogador", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@ID_jogador", idJogador);

                            int rowsAffected = cmd.ExecuteNonQuery();

                            MessageBox.Show("Jogador eliminado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    jogadores.Clear();
                    listBoxJogadores.Items.Clear();
                    LoadJogadores();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao eliminar jogador: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void buttonCarregar_Click(object sender, EventArgs e)
        {
            Carregamento formCarregamento = new Carregamento();
            formCarregamento.IDFuncionario = IDFuncionario;

            formCarregamento.CreditosCarregados += (s, args) =>
            {
                jogadores.Clear();
                listBoxJogadores.Items.Clear();
                LoadJogadores();
            };

            formCarregamento.Show();
        }


        private void Funcionario_Load(object sender, EventArgs e)
        {

        }
    }
}

