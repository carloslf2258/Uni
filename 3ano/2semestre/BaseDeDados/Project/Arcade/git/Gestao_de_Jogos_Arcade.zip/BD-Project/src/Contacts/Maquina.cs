﻿using System;

namespace Contacts
{
    public class Maquina
    {
        public int ID { get; set; }
        public string Tipo { get; set; }
        public string Modelo { get; set; }
        public string Fabricante { get; set; }
        public string Status { get; set; }
        public DateTime DataInstalacao { get; set; }

        public override string ToString()
        {
            return $"{ID} - {Tipo} - {Modelo} - {Fabricante}";
        }
    }

}