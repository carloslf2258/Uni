﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Contacts
{
    public partial class Addfuncionarios: Form
    {
        public int ID_funcionario => int.Parse(textBox8.Text);
        public string Nome => textBox9.Text;
        public string Cargo => textBox10.Text;
        public string Turno => textBox11.Text;
        public decimal Salario => decimal.Parse(textBox12.Text);
        public string Contacto => textBox13.Text;
        public int? ID_manutencao
            => int.TryParse(textBox14.Text, out int id) ? id : (int?)null;
        public Addfuncionarios()
        {
            InitializeComponent();
        }

        private void Addfuncionarios_Load(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
