﻿namespace Contacts
{
    partial class Stats
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelSessoesAtivas = new System.Windows.Forms.Label();
            this.labelNSessoesAtivas = new System.Windows.Forms.Label();
            this.labelFichas_vendidas = new System.Windows.Forms.Label();
            this.labelNFichas_vendidas = new System.Windows.Forms.Label();
            this.labelJogadores = new System.Windows.Forms.Label();
            this.labelOuro = new System.Windows.Forms.Label();
            this.labelPrata = new System.Windows.Forms.Label();
            this.labelBronze = new System.Windows.Forms.Label();
            this.labelNOuro = new System.Windows.Forms.Label();
            this.labelNPrata = new System.Windows.Forms.Label();
            this.labelNBronze = new System.Windows.Forms.Label();
            this.labelTotalFaturado = new System.Windows.Forms.Label();
            this.labelNFaturado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelSessoesAtivas
            // 
            this.labelSessoesAtivas.AutoSize = true;
            this.labelSessoesAtivas.Location = new System.Drawing.Point(39, 45);
            this.labelSessoesAtivas.Name = "labelSessoesAtivas";
            this.labelSessoesAtivas.Size = new System.Drawing.Size(119, 16);
            this.labelSessoesAtivas.TabIndex = 0;
            this.labelSessoesAtivas.Text = "Nº sessões ativas:";
            // 
            // labelNSessoesAtivas
            // 
            this.labelNSessoesAtivas.AutoSize = true;
            this.labelNSessoesAtivas.Location = new System.Drawing.Point(199, 45);
            this.labelNSessoesAtivas.Name = "labelNSessoesAtivas";
            this.labelNSessoesAtivas.Size = new System.Drawing.Size(138, 16);
            this.labelNSessoesAtivas.TabIndex = 1;
            this.labelNSessoesAtivas.Text = "labelNSessoesAtivas";
            // 
            // labelFichas_vendidas
            // 
            this.labelFichas_vendidas.AutoSize = true;
            this.labelFichas_vendidas.Location = new System.Drawing.Point(39, 121);
            this.labelFichas_vendidas.Name = "labelFichas_vendidas";
            this.labelFichas_vendidas.Size = new System.Drawing.Size(124, 16);
            this.labelFichas_vendidas.TabIndex = 2;
            this.labelFichas_vendidas.Text = "Nº Fichas vendidas";
            // 
            // labelNFichas_vendidas
            // 
            this.labelNFichas_vendidas.AutoSize = true;
            this.labelNFichas_vendidas.Location = new System.Drawing.Point(199, 121);
            this.labelNFichas_vendidas.Name = "labelNFichas_vendidas";
            this.labelNFichas_vendidas.Size = new System.Drawing.Size(124, 16);
            this.labelNFichas_vendidas.TabIndex = 3;
            this.labelNFichas_vendidas.Text = "Nº Fichas vendidas";
            // 
            // labelJogadores
            // 
            this.labelJogadores.AutoSize = true;
            this.labelJogadores.Location = new System.Drawing.Point(39, 198);
            this.labelJogadores.Name = "labelJogadores";
            this.labelJogadores.Size = new System.Drawing.Size(94, 16);
            this.labelJogadores.TabIndex = 4;
            this.labelJogadores.Text = "Nº Jogadores:";
            // 
            // labelOuro
            // 
            this.labelOuro.AutoSize = true;
            this.labelOuro.Location = new System.Drawing.Point(199, 198);
            this.labelOuro.Name = "labelOuro";
            this.labelOuro.Size = new System.Drawing.Size(36, 16);
            this.labelOuro.TabIndex = 5;
            this.labelOuro.Text = "Ouro";
            // 
            // labelPrata
            // 
            this.labelPrata.AutoSize = true;
            this.labelPrata.Location = new System.Drawing.Point(308, 198);
            this.labelPrata.Name = "labelPrata";
            this.labelPrata.Size = new System.Drawing.Size(39, 16);
            this.labelPrata.TabIndex = 6;
            this.labelPrata.Text = "Prata";
            // 
            // labelBronze
            // 
            this.labelBronze.AutoSize = true;
            this.labelBronze.Location = new System.Drawing.Point(413, 198);
            this.labelBronze.Name = "labelBronze";
            this.labelBronze.Size = new System.Drawing.Size(49, 16);
            this.labelBronze.TabIndex = 7;
            this.labelBronze.Text = "Bronze";
            // 
            // labelNOuro
            // 
            this.labelNOuro.AutoSize = true;
            this.labelNOuro.Location = new System.Drawing.Point(199, 223);
            this.labelNOuro.Name = "labelNOuro";
            this.labelNOuro.Size = new System.Drawing.Size(46, 16);
            this.labelNOuro.TabIndex = 8;
            this.labelNOuro.Text = "NOuro";
            // 
            // labelNPrata
            // 
            this.labelNPrata.AutoSize = true;
            this.labelNPrata.Location = new System.Drawing.Point(308, 223);
            this.labelNPrata.Name = "labelNPrata";
            this.labelNPrata.Size = new System.Drawing.Size(49, 16);
            this.labelNPrata.TabIndex = 9;
            this.labelNPrata.Text = "NPrata";
            // 
            // labelNBronze
            // 
            this.labelNBronze.AutoSize = true;
            this.labelNBronze.Location = new System.Drawing.Point(413, 223);
            this.labelNBronze.Name = "labelNBronze";
            this.labelNBronze.Size = new System.Drawing.Size(59, 16);
            this.labelNBronze.TabIndex = 10;
            this.labelNBronze.Text = "NBronze";
            // 
            // labelTotalFaturado
            // 
            this.labelTotalFaturado.AutoSize = true;
            this.labelTotalFaturado.Location = new System.Drawing.Point(39, 294);
            this.labelTotalFaturado.Name = "labelTotalFaturado";
            this.labelTotalFaturado.Size = new System.Drawing.Size(95, 16);
            this.labelTotalFaturado.TabIndex = 11;
            this.labelTotalFaturado.Text = "Total Faturado";
            // 
            // labelNFaturado
            // 
            this.labelNFaturado.AutoSize = true;
            this.labelNFaturado.Location = new System.Drawing.Point(199, 294);
            this.labelNFaturado.Name = "labelNFaturado";
            this.labelNFaturado.Size = new System.Drawing.Size(95, 16);
            this.labelNFaturado.TabIndex = 12;
            this.labelNFaturado.Text = "Total Faturado";
            // 
            // Stats
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelNFaturado);
            this.Controls.Add(this.labelTotalFaturado);
            this.Controls.Add(this.labelNBronze);
            this.Controls.Add(this.labelNPrata);
            this.Controls.Add(this.labelNOuro);
            this.Controls.Add(this.labelBronze);
            this.Controls.Add(this.labelPrata);
            this.Controls.Add(this.labelOuro);
            this.Controls.Add(this.labelJogadores);
            this.Controls.Add(this.labelNFichas_vendidas);
            this.Controls.Add(this.labelFichas_vendidas);
            this.Controls.Add(this.labelNSessoesAtivas);
            this.Controls.Add(this.labelSessoesAtivas);
            this.Name = "Stats";
            this.Text = "Stats";
            this.Load += new System.EventHandler(this.Stats_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelSessoesAtivas;
        private System.Windows.Forms.Label labelNSessoesAtivas;
        private System.Windows.Forms.Label labelFichas_vendidas;
        private System.Windows.Forms.Label labelNFichas_vendidas;
        private System.Windows.Forms.Label labelJogadores;
        private System.Windows.Forms.Label labelOuro;
        private System.Windows.Forms.Label labelPrata;
        private System.Windows.Forms.Label labelBronze;
        private System.Windows.Forms.Label labelNOuro;
        private System.Windows.Forms.Label labelNPrata;
        private System.Windows.Forms.Label labelNBronze;
        private System.Windows.Forms.Label labelTotalFaturado;
        private System.Windows.Forms.Label labelNFaturado;
    }
}