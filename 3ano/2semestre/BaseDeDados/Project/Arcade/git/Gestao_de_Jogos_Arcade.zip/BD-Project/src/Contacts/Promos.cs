﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Contacts
{
    public partial class Promos : Form
    {
        string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";

        public Promos()
        {
            InitializeComponent();
            this.Load += Promos_Load;
        }

        private void Promos_Load(object sender, EventArgs e)
        {
            CarregarPromocoes();
        }

        private void CarregarPromocoes()
        {
            string query = @"SELECT ID_promocao, Nome, Tipo, Data_inicio, Data_fim, ID_evento
                             FROM arcade.Promocao";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar promoções: " + ex.Message);
            }
        }
    }
}
