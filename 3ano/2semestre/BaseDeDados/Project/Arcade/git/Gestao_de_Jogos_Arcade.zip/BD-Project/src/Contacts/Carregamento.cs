﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Contacts
{
    public partial class Carregamento: Form
    {
        public int IDFuncionario { get; set; }
        string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";

        public event EventHandler CreditosCarregados;

        public Carregamento()
        {
            InitializeComponent();
        }


        private void buttonCarregar_Click(object sender, EventArgs e)
        {
            // Validação dos inputs
            if (!int.TryParse(textBoxCreditos.Text, out int creditos) || creditos <= 0)
            {
                MessageBox.Show("Insira um número válido de créditos.");
                return;
            }

            if (!decimal.TryParse(textBoxValor.Text, out decimal valor) || valor <= 0)
            {
                MessageBox.Show("Insira um valor válido.");
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    using (SqlCommand cmd = new SqlCommand("arcade.sp_carregar_creditos", conn))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;

                        // to do
                        cmd.Parameters.AddWithValue("@ID_jogador", textBoxID.Text.Trim());
                        cmd.Parameters.AddWithValue("@ID_funcionario", IDFuncionario);
                        cmd.Parameters.AddWithValue("@Valor", valor);
                        cmd.Parameters.AddWithValue("@Creditos", creditos);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Créditos carregados com sucesso!");
                CreditosCarregados?.Invoke(this, EventArgs.Empty); // <-- Notifica o formulário principal
                this.Close(); // ou this.Hide() se preferires



                //to do
                // Atualiza a label com os créditos mais recentes
                // Credito_Load
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar créditos: " + ex.Message);
            }
        }

    }
}
