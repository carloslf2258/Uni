﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Contacts
{
    public partial class Login: Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void buttonEntrar_Click(object sender, EventArgs e)
        {
            string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";
            string password = textBox4.Text.Trim();
            string inputID = textBoxLoginID.Text.Trim();

            if (!int.TryParse(inputID, out int userID))
            {
                MessageBox.Show("ID inválido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (password == "employ")
            {
                // Verifica se o ID está em Funcionario
                if (IDExiste("arcade.Funcionario", "ID_funcionario", userID, connectionString))
                {
                    FuncionarioPage form1 = new FuncionarioPage();
                    form1.IDFuncionario = userID;
                    form1.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("ID não corresponde a um funcionário válido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (password == "admin")
            {
                // Verifica se o ID está em Gerente
                if (IDExiste("arcade.Gerente", "ID_gerente", userID, connectionString))
                {
                    Gerente formGerente = new Gerente();
                    formGerente.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("ID não corresponde a um gerente válido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (password == "player")
            {
                // Verifica se o ID está em Jogador
                if (IDExiste("arcade.Jogador", "ID_jogador", userID, connectionString))
                {
                    Jogador formJogador = new Jogador();
                    formJogador.IDJogador = userID;
                    formJogador.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("ID não corresponde a um jogador válido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Palavra-passe incorreta!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool IDExiste(string tabela, string colunaID, int id, string connectionString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = $"SELECT COUNT(*) FROM {tabela} WHERE {colunaID} = @ID";
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@ID", id);
                    try
                    {
                        connection.Open();
                        int count = (int)cmd.ExecuteScalar();
                        return count > 0;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro na verificação de ID: " + ex.Message);
                        return false;
                    }
                }
            }
        }
    }
}
