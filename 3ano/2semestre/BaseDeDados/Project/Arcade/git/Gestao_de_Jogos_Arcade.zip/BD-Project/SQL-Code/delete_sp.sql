use ArcadeDB;

DROP PROCEDURE arcade.sp_add_jogador;
drop procedure arcade.sp_add_maquina
DROP PROCEDURE arcade.sp_add_funcionario;
DROP PROCEDURE arcade.sp_add_gerente;
DROP PROCEDURE arcade.sp_add_manutencao;

drop procedure arcade.sp_atualizar_jogador;
drop procedure arcade.sp_atualizar_maquina;
drop procedure arcade.sp_atualizar_funcionario;

drop procedure arcade.sp_eliminar_jogador;
drop procedure arcade.sp_eliminar_maquina;
drop procedure arcade.sp_eliminar_funcionario;

drop procedure arcade.sp_carregar_creditos;
