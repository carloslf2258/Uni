﻿namespace Contacts
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonLogin = new System.Windows.Forms.Button();
            this.labelGerente = new System.Windows.Forms.Label();
            this.labelFuncionario = new System.Windows.Forms.Label();
            this.labelJogador = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonLogin
            // 
            this.buttonLogin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonLogin.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.buttonLogin.Location = new System.Drawing.Point(108, 131);
            this.buttonLogin.Margin = new System.Windows.Forms.Padding(4);
            this.buttonLogin.Name = "buttonLogin";
            this.buttonLogin.Size = new System.Drawing.Size(91, 45);
            this.buttonLogin.TabIndex = 143;
            this.buttonLogin.Text = "Login";
            this.buttonLogin.Click += new System.EventHandler(this.buttonLogin_Click);
            // 
            // labelGerente
            // 
            this.labelGerente.AutoSize = true;
            this.labelGerente.Location = new System.Drawing.Point(73, 20);
            this.labelGerente.Name = "labelGerente";
            this.labelGerente.Size = new System.Drawing.Size(164, 16);
            this.labelGerente.TabIndex = 144;
            this.labelGerente.Text = "Gerente ID exemplo - 8001";
            // 
            // labelFuncionario
            // 
            this.labelFuncionario.AutoSize = true;
            this.labelFuncionario.Location = new System.Drawing.Point(73, 54);
            this.labelFuncionario.Name = "labelFuncionario";
            this.labelFuncionario.Size = new System.Drawing.Size(186, 16);
            this.labelFuncionario.TabIndex = 145;
            this.labelFuncionario.Text = "Funcionario ID exemplo - 4001";
            // 
            // labelJogador
            // 
            this.labelJogador.AutoSize = true;
            this.labelJogador.Location = new System.Drawing.Point(73, 91);
            this.labelJogador.Name = "labelJogador";
            this.labelJogador.Size = new System.Drawing.Size(167, 16);
            this.labelJogador.TabIndex = 146;
            this.labelJogador.Text = "Jogador ID exemplo - 3001";
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(320, 204);
            this.Controls.Add(this.labelJogador);
            this.Controls.Add(this.labelFuncionario);
            this.Controls.Add(this.labelGerente);
            this.Controls.Add(this.buttonLogin);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "main";
            this.Text = "Entry";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonLogin;
        private System.Windows.Forms.Label labelGerente;
        private System.Windows.Forms.Label labelFuncionario;
        private System.Windows.Forms.Label labelJogador;
    }
}