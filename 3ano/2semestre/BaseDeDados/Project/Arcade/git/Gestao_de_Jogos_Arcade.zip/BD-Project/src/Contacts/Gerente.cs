﻿using System;
using System.Windows.Forms;

namespace Contacts
{
    public partial class Gerente: Form
    {
        public Gerente()
        {
            InitializeComponent();
        }

        private void buttonMaquinas_Click(object sender, EventArgs e)
        {
            using (Maquinas popup = new Maquinas())
            {
                popup.ShowDialog(); 
            }
        }

        private void buttonFidelidade_Click(object sender, EventArgs e)
        {
            using (Fidelidade form = new Fidelidade())
            {
                form.ShowDialog();  
            }

        }

        private void buttonFuncionarios_Click(object sender, EventArgs e)
        {
            using (Funcionarios form = new Funcionarios())
            {
                form.ShowDialog();  
            }
        }

        private void buttonPromos_Click(object sender, EventArgs e)
        {
            using (Promos form = new Promos())
            {
                form.ShowDialog();
            }
        }

        private void buttonEventos_Click(object sender, EventArgs e)
        {
            using (Promos form = new Promos())
            {
                form.ShowDialog();
            }
        }

        private void buttonStats_Click(object sender, EventArgs e)
        {
            using (Stats form = new Stats())
            {
                form.ShowDialog();
            }
        }
    }
}
