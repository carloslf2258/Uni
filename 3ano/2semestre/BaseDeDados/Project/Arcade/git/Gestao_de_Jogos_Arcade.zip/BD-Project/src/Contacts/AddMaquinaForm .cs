﻿using System;
using System.Windows.Forms;

namespace Contacts
{
    public partial class AddMaquinaForm: Form
    {
        public int ID_maquina => int.Parse(textBox7.Text);
        public string Tipo => textBox8.Text;
        public string Modelo => textBox9.Text;
        public string Fabricante => textBox10.Text;
        public string StatusMaquina => textBox11.Text;
        public DateTime DataInstalacao => dateTimePicker1.Value.Date;

        public AddMaquinaForm()
        {
            InitializeComponent();
        }

        private void AddMaquinaForm_Load(object sender, EventArgs e)
        {

        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
