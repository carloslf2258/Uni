﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Contacts
{
    public partial class Stats: Form
    {

        string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";

        public Stats()
        {
            InitializeComponent();
        }

        private void Stats_Load(object sender, EventArgs e)
        {
            AtualizarNumeroSessoesAtivas();
            AtualizarTotalFichasVendidas();
            AtualizarFidelidadeStats();
            AtualizarTotalFaturado();
        }

        

        private void AtualizarNumeroSessoesAtivas()
        {
            string query = "SELECT COUNT(*) FROM arcade.udf_listar_sessoes_ativas()";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        int count = (int)cmd.ExecuteScalar();
                        labelNSessoesAtivas.Text = $"{count}";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar sessões ativas: " + ex.Message);
            }
        }

        private void AtualizarTotalFichasVendidas()
        {
            string query = "SELECT arcade.udf_total_fichas_vendidas()";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    object result = command.ExecuteScalar();

                    int totalFichas = (result != DBNull.Value) ? Convert.ToInt32(result) : 0;
                    labelNFichas_vendidas.Text = totalFichas.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao obter total de fichas vendidas: " + ex.Message);
                }
            }
        }

        private void AtualizarFidelidadeStats()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                labelNOuro.Text = ObterNumeroJogadoresFidelidade(conn, "Ouro").ToString();
                labelNPrata.Text = ObterNumeroJogadoresFidelidade(conn, "Prata").ToString();
                labelNBronze.Text = ObterNumeroJogadoresFidelidade(conn, "Bronze").ToString();
            }
        }

        private int ObterNumeroJogadoresFidelidade(SqlConnection conn, string fidelidade)
        {
            using (SqlCommand cmd = new SqlCommand("SELECT arcade.udf_total_jogadores_por_fidelidade(@nome)", conn))
            {
                cmd.Parameters.AddWithValue("@nome", fidelidade);
                object result = cmd.ExecuteScalar();
                return result != DBNull.Value ? Convert.ToInt32(result) : 0;
            }
        }

        private void AtualizarTotalFaturado()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT arcade.udf_total_faturado()", conn))
                {
                    object result = cmd.ExecuteScalar();
                    decimal total = result != DBNull.Value ? Convert.ToDecimal(result) : 0;
                    labelNFaturado.Text = total.ToString("C"); // "C" formata como moeda
                }
            }
        }

    }
}
