use ArcadeDB;
go

-- Stored Procedures
-- NOTE: os IDs t�m de ser controlados manualmente (sem gera��o de IDs)

-- To add Jogadores
GO
CREATE OR ALTER PROC arcade.sp_add_jogador
    @ID_jogador INT,
    @Nome VARCHAR(100),
    @Email VARCHAR(100) = NULL,
    @Telefone VARCHAR(20) = NULL,
    @Pontuacao_total INT = 0,
    @ID_programa_fidelidade INT = 2001
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        INSERT INTO arcade.Jogador (
            ID_jogador, Nome, Email, Telefone, Pontuacao_total, ID_programa_fidelidade
        )
        VALUES (
            @ID_jogador, @Nome, @Email, @Telefone, @Pontuacao_total, @ID_programa_fidelidade
        );
    END TRY
    BEGIN CATCH
        DECLARE @Msg NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@Msg, 16, 1);
    END CATCH
END;
GO

-- to add Maquina
GO
CREATE PROC arcade.sp_add_maquina
    @ID_maquina INT,
    @Tipo VARCHAR(50),
    @Modelo VARCHAR(100),
    @Fabricante VARCHAR(100),
    @Status VARCHAR(50),
    @Data_instalacao DATE
AS
BEGIN
    INSERT INTO arcade.Maquina (
        ID_maquina, Tipo, Modelo, Fabricante, Status, Data_instalacao
    )
    VALUES (
        @ID_maquina, @Tipo, @Modelo, @Fabricante, @Status, @Data_instalacao
    );
END
GO

-- to add funcionario
GO
CREATE OR ALTER PROC arcade.sp_add_funcionario
    @ID_funcionario INT,
    @Nome VARCHAR(100),
    @Cargo VARCHAR(50) = NULL,
    @Turno VARCHAR(20) = NULL,
    @Salario INT = NULL,
    @Contacto VARCHAR(100) = NULL,
    @ID_manutencao INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO arcade.Funcionario (
        ID_funcionario, Nome, Cargo, Turno, Salario, Contacto, ID_manutencao
    )
    VALUES (
        @ID_funcionario, @Nome, @Cargo, @Turno, @Salario, @Contacto, @ID_manutencao
    );
END
GO

-- to add gerente
GO
CREATE PROC arcade.sp_add_gerente
    @ID_gerente INT,
    @Data_inicio DATE,
    @Data_fim DATE = NULL,
    @Responsabilidade VARCHAR(255),
    @ID_evento INT
AS
BEGIN
    INSERT INTO arcade.Gerente (
        ID_gerente, Data_inicio, Data_fim, Responsabilidade, ID_evento
    )
    VALUES (
        @ID_gerente, @Data_inicio, @Data_fim, @Responsabilidade, @ID_evento
    );
END
GO

-- to add manuten��o
GO
CREATE PROC arcade.sp_add_manutencao
    @ID_manutencao INT,
    @Tipo VARCHAR(50),
    @Data_inicio DATE,
    @Data_fim DATE = NULL,
    @Descricao VARCHAR(255),
    @Status VARCHAR(50),
    @ID_maquina INT,
    @ID_funcionario INT
AS
BEGIN
    INSERT INTO arcade.Manutencao (
        ID_manutencao, Tipo, Data_inicio, Data_fim, Descricao, Status, ID_maquina, ID_funcionario
    )
    VALUES (
        @ID_manutencao, @Tipo, @Data_inicio, @Data_fim, @Descricao, @Status, @ID_maquina, @ID_funcionario
    );
END
GO

/*
-- Exemplo de utiliza��o
EXEC arcade.sp_add_maquina 
    @ID_maquina = 1007, 
    @Tipo = 'Puzzle', 
    @Nome_jogo = 'Tetris', 
    @Fabricante = 'Sega', 
    @Estado = 'Operacional', 
    @Data_aquisicao = '2024-05-20';

EXEC arcade.sp_add_funcionario 
    @ID_funcionario = 4004, 
    @Nome = 'Luis Braga', 
    @Cargo = 'T�cnico', 
    @Turno = 'Noite', 
    @Salario = 950.00, 
    @Email = 'luis@arcade.pt';

EXEC arcade.sp_add_gerente
    @ID_gerente = 8003,
    @Data_inicio = '2024-01-01',
    @Responsabilidades = 'Gest�o geral',
    @ID_evento = 6002;

EXEC arcade.sp_add_manutencao
    @ID_manutencao = 5004,
    @Tipo = 'Preventiva',
    @Data_inicio = '2025-05-30',
    @Descricao = 'Limpeza e testes',
    @Estado = 'Agendada',
    @ID_maquina = 1001,
    @ID_funcionario = 4004;

*/

-- To UPDATE information

-- update Jogador
GO
CREATE OR ALTER PROCEDURE arcade.sp_atualizar_jogador
    @ID_jogador INT,
    @Nome VARCHAR(100),
    @Email VARCHAR(100),
    @Telefone VARCHAR(20),
    @Pontuacao_total INT
AS
BEGIN
    UPDATE arcade.Jogador
    SET
        Nome = @Nome,
        Email = @Email,
        Telefone = @Telefone,
        Pontuacao_total = @Pontuacao_total
    WHERE ID_jogador = @ID_jogador;
END;
GO

-- To update maquina
CREATE OR ALTER PROCEDURE arcade.sp_atualizar_maquina
    @ID_maquina INT,
    @Tipo VARCHAR(50),
    @Modelo VARCHAR(100),
    @Fabricante VARCHAR(100),
    @Status VARCHAR(50),
    @Data_instalacao DATE
AS
BEGIN
    UPDATE arcade.Maquina
    SET
        Tipo = @Tipo,
        Modelo = @Modelo,
        Fabricante = @Fabricante,
        Status = @Status,
        Data_instalacao = @Data_instalacao
    WHERE ID_maquina = @ID_maquina;
END;
go

-- To update Funcionario
CREATE PROCEDURE arcade.sp_atualizar_funcionario
    @ID_funcionario INT,
    @Nome VARCHAR(100),
    @Cargo VARCHAR(50),
    @Turno VARCHAR(20),
    @Salario INT,
    @Contacto VARCHAR(100),
    @ID_manutencao INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Verificar se o funcion�rio existe
        IF NOT EXISTS (
            SELECT 1 FROM arcade.Funcionario WHERE ID_funcionario = @ID_funcionario
        )
        BEGIN
            RAISERROR('Funcion�rio com o ID %d n�o existe.', 16, 1, @ID_funcionario);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        -- (Opcional) Verificar se o ID_manutencao existe, se n�o for NULL
        IF @ID_manutencao IS NOT NULL AND NOT EXISTS (
            SELECT 1 FROM arcade.Manutencao WHERE ID_manutencao = @ID_manutencao
        )
        BEGIN
            RAISERROR('Manuten��o com o ID %d n�o existe.', 16, 1, @ID_manutencao);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        -- Atualizar os dados do funcion�rio
        UPDATE arcade.Funcionario
        SET
            Nome = @Nome,
            Cargo = @Cargo,
            Turno = @Turno,
            Salario = @Salario,
            Contacto = @Contacto,
            ID_manutencao = @ID_manutencao
        WHERE
            ID_funcionario = @ID_funcionario;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        -- Em caso de erro, reverter e mostrar mensagem
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();

        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
GO



-- To delete Jogador
create PROCEDURE arcade.sp_eliminar_jogador
    @ID_jogador INT
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Eliminar carregamentos associados aos cards do jogador
        DELETE C
        FROM arcade.Carregamento C
        INNER JOIN arcade.Card_fichas CF ON C.ID_card_fichas = CF.ID_card_fichas
        WHERE CF.ID_jogador = @ID_jogador;

        -- Eliminar cards do jogador
        DELETE FROM arcade.Card_fichas
        WHERE ID_jogador = @ID_jogador;

        -- Eliminar sess�es do jogador
        DELETE FROM arcade.Sessao_jogo
        WHERE ID_jogador = @ID_jogador;

        -- Eliminar promo��es usufru�das
        DELETE FROM arcade.Usufrui_promocao
        WHERE ID_jogador = @ID_jogador;

        -- Finalmente, eliminar o jogador
        DELETE FROM arcade.Jogador
        WHERE ID_jogador = @ID_jogador;

        COMMIT;
    END TRY
    BEGIN CATCH
        ROLLBACK;
        THROW;
    END CATCH
END;
GO

-- To delete Maquina
GO
CREATE OR ALTER PROCEDURE arcade.sp_eliminar_maquina
    @ID_maquina INT
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Verifica se a m�quina existe
        IF NOT EXISTS (SELECT 1 FROM arcade.Maquina WHERE ID_maquina = @ID_maquina)
        BEGIN
            RAISERROR('M�quina com o ID fornecido n�o existe.', 16, 1);
            ROLLBACK;
            RETURN;
        END

        -- Eliminar sess�es de jogo associadas
        DELETE FROM arcade.Sessao_jogo
        WHERE ID_maquina = @ID_maquina;

        -- Eliminar manuten��es associadas
        DELETE FROM arcade.Manutencao
        WHERE ID_maquina = @ID_maquina;

        -- Eliminar a pr�pria m�quina
        DELETE FROM arcade.Maquina
        WHERE ID_maquina = @ID_maquina;

        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK;

        DECLARE @ErrorMessage NVARCHAR(4000), @ErrorSeverity INT, @ErrorState INT;
        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();

        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
go

-- To delete Funcionario
CREATE PROCEDURE arcade.sp_eliminar_funcionario
    @ID_funcionario INT
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Verificar se o funcion�rio existe
        IF NOT EXISTS (
            SELECT 1 FROM arcade.Funcionario WHERE ID_funcionario = @ID_funcionario
        )
        BEGIN
            RAISERROR('Funcion�rio com ID %d n�o existe.', 16, 1, @ID_funcionario);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        -- Verificar se h� depend�ncias em outras tabelas
        IF EXISTS (SELECT 1 FROM arcade.Card_fichas WHERE ID_funcionario = @ID_funcionario) OR
           EXISTS (SELECT 1 FROM arcade.Manutencao WHERE ID_funcionario = @ID_funcionario) OR
           EXISTS (SELECT 1 FROM arcade.Evento WHERE ID_funcionario = @ID_funcionario) OR
           EXISTS (SELECT 1 FROM arcade.Carregamento WHERE ID_funcionario = @ID_funcionario) OR
           EXISTS (SELECT 1 FROM arcade.G_Tem_F WHERE ID_funcionario = @ID_funcionario)
        BEGIN
            RAISERROR('N�o � poss�vel eliminar o funcion�rio porque existem depend�ncias em outras tabelas.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        -- Eliminar o funcion�rio
        DELETE FROM arcade.Funcionario
        WHERE ID_funcionario = @ID_funcionario;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();

        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
GO


-- To Funcionario carregar creditos em card de jogador
CREATE PROCEDURE arcade.sp_carregar_creditos
    @ID_jogador INT,
    @ID_funcionario INT,
    @Valor DECIMAL(6,2),
    @Creditos INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ID_card_fichas INT;

    -- Obter o ID do card do jogador
    SELECT @ID_card_fichas = ID_card_fichas
    FROM arcade.Card_fichas
    WHERE ID_jogador = @ID_jogador;

    IF @ID_card_fichas IS NULL
    BEGIN
        RAISERROR('Card de fichas n�o encontrado para este jogador.', 16, 1);
        RETURN;
    END

    -- Inserir no hist�rico de carregamentos
    INSERT INTO arcade.Carregamento (Valor, Creditos, ID_card_fichas, ID_funcionario)
    VALUES (@Valor, @Creditos, @ID_card_fichas, @ID_funcionario);

    -- Atualizar o card de fichas
    UPDATE arcade.Card_fichas
    SET 
        Fichas_atuais = Fichas_atuais + @Creditos,
        Data_ultimo_carregamento = GETDATE()
    WHERE ID_card_fichas = @ID_card_fichas;
END;
GO
