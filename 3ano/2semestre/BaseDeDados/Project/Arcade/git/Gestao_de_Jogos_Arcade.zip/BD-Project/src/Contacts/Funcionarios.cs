﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Contacts
{
    public partial class Funcionarios : Form
    {
        string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";
        private List<Funcionario> funcionarios = new List<Funcionario>();

        public Funcionarios()
        {
            InitializeComponent();
            this.Load += Funcionarios_Load;


            buttonOk.Visible = false;
            textBoxID.Visible = false;
            textBoxNome.Visible = false;
            textBoxCargo.Visible = false;
            textBoxTurno.Visible = false;
            textBoxSalario.Visible = false;
            textBoxContacto.Visible = false;
            textBoxIDManutencao.Visible = false;
            listBoxFuncionarios.SelectedIndexChanged += listBoxFuncionarios_SelectedIndexChanged;

        }

        private void Funcionarios_Load(object sender, EventArgs e)
        {
            CarregarFuncionarios();
        }

        private void CarregarFuncionarios()
        {
            funcionarios.Clear();
            listBoxFuncionarios.Items.Clear();

            string query = @"SELECT ID_funcionario, Nome, Cargo, Turno, Salario, Contacto, ID_manutencao FROM arcade.Funcionario";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            var funcionario = new Funcionario
                            {
                                ID_funcionario = (int)reader["ID_funcionario"],
                                Nome = reader["Nome"].ToString(),
                                Cargo = reader["Cargo"].ToString(),
                                Turno = reader["Turno"].ToString(),
                                Salario = (int)reader["Salario"],
                                Contacto = reader["Contacto"].ToString(),
                                ID_manutencao = reader["ID_manutencao"] != DBNull.Value ? (int?)reader["ID_manutencao"] : null
                            };
                            funcionarios.Add(funcionario);
                            listBoxFuncionarios.Items.Add(funcionario);
                        }

                        if (listBoxFuncionarios.Items.Count > 0)
                        {
                            listBoxFuncionarios.SelectedIndex = 0;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar funcionários: " + ex.Message);
            }
        }

        private void listBoxFuncionarios_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxFuncionarios.SelectedItem is Funcionario f)
            {
                labelID.Text = $"{f.ID_funcionario}";
                labelNome.Text = $" {f.Nome}";
                labelCargo.Text = $" {f.Cargo}";
                labelTurno.Text = $" {f.Turno}";
                labelSalario.Text = $" {f.Salario}";
                labelContacto.Text = $" {f.Contacto}";
                labelIDManutencao.Text = $" {(f.ID_manutencao.HasValue ? f.ID_manutencao.Value.ToString() : "—")}";
            }
        }

        private void buttonEditar_Click_1(object sender, EventArgs e)
        {
            bool modoEdicao = !textBoxNome.Visible;

            if (modoEdicao && listBoxFuncionarios.SelectedItem is Funcionario f)
            {
                textBoxNome.Text = f.Nome;
                textBoxCargo.Text = f.Cargo;
                textBoxTurno.Text = f.Turno;
                textBoxSalario.Text = f.Salario.ToString();
                textBoxContacto.Text = f.Contacto;
                textBoxIDManutencao.Text = f.ID_manutencao.HasValue ? f.ID_manutencao.Value.ToString() : "";
            }

            labelNome.Visible = !modoEdicao;
            labelCargo.Visible = !modoEdicao;
            labelTurno.Visible = !modoEdicao;
            labelSalario.Visible = !modoEdicao;
            labelContacto.Visible = !modoEdicao;
            labelIDManutencao.Visible = !modoEdicao;

            textBoxNome.Visible = modoEdicao;
            textBoxCargo.Visible = modoEdicao;
            textBoxTurno.Visible = modoEdicao;
            textBoxSalario.Visible = modoEdicao;
            textBoxContacto.Visible = modoEdicao;
            textBoxIDManutencao.Visible = modoEdicao;
            buttonOk.Visible = modoEdicao;
        }


        private void buttonOk_Click_1(object sender, EventArgs e)
        {
            if (!int.TryParse(labelID.Text.Trim(), out int idFuncionario))
            {
                MessageBox.Show("ID inválido.");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("arcade.sp_atualizar_funcionario", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ID_funcionario", idFuncionario);
                cmd.Parameters.AddWithValue("@Nome", textBoxNome.Text.Trim());
                cmd.Parameters.AddWithValue("@Cargo", textBoxCargo.Text.Trim());
                cmd.Parameters.AddWithValue("@Turno", textBoxTurno.Text.Trim());
                cmd.Parameters.AddWithValue("@Salario", int.Parse(textBoxSalario.Text.Trim()));
                cmd.Parameters.AddWithValue("@Contacto", textBoxContacto.Text.Trim());

                if (int.TryParse(textBoxIDManutencao.Text.Trim(), out int idMan))
                    cmd.Parameters.AddWithValue("@ID_manutencao", idMan);
                else
                    cmd.Parameters.AddWithValue("@ID_manutencao", DBNull.Value);

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Funcionário atualizado com sucesso.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao atualizar funcionário: " + ex.Message);
                }
            }

            // Voltar ao modo visualização
            textBoxNome.Visible = false;
            textBoxCargo.Visible = false;
            textBoxTurno.Visible = false;
            textBoxSalario.Visible = false;
            textBoxContacto.Visible = false;
            textBoxIDManutencao.Visible = false;
            buttonOk.Visible = false;

            labelNome.Visible = true;
            labelCargo.Visible = true;
            labelTurno.Visible = true;
            labelSalario.Visible = true;
            labelContacto.Visible = true;
            labelIDManutencao.Visible = true;

            CarregarFuncionarios();
        }

        private void buttonEliminar_Click_1(object sender, EventArgs e)
        {
            if (!int.TryParse(labelID.Text.Trim(), out int idFuncionario))
            {
                MessageBox.Show("ID inválido.");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("arcade.sp_eliminar_funcionario", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ID_funcionario", idFuncionario);

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Funcionário eliminado com sucesso.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao eliminar funcionário: " + ex.Message);
                }
            }

            CarregarFuncionarios();
        }



        private void buttonAdicionar_Click(object sender, EventArgs e)
        {
            textBoxID.Visible = true;
            // 1. Validar ID e Nome
            if (!int.TryParse(textBoxID.Text.Trim(), out int idFuncionario))
            {
                MessageBox.Show("ID do funcionário inválido.");
                return;
            }

            string nome = textBoxNome.Text.Trim();
            if (string.IsNullOrEmpty(nome))
            {
                MessageBox.Show("O nome do funcionário é obrigatório.");
                return;
            }

            // 2. Obter os restantes campos (podem ser nulos)
            string cargo = string.IsNullOrWhiteSpace(textBoxCargo.Text) ? null : textBoxCargo.Text.Trim();
            string turno = string.IsNullOrWhiteSpace(textBoxTurno.Text) ? null : textBoxTurno.Text.Trim();
            string contacto = string.IsNullOrWhiteSpace(textBoxContacto.Text) ? null : textBoxContacto.Text.Trim();

            int? salario = null;
            if (int.TryParse(textBoxSalario.Text.Trim(), out int parsedSalario))
                salario = parsedSalario;

            int? idManutencao = null;
            if (int.TryParse(textBoxIDManutencao.Text.Trim(), out int parsedMan))
                idManutencao = parsedMan;

            // 3. Chamada ao stored procedure
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("arcade.sp_add_funcionario", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ID_funcionario", idFuncionario);
                cmd.Parameters.AddWithValue("@Nome", nome);

                cmd.Parameters.AddWithValue("@Cargo", (object)cargo ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@Turno", (object)turno ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@Salario", (object)salario ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@Contacto", (object)contacto ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ID_manutencao", (object)idManutencao ?? DBNull.Value);

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Funcionário adicionado com sucesso.");
                    CarregarFuncionarios(); // Atualiza a lista
                    textBoxID.Visible = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao adicionar funcionário: " + ex.Message);
                }
            }
        }


    }

    public class Funcionario
    {
        public int ID_funcionario { get; set; }
        public string Nome { get; set; }
        public string Cargo { get; set; }
        public string Turno { get; set; }
        public int Salario { get; set; }
        public string Contacto { get; set; }
        public int? ID_manutencao { get; set; }

        public override string ToString()
        {
            return $"{ID_funcionario} - {Nome}";
        }
    }
}
