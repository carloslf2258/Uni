use ArcadeDB;
go

drop function arcade.udf_listar_jogadores;
drop function arcade.udf_listar_maquinas;
drop function arcade.udf_listar_eventos;
drop function arcade.udf_listar_maquinas_em_manutencao;
drop function arcade.udf_listar_promocoes_ativas;
drop function arcade.udf_listar_sessoes_ativas;

drop function arcade.udf_listar_fidelidades;
drop function arcade.udf_total_fichas_vendidas;
drop function arcade.udf_total_jogadores_por_fidelidade;
drop function arcade.udf_total_faturado;

drop function arcade.udf_get_nome_jogador;
drop function arcade.udf_get_credito_jogador;
drop function arcade.udf_get_pontuacao_total;

drop function arcade.udf_top_jogadores_fichas;
drop function arcade.udf_top_jogadores_pontuacao;

drop function arcade.udf_listar_fidelidades_ativas;