﻿using System;
using System.Windows.Forms;

namespace Contacts
{
    public partial class AddJogadorForm : Form
    {
        private System.Windows.Forms.TextBox textBoxTelefone;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxNome;
        private System.Windows.Forms.TextBox textBoxID;
        private Label labelID;
        private Label labelNome;
        private Label labelEmail;
        private Label labelTelefone;
        private Label labelPontuacaoTotal;
        private System.Windows.Forms.TextBox textBoxPontTotal;
        private System.Windows.Forms.TextBox textBoxProgramaFidelidade;
        private Label labelProgramaFidelidade;
        private System.Windows.Forms.Button buttonOk;

        public int ID_jogador => int.Parse(textBoxID.Text);
        public string Nome => textBoxNome.Text.Trim();
        public string Email => textBoxEmail.Text.Trim();
        public string Telefone => textBoxTelefone.Text.Trim();
        public int? PontuacaoTotal => int.Parse(textBoxPontTotal.Text);
        public int? ID_Programa_Fidelidade => int.Parse(textBoxProgramaFidelidade.Text);

        public AddJogadorForm()
        {
            InitializeComponent();
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            // Validação simples
            if (!int.TryParse(textBoxID.Text, out _) ||
                string.IsNullOrWhiteSpace(textBoxNome.Text) ||
                !int.TryParse(textBoxPontTotal.Text, out _) ||
                !int.TryParse(textBoxProgramaFidelidade.Text, out _))
            {
                MessageBox.Show("Preencha corretamente todos os campos obrigatórios.");
                return;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void InitializeComponent()
        {
            this.textBoxTelefone = new System.Windows.Forms.TextBox();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxNome = new System.Windows.Forms.TextBox();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.buttonOk = new System.Windows.Forms.Button();
            this.labelID = new System.Windows.Forms.Label();
            this.labelNome = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.labelTelefone = new System.Windows.Forms.Label();
            this.labelPontuacaoTotal = new System.Windows.Forms.Label();
            this.textBoxPontTotal = new System.Windows.Forms.TextBox();
            this.textBoxProgramaFidelidade = new System.Windows.Forms.TextBox();
            this.labelProgramaFidelidade = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxTelefone
            // 
            this.textBoxTelefone.Location = new System.Drawing.Point(255, 214);
            this.textBoxTelefone.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxTelefone.Name = "textBoxTelefone";
            this.textBoxTelefone.Size = new System.Drawing.Size(132, 22);
            this.textBoxTelefone.TabIndex = 21;
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(255, 169);
            this.textBoxEmail.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(132, 22);
            this.textBoxEmail.TabIndex = 20;
            // 
            // textBoxNome
            // 
            this.textBoxNome.Location = new System.Drawing.Point(255, 118);
            this.textBoxNome.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxNome.Name = "textBoxNome";
            this.textBoxNome.Size = new System.Drawing.Size(132, 22);
            this.textBoxNome.TabIndex = 19;
            // 
            // textBoxID
            // 
            this.textBoxID.Location = new System.Drawing.Point(255, 70);
            this.textBoxID.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.Size = new System.Drawing.Size(132, 22);
            this.textBoxID.TabIndex = 18;
            // 
            // buttonOk
            // 
            this.buttonOk.Location = new System.Drawing.Point(453, 388);
            this.buttonOk.Margin = new System.Windows.Forms.Padding(4);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(135, 49);
            this.buttonOk.TabIndex = 24;
            this.buttonOk.Text = "OK";
            this.buttonOk.UseVisualStyleBackColor = true;
            this.buttonOk.Click += new System.EventHandler(this.buttonOk_Click);
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Location = new System.Drawing.Point(130, 73);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(74, 16);
            this.labelID.TabIndex = 25;
            this.labelID.Text = "ID Jogador";
            this.labelID.Click += new System.EventHandler(this.labelID_Click);
            // 
            // labelNome
            // 
            this.labelNome.AutoSize = true;
            this.labelNome.Location = new System.Drawing.Point(130, 118);
            this.labelNome.Name = "labelNome";
            this.labelNome.Size = new System.Drawing.Size(44, 16);
            this.labelNome.TabIndex = 26;
            this.labelNome.Text = "Nome";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Location = new System.Drawing.Point(130, 169);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(41, 16);
            this.labelEmail.TabIndex = 27;
            this.labelEmail.Text = "Email";
            // 
            // labelTelefone
            // 
            this.labelTelefone.AutoSize = true;
            this.labelTelefone.Location = new System.Drawing.Point(130, 220);
            this.labelTelefone.Name = "labelTelefone";
            this.labelTelefone.Size = new System.Drawing.Size(61, 16);
            this.labelTelefone.TabIndex = 28;
            this.labelTelefone.Text = "Telefone";
            // 
            // labelPontuacaoTotal
            // 
            this.labelPontuacaoTotal.AutoSize = true;
            this.labelPontuacaoTotal.Location = new System.Drawing.Point(130, 284);
            this.labelPontuacaoTotal.Name = "labelPontuacaoTotal";
            this.labelPontuacaoTotal.Size = new System.Drawing.Size(71, 16);
            this.labelPontuacaoTotal.TabIndex = 29;
            this.labelPontuacaoTotal.Text = "Pont. Total";
            // 
            // textBoxPontTotal
            // 
            this.textBoxPontTotal.Location = new System.Drawing.Point(255, 281);
            this.textBoxPontTotal.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxPontTotal.Name = "textBoxPontTotal";
            this.textBoxPontTotal.Size = new System.Drawing.Size(132, 22);
            this.textBoxPontTotal.TabIndex = 30;
            // 
            // textBoxProgramaFidelidade
            // 
            this.textBoxProgramaFidelidade.Location = new System.Drawing.Point(255, 337);
            this.textBoxProgramaFidelidade.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxProgramaFidelidade.Name = "textBoxProgramaFidelidade";
            this.textBoxProgramaFidelidade.Size = new System.Drawing.Size(132, 22);
            this.textBoxProgramaFidelidade.TabIndex = 31;
            // 
            // labelProgramaFidelidade
            // 
            this.labelProgramaFidelidade.AutoSize = true;
            this.labelProgramaFidelidade.Location = new System.Drawing.Point(130, 343);
            this.labelProgramaFidelidade.Name = "labelProgramaFidelidade";
            this.labelProgramaFidelidade.Size = new System.Drawing.Size(107, 16);
            this.labelProgramaFidelidade.TabIndex = 32;
            this.labelProgramaFidelidade.Text = "Prog. Fidelidade";
            // 
            // AddJogadorForm
            // 
            this.ClientSize = new System.Drawing.Size(601, 450);
            this.Controls.Add(this.labelProgramaFidelidade);
            this.Controls.Add(this.textBoxProgramaFidelidade);
            this.Controls.Add(this.textBoxPontTotal);
            this.Controls.Add(this.labelPontuacaoTotal);
            this.Controls.Add(this.labelTelefone);
            this.Controls.Add(this.labelEmail);
            this.Controls.Add(this.labelNome);
            this.Controls.Add(this.labelID);
            this.Controls.Add(this.buttonOk);
            this.Controls.Add(this.textBoxTelefone);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.textBoxNome);
            this.Controls.Add(this.textBoxID);
            this.Name = "AddJogadorForm";
            this.Load += new System.EventHandler(this.AddJogadorForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void labelID_Click(object sender, EventArgs e)
        {

        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void AddJogadorForm_Load(object sender, EventArgs e)
        {

        }
    }
}
