﻿using System;

namespace Contacts
{
    partial class Maquinas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAdicionar = new System.Windows.Forms.Button();
            this.listBoxMaquinas = new System.Windows.Forms.ListBox();
            this.textBoxDataInstalacao = new System.Windows.Forms.TextBox();
            this.textBoxStatus = new System.Windows.Forms.TextBox();
            this.textBoxFabricante = new System.Windows.Forms.TextBox();
            this.textBoxModelo = new System.Windows.Forms.TextBox();
            this.textBoxTipo = new System.Windows.Forms.TextBox();
            this.labelDataInstalacao = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.labelStatus = new System.Windows.Forms.Label();
            this.labelfabricante = new System.Windows.Forms.Label();
            this.labelModelo = new System.Windows.Forms.Label();
            this.labelTipo = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelID = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonEditar = new System.Windows.Forms.Button();
            this.buttonOk = new System.Windows.Forms.Button();
            this.buttonEliminar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonAdicionar
            // 
            this.buttonAdicionar.Location = new System.Drawing.Point(924, 493);
            this.buttonAdicionar.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAdicionar.Name = "buttonAdicionar";
            this.buttonAdicionar.Size = new System.Drawing.Size(117, 39);
            this.buttonAdicionar.TabIndex = 1;
            this.buttonAdicionar.Text = "Adicionar";
            this.buttonAdicionar.UseVisualStyleBackColor = true;
            this.buttonAdicionar.Click += new System.EventHandler(this.buttonAdicionar_Click);
            // 
            // listBoxMaquinas
            // 
            this.listBoxMaquinas.FormattingEnabled = true;
            this.listBoxMaquinas.ItemHeight = 16;
            this.listBoxMaquinas.Location = new System.Drawing.Point(16, 16);
            this.listBoxMaquinas.Name = "listBoxMaquinas";
            this.listBoxMaquinas.Size = new System.Drawing.Size(369, 516);
            this.listBoxMaquinas.TabIndex = 2;
            this.listBoxMaquinas.SelectedIndexChanged += new System.EventHandler(this.listBoxJogadores_SelectedIndexChanged);
            // 
            // textBoxDataInstalacao
            // 
            this.textBoxDataInstalacao.Location = new System.Drawing.Point(585, 290);
            this.textBoxDataInstalacao.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxDataInstalacao.Name = "textBoxDataInstalacao";
            this.textBoxDataInstalacao.Size = new System.Drawing.Size(132, 22);
            this.textBoxDataInstalacao.TabIndex = 36;
            // 
            // textBoxStatus
            // 
            this.textBoxStatus.Location = new System.Drawing.Point(603, 232);
            this.textBoxStatus.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxStatus.Name = "textBoxStatus";
            this.textBoxStatus.Size = new System.Drawing.Size(132, 22);
            this.textBoxStatus.TabIndex = 35;
            // 
            // textBoxFabricante
            // 
            this.textBoxFabricante.Location = new System.Drawing.Point(547, 189);
            this.textBoxFabricante.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxFabricante.Name = "textBoxFabricante";
            this.textBoxFabricante.Size = new System.Drawing.Size(132, 22);
            this.textBoxFabricante.TabIndex = 34;
            // 
            // textBoxModelo
            // 
            this.textBoxModelo.Location = new System.Drawing.Point(530, 146);
            this.textBoxModelo.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxModelo.Name = "textBoxModelo";
            this.textBoxModelo.Size = new System.Drawing.Size(132, 22);
            this.textBoxModelo.TabIndex = 33;
            // 
            // textBoxTipo
            // 
            this.textBoxTipo.Location = new System.Drawing.Point(530, 104);
            this.textBoxTipo.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxTipo.Name = "textBoxTipo";
            this.textBoxTipo.Size = new System.Drawing.Size(132, 22);
            this.textBoxTipo.TabIndex = 32;
            // 
            // labelDataInstalacao
            // 
            this.labelDataInstalacao.AutoSize = true;
            this.labelDataInstalacao.Location = new System.Drawing.Point(563, 290);
            this.labelDataInstalacao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelDataInstalacao.Name = "labelDataInstalacao";
            this.labelDataInstalacao.Size = new System.Drawing.Size(51, 16);
            this.labelDataInstalacao.TabIndex = 31;
            this.labelDataInstalacao.Text = "label12";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(441, 290);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(101, 16);
            this.label11.TabIndex = 30;
            this.label11.Text = "Data Instalação";
            // 
            // labelStatus
            // 
            this.labelStatus.AutoSize = true;
            this.labelStatus.Location = new System.Drawing.Point(581, 232);
            this.labelStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new System.Drawing.Size(51, 16);
            this.labelStatus.TabIndex = 29;
            this.labelStatus.Text = "label10";
            // 
            // labelfabricante
            // 
            this.labelfabricante.AutoSize = true;
            this.labelfabricante.Location = new System.Drawing.Point(526, 193);
            this.labelfabricante.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelfabricante.Name = "labelfabricante";
            this.labelfabricante.Size = new System.Drawing.Size(44, 16);
            this.labelfabricante.TabIndex = 28;
            this.labelfabricante.Text = "label9";
            // 
            // labelModelo
            // 
            this.labelModelo.AutoSize = true;
            this.labelModelo.Location = new System.Drawing.Point(509, 150);
            this.labelModelo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelModelo.Name = "labelModelo";
            this.labelModelo.Size = new System.Drawing.Size(44, 16);
            this.labelModelo.TabIndex = 27;
            this.labelModelo.Text = "label8";
            // 
            // labelTipo
            // 
            this.labelTipo.AutoSize = true;
            this.labelTipo.Location = new System.Drawing.Point(509, 104);
            this.labelTipo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTipo.Name = "labelTipo";
            this.labelTipo.Size = new System.Drawing.Size(44, 16);
            this.labelTipo.TabIndex = 26;
            this.labelTipo.Text = "label7";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(441, 232);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 16);
            this.label6.TabIndex = 25;
            this.label6.Text = "Status";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(441, 193);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 16);
            this.label5.TabIndex = 24;
            this.label5.Text = "Fabricante";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(441, 150);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 16);
            this.label4.TabIndex = 23;
            this.label4.Text = "Modelo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(437, 104);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 16);
            this.label3.TabIndex = 22;
            this.label3.Text = "Tipo";
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Location = new System.Drawing.Point(495, 52);
            this.labelID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(44, 16);
            this.labelID.TabIndex = 21;
            this.labelID.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(437, 52);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 16);
            this.label1.TabIndex = 20;
            this.label1.Text = "ID";
            // 
            // buttonEditar
            // 
            this.buttonEditar.Location = new System.Drawing.Point(444, 494);
            this.buttonEditar.Margin = new System.Windows.Forms.Padding(4);
            this.buttonEditar.Name = "buttonEditar";
            this.buttonEditar.Size = new System.Drawing.Size(117, 38);
            this.buttonEditar.TabIndex = 37;
            this.buttonEditar.Text = "Editar";
            this.buttonEditar.UseVisualStyleBackColor = true;
            this.buttonEditar.Click += new System.EventHandler(this.buttonEditar_Click);
            // 
            // buttonOk
            // 
            this.buttonOk.Location = new System.Drawing.Point(924, 493);
            this.buttonOk.Margin = new System.Windows.Forms.Padding(4);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(117, 38);
            this.buttonOk.TabIndex = 38;
            this.buttonOk.Text = "Ok";
            this.buttonOk.UseVisualStyleBackColor = true;
            this.buttonOk.Click += new System.EventHandler(this.buttonOk_Click_1);
            // 
            // buttonEliminar
            // 
            this.buttonEliminar.Location = new System.Drawing.Point(584, 493);
            this.buttonEliminar.Margin = new System.Windows.Forms.Padding(4);
            this.buttonEliminar.Name = "buttonEliminar";
            this.buttonEliminar.Size = new System.Drawing.Size(119, 36);
            this.buttonEliminar.TabIndex = 39;
            this.buttonEliminar.Text = "Eliminar";
            this.buttonEliminar.UseVisualStyleBackColor = true;
            this.buttonEliminar.Click += new System.EventHandler(this.buttonEliminar_Click);
            // 
            // Maquinas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.buttonEliminar);
            this.Controls.Add(this.buttonOk);
            this.Controls.Add(this.buttonEditar);
            this.Controls.Add(this.textBoxDataInstalacao);
            this.Controls.Add(this.textBoxStatus);
            this.Controls.Add(this.textBoxFabricante);
            this.Controls.Add(this.textBoxModelo);
            this.Controls.Add(this.textBoxTipo);
            this.Controls.Add(this.labelDataInstalacao);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.labelStatus);
            this.Controls.Add(this.labelfabricante);
            this.Controls.Add(this.labelModelo);
            this.Controls.Add(this.labelTipo);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBoxMaquinas);
            this.Controls.Add(this.buttonAdicionar);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Maquinas";
            this.Text = "Maquinas";
            this.Load += new System.EventHandler(this.Maquinas_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
        }

        #endregion
        private System.Windows.Forms.Button buttonAdicionar;
        private System.Windows.Forms.ListBox listBoxMaquinas;
        private System.Windows.Forms.TextBox textBoxDataInstalacao;
        private System.Windows.Forms.TextBox textBoxStatus;
        private System.Windows.Forms.TextBox textBoxFabricante;
        private System.Windows.Forms.TextBox textBoxModelo;
        private System.Windows.Forms.TextBox textBoxTipo;
        private System.Windows.Forms.Label labelDataInstalacao;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label labelStatus;
        private System.Windows.Forms.Label labelfabricante;
        private System.Windows.Forms.Label labelModelo;
        private System.Windows.Forms.Label labelTipo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonEditar;
        private System.Windows.Forms.Button buttonOk;
        private System.Windows.Forms.Button buttonEliminar;
    }
}