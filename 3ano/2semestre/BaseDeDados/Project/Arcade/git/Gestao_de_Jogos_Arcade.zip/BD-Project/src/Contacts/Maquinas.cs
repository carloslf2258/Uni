﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Contacts
{
    public partial class Maquinas : Form
    {
        string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";

        public Maquinas()
        {
            InitializeComponent();
            // Adiciona o handler do Load aqui, se quiser
            this.Load += Maquinas_Load;

            // Esconder textBoxes para editar e botão ok
            textBoxTipo.Visible = false;
            textBoxModelo.Visible = false;
            textBoxFabricante.Visible = false;
            textBoxStatus.Visible = false;
            textBoxDataInstalacao.Visible = false;
            buttonOk.Visible = false;
        }

        private List<Maquina> maquinas = new List<Maquina>();
        private void Maquinas_Load(object sender, EventArgs e)
        {
            // Limpa listas antes de preencher novamente
            maquinas.Clear();
            listBoxMaquinas.Items.Clear();

            string query = "SELECT * FROM arcade.udf_listar_maquinas()";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                try
                {
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        var maquina = new Maquina
                        {
                            ID = (int)reader["ID_maquina"],
                            Tipo = reader["Tipo"].ToString(),
                            Modelo = reader["Modelo"].ToString(),
                            Fabricante = reader["Fabricante"].ToString(),
                            Status = reader["Status"].ToString(),
                            DataInstalacao = Convert.ToDateTime(reader["Data_instalacao"])
                        };
                        maquinas.Add(maquina);
                        listBoxMaquinas.Items.Add(maquina);
                    }
                    // Seleciona o primeiro jogador e carrega os dados
                    if (listBoxMaquinas.Items.Count > 0)
                    {
                        listBoxMaquinas.SelectedIndex = 0;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar máquinas: " + ex.Message);
                }
            }
        }

        private void buttonAdicionar_Click(object sender, EventArgs e)
        {
            using (var addForm = new AddMaquinaForm())
            {
                if (addForm.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        using (SqlConnection con = new SqlConnection(connectionString))
                        using (SqlCommand cmd = new SqlCommand("arcade.sp_add_maquina", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@ID_maquina", addForm.ID_maquina);
                            cmd.Parameters.AddWithValue("@Tipo", addForm.Tipo);
                            cmd.Parameters.AddWithValue("@Modelo", addForm.Modelo);
                            cmd.Parameters.AddWithValue("@Fabricante", addForm.Fabricante);
                            cmd.Parameters.AddWithValue("@Status", addForm.StatusMaquina);
                            cmd.Parameters.AddWithValue("@Data_instalacao", addForm.DataInstalacao);

                            con.Open();
                            cmd.ExecuteNonQuery();
                        }

                        Maquinas_Load(sender, e);   // refresca o DataGridView
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro ao adicionar máquina: " + ex.Message);
                    }
                }
            }
        }

        private void listBoxJogadores_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxMaquinas.SelectedItem is Maquina maquina)
            {
                labelID.Text = $"{maquina.ID}";
                labelTipo.Text = $" {maquina.Tipo}";
                labelModelo.Text = $" {maquina.Modelo}";
                labelfabricante.Text = $" {maquina.Fabricante}";
                labelStatus.Text = $" {maquina.Status}";
                labelDataInstalacao.Text = $" {maquina.DataInstalacao}";
            }
        }

        private void buttonEditar_Click(object sender, EventArgs e)
        {
            bool modoVisualizacao = !textBoxTipo.Visible;

            if (modoVisualizacao)
            {
                textBoxTipo.Text = labelTipo.Text.Trim();
                textBoxModelo.Text = labelModelo.Text.Trim();
                textBoxFabricante.Text = labelfabricante.Text.Trim();
                textBoxStatus.Text = labelStatus.Text.Trim();
                textBoxDataInstalacao.Text = labelDataInstalacao.Text.Trim(); // Pontuação
            }

            labelID.Visible = true;
            labelTipo.Visible = !modoVisualizacao;
            labelModelo.Visible = !modoVisualizacao;
            labelfabricante.Visible = !modoVisualizacao;
            labelStatus.Visible = !modoVisualizacao;
            labelDataInstalacao.Visible = !modoVisualizacao;

            textBoxTipo.Visible = modoVisualizacao;
            textBoxModelo.Visible = modoVisualizacao;
            textBoxFabricante.Visible = modoVisualizacao;
            textBoxStatus.Visible = modoVisualizacao;
            textBoxDataInstalacao.Visible = modoVisualizacao;

            // Mostrar botão OK apenas em modo edição
            buttonOk.Visible = modoVisualizacao;
        }



        private void buttonOk_Click_1(object sender, EventArgs e)
        {
            // Atualiza labels com os valores dos TextBoxes
            labelTipo.Text = textBoxTipo.Text.Trim();
            labelModelo.Text = textBoxModelo.Text.Trim();
            labelfabricante.Text = textBoxFabricante.Text.Trim();
            labelStatus.Text = textBoxStatus.Text.Trim();
            labelDataInstalacao.Text = textBoxDataInstalacao.Text.Trim();

            if (!int.TryParse(labelID.Text.Trim(), out int ID))
            {
                MessageBox.Show("ID da máquina inválido.");
                return;
            }

            string connectionString = @"Server=.\SQLEXPRESS;Database=ArcadeDB;Trusted_Connection=True;";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("arcade.sp_atualizar_maquina", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ID_maquina", ID);
                cmd.Parameters.AddWithValue("@Tipo", textBoxTipo.Text.Trim());
                cmd.Parameters.AddWithValue("@Modelo", textBoxModelo.Text.Trim());
                cmd.Parameters.AddWithValue("@Fabricante", textBoxFabricante.Text.Trim());
                cmd.Parameters.AddWithValue("@Status", textBoxStatus.Text.Trim());

                // Converter a data
                if (DateTime.TryParse(textBoxDataInstalacao.Text.Trim(), out DateTime dataInstalacao))
                {
                    cmd.Parameters.AddWithValue("@Data_instalacao", dataInstalacao);
                }
                else
                {
                    MessageBox.Show("Data de instalação inválida. Use o formato AAAA-MM-DD.");
                    return;
                }

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Máquina atualizada com sucesso.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao atualizar máquina: " + ex.Message);
                }
            }

            // Retornar ao modo visualização
            textBoxTipo.Visible = false;
            textBoxModelo.Visible = false;
            textBoxFabricante.Visible = false;
            textBoxStatus.Visible = false;
            textBoxDataInstalacao.Visible = false;
            buttonOk.Visible = false;

            labelTipo.Visible = true;
            labelModelo.Visible = true;
            labelfabricante.Visible = true;
            labelStatus.Visible = true;
            labelDataInstalacao.Visible = true;

            maquinas.Clear();
            listBoxMaquinas.Items.Clear();
            Maquinas_Load(sender, e);
        }

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(labelID.Text.Trim(), out int ID_maquina))
            {
                MessageBox.Show("ID da máquina inválido.");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("arcade.sp_eliminar_maquina", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ID_maquina", ID_maquina);

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Máquina eliminada com sucesso.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao eliminar máquina: " + ex.Message);
                }
            }

            maquinas.Clear();
            listBoxMaquinas.Items.Clear();
            Maquinas_Load(sender, e);
        }

    }
}
