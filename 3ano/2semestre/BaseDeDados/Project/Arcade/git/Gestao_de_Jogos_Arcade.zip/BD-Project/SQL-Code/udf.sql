use ArcadeDB;
go
/* Como usar:
SELECT * FROM arcade.udf_listar_jogadores();
SELECT * FROM arcade.udf_listar_maquinas();
SELECT * FROM arcade.udf_listar_eventos();
SELECT * FROM arcade.udf_listar_maquinas_em_manutencao();
SELECT * FROM arcade.udf_listar_promocoes_ativas();

SELECT * FROM arcade.udf_listar_sessoes();
SELECT * FROM arcade.udf_listar_sessoes_ativas();

SELECT * FROM arcade.udf_listar_fidelidades();
*/

-- Listar Jogadores
-- Devolve ID, Nome, Email, Tele, Pont.Total, Nome Prog Fidelidade, Fichas Atuais
GO
CREATE FUNCTION arcade.udf_listar_jogadores()
RETURNS TABLE
AS
RETURN
(
    SELECT 
        J.ID_jogador,
        J.Nome,
        J.Email,
        J.Telefone,
        J.Pontuacao_total,
        PF.Nome AS Programa_fidelidade,
        COALESCE(CF.Fichas_atuais, 0) AS Fichas_atuais
    FROM arcade.Jogador AS J
    LEFT JOIN arcade.Card_fichas AS CF ON CF.ID_jogador = J.ID_jogador
    LEFT JOIN arcade.Programa_fidelidade AS PF ON J.ID_programa_fidelidade = PF.ID_programa_fidelidade
);


GO
-- Listar Maquinas
CREATE FUNCTION arcade.udf_listar_maquinas()
RETURNS TABLE
AS
RETURN (
    SELECT 
        M.ID_maquina,
        M.Tipo,
        M.Modelo,
        M.Fabricante,
        M.Status,
        M.Data_instalacao
    FROM arcade.Maquina AS M
);


-- Listar Eventos
GO
CREATE FUNCTION arcade.udf_listar_eventos()
RETURNS TABLE
AS
RETURN
(
    SELECT 
        E.ID_evento,
        E.Nome,
        E.Data_inicio,
        E.Data_fim,
        E.Capacidade,
        E.Status,
        F.Nome AS Responsavel
    FROM arcade.Evento E
    JOIN arcade.Funcionario F ON E.ID_funcionario = F.ID_funcionario
);
GO

-- Listar M�quinas em Manuten��o
GO
CREATE FUNCTION arcade.udf_listar_maquinas_em_manutencao()
RETURNS TABLE
AS
RETURN
(
    SELECT 
        M.ID_maquina,
        MQ.Modelo,
        M.Tipo,
        M.Data_inicio,
        M.Data_fim,
        M.Descricao,
        M.Status
    FROM arcade.Manutencao M
    JOIN arcade.Maquina MQ ON M.ID_maquina = MQ.ID_maquina
    WHERE M.Status IN ('Ativa', 'Em progresso', 'Agendada') OR M.Data_fim IS NULL
);
GO

-- Listar Promocoes ativas
GO
CREATE FUNCTION arcade.udf_listar_promocoes_ativas()
RETURNS TABLE
AS
RETURN
(
    SELECT 
        P.ID_promocao,
        P.Nome,
        P.Tipo,
        P.Data_inicio,
        P.Data_fim,
        E.Nome AS Evento_associado
    FROM arcade.Promocao P
    JOIN arcade.Evento E ON P.ID_evento = E.ID_evento
    WHERE GETDATE() BETWEEN P.Data_inicio AND P.Data_fim
);
GO

-- Listar as Sess�es de jogo ativas ou interrompidas
create FUNCTION arcade.udf_listar_sessoes_ativas()
RETURNS TABLE
AS
RETURN (
    SELECT 
        SJ.ID_sessao,
        SJ.Tempo_jogado,
        SJ.Pontuacao_final,
        SJ.Status_sessao,
        SJ.Fichas,
        J.Nome AS Nome_jogador,
        M.Modelo AS Maquina
    FROM arcade.Sessao_jogo AS SJ
    JOIN arcade.Jogador AS J ON SJ.ID_jogador = J.ID_jogador
    JOIN arcade.Maquina AS M ON SJ.ID_maquina = M.ID_maquina
    WHERE SJ.Status_sessao IN ('Ativa', 'Interrompida')
);
go

select * from arcade.udf_listar_sessoes_ativas();

-- Listar Programas fidelidade
CREATE FUNCTION arcade.udf_listar_fidelidades()
RETURNS TABLE
AS
RETURN (
    SELECT 
        PF.ID_programa_fidelidade,
        PF.Nome,
        PF.Descricao,
        PF.Tipo,
        PF.Requisitos,
        PF.Data_inicio,
		PF.Data_fim
    FROM arcade.Programa_fidelidade AS PF
);


go
-- Total fichas vendidas no Arcade
CREATE FUNCTION arcade.udf_total_fichas_vendidas()
RETURNS INT
AS
BEGIN
    DECLARE @total INT;

    SELECT @total = SUM(Creditos)
    FROM arcade.Carregamento;

    RETURN ISNULL(@total, 0);
END;

go
-- Total Jogadores por Fidelidade
CREATE FUNCTION arcade.udf_total_jogadores_por_fidelidade (@NomeFidelidade VARCHAR(100))
RETURNS INT
AS
BEGIN
    DECLARE @Total INT;

    SELECT @Total = COUNT(*)
    FROM arcade.Jogador J
    JOIN arcade.Programa_fidelidade PF ON J.ID_programa_fidelidade = PF.ID_programa_fidelidade
    WHERE PF.Nome = @NomeFidelidade;

    RETURN ISNULL(@Total, 0);
END;
go

-- Total faturado (somar Valor Carregamento)
CREATE FUNCTION arcade.udf_total_faturado()
RETURNS DECIMAL(10, 2)
AS
BEGIN
    DECLARE @total DECIMAL(10, 2);

    SELECT @total = SUM(Valor)
    FROM arcade.Carregamento;

    RETURN ISNULL(@total, 0);
END;
go

-- Obter Nome de Jogador
CREATE FUNCTION arcade.udf_get_nome_jogador (@id INT)
RETURNS VARCHAR(100)
AS
BEGIN
    DECLARE @nome VARCHAR(100);

    SELECT @nome = Nome
    FROM arcade.Jogador
    WHERE ID_jogador = @id;

    RETURN @nome;
END;
go

CREATE FUNCTION arcade.udf_get_credito_jogador(@idJogador INT)
RETURNS INT
AS
BEGIN
    DECLARE @credito INT;

    SELECT @credito = CF.Fichas_atuais
    FROM arcade.Card_fichas AS CF
    WHERE CF.ID_jogador = @idJogador;

    RETURN @credito;
END;
go

CREATE FUNCTION arcade.udf_get_pontuacao_total(@idJogador INT)
RETURNS INT
AS
BEGIN
    DECLARE @pontos INT;

    SELECT @pontos = J.Pontuacao_total
    FROM arcade.Jogador AS J
    WHERE J.ID_jogador = @idJogador;

    RETURN @pontos;
END;
GO

-- top jogadores com mais fichas (creditos)
CREATE FUNCTION arcade.udf_top_jogadores_fichas(@topN INT)
RETURNS TABLE
AS
RETURN (
    SELECT TOP (@topN)
        J.ID_jogador,
        J.Nome,
        COALESCE(CF.Fichas_atuais, 0) AS Fichas_atuais
    FROM arcade.Jogador J
    LEFT JOIN arcade.Card_fichas CF ON J.ID_jogador = CF.ID_jogador
    ORDER BY Fichas_atuais DESC
);
go

-- Top jogadores com mais pontos em total
GO
CREATE FUNCTION arcade.udf_top_jogadores_pontuacao(@topN INT)
RETURNS TABLE
AS
RETURN (
    SELECT TOP (@topN)
        J.ID_jogador,
        J.Nome,
        J.Pontuacao_total
    FROM arcade.Jogador J
    ORDER BY J.Pontuacao_total DESC
);
GO

-- Fidelidade ativa (por data)
CREATE FUNCTION arcade.udf_listar_fidelidades_ativas()
RETURNS TABLE
AS
RETURN (
    SELECT *
    FROM arcade.Programa_fidelidade
    WHERE GETDATE() BETWEEN Data_inicio AND ISNULL(Data_fim, GETDATE())
);
GO


-- Sess�es de um Jogador espec�fico
GO
CREATE FUNCTION arcade.udf_sessoes_por_jogador(@idJogador INT)
RETURNS TABLE
AS
RETURN (
    SELECT 
        SJ.ID_sessao,
        SJ.Tempo_jogado,
        SJ.Pontuacao_final,
        SJ.Status_sessao,
        SJ.Fichas,
        M.Modelo AS Maquina
    FROM arcade.Sessao_jogo SJ
    JOIN arcade.Maquina M ON SJ.ID_maquina = M.ID_maquina
    WHERE SJ.ID_jogador = @idJogador
);

