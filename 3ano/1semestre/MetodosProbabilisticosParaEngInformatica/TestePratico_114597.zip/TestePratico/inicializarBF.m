function BF = inicializarBF(n)
% n : Número de posições ou células do filtro
% Inicializa o Bloom Filter

BF = zeros(n, 1, 'uint8');

end