[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/n4Xu0y1X)
[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-2e0aaae1b6195c2367325f4f02e2d04e9abb55f0b24a779b69b11b9e10269abc.svg)](https://classroom.github.com/online_ide?assignment_repo_id=17062867&assignment_repo_type=AssignmentRepo)
# sio_2425_project

# Group members
- José Fernandes, n114472, jbfernandes@ua.pt
- Diogo Carvalho, n113221, diogo.tav.carvalho@ua.pt
- Carlos Verenzuela, n114597, carlos.verenzuela@ua.pt

