import os
import sys
import argparse
import logging
import json
import requests
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.hashes import SHA256
import base64
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import hashes

logging.basicConfig(format='%(levelname)s\t- %(message)s')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def load_state():
    state = {}
    state_dir = os.path.join(os.path.expanduser('~'), '.sio')
    state_file = os.path.join(state_dir, 'state.json')

    logger.debug('State folder: ' + state_dir)
    logger.debug('State file: ' + state_file)

    if os.path.exists(state_file):
        logger.debug('Loading state')
        with open(state_file,'r') as f:
            state = json.loads(f.read())

    if state is None:
        state = {}

    return state

def parse_env(state):
    if 'REP_ADDRESS' in os.environ:
        state['REP_ADDRESS'] = os.getenv('REP_ADDRESS')
        logger.debug('Setting REP_ADDRESS from Environment to: ' + state['REP_ADDRESS'])

    if 'REP_PUB_KEY' in os.environ:
        rep_pub_key = os.getenv('REP_PUB_KEY')
        logger.debug('Loading REP_PUB_KEY fron: ' + state['REP_PUB_KEY'])
        if os.path.exists(rep_pub_key):
            with open(rep_pub_key, 'r') as f:
                state['REP_PUB_KEY'] = f.read()
                logger.debug('Loaded REP_PUB_KEY from Environment')
    return state

def parse_args(state):
    parser = argparse.ArgumentParser()

    parser.add_argument("-k", '--key', nargs=1, help="Path to the key file")
    parser.add_argument("-r", '--repo', nargs=1, help="Address:Port of the repository")
    parser.add_argument("-v", '--verbose', help="Increase verbosity", action="store_true")
    parser.add_argument("-c", "--command", help="Command to execute")
    parser.add_argument('arg0', nargs='?', default=None)
    parser.add_argument('arg1', nargs='?', default=None)
    parser.add_argument('arg2', nargs='?', default=None)
    parser.add_argument('arg3', nargs='?', default=None)
    parser.add_argument('arg4', nargs='?', default=None)
    parser.add_argument('arg5', nargs='?', default=None)

    # Optional arguments for add document, I dont know how to do this better
    parser.add_argument("-s", "--username", help="Username for the session", default=None)
    parser.add_argument("-d", "--date", choices=["nt", "ot", "et"], help="Date type (nt, ot, or et)", default=None)
    parser.add_argument("date_value", help="The date value in format DD-MM-YYYY", nargs="?", default=None)

    args = parser.parse_args()
    if args.verbose:
        logger.setLevel(logging.DEBUG)
        logger.info('Setting log level to DEBUG')

    if args.key:
        if not os.path.exists(args.key[0]) or not os.isfile(args.key[0]):
            logger.error(f'Key file not found or invalid: {args.key[0]}')
            sys.exit(-1)

        with open(args.key[0], 'r') as f:
            state['REP_PUB_KEY'] = f.read()
            logger.info('Overriding REP_PUB_KEY from command line')

    if args.repo:
        state['REP_ADDRESS'] = args.repo[0]
        logger.info('Overriding REP_ADDRESS from command line')

    if args.command:
        logger.info("Command: " + args.command)

    return state, {'command': args.command, 'arg0': args.arg0, 'arg1': args.arg1, 'arg2': args.arg2, 'arg3': args.arg3, 'arg4': args.arg4, 'arg5': args.arg5}

def save(state):
    state_dir = os.path.join(os.path.expanduser('~'), '.sio')
    state_file = os.path.join(state_dir, 'state.json')

    if not os.path.exists(state_dir):
        logger.debug('Creating state folder')
        os.mkdir(state_dir)

    with open(state_file, 'w') as f:
        f.write(json.dumps(state, indent=4))

state = load_state()
state = parse_env(state)
state, args = parse_args(state)

if 'REP_ADDRESS' not in state:
    logger.error("Must define Repository Address")
    sys.exit(-1)

# NOT IMPLEMENTED YET
#if 'REP_PUB_KEY' not in state:
#  logger.error("Must set the Repository Public Key")
#  sys.exit(-1)

""" Do something """
logger.debug("Arguments: " + str(args))

# OTHERS

def request_pub_key():
    url = state['REP_ADDRESS'] + '/key/request'
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()["public_key"]
    else:
        print(response.text)
        return None

def check_client_keys():
    if not os.path.exists("./keys/private_key.pem") or not os.path.exists("./keys/public_key.pem"):
        return False
    return True

def check_server_keys():
    if not os.path.exists("./keys/server_public_key.pem"):
        return False
    return True

# ORGANIZATIONS

#rep_create_org <organization> <username> <name> <email> <public key file>
def rep_create_org(org, username, name, email, pubkey):
    print("rep_create_org: org=%s, username=%s, name=%s, email=%s, pubkey=%s" % (org, username, name, email, pubkey))
    url = state['REP_ADDRESS'] + '/organization/create'
    headers = {"Content-Type": "application/json"}
    data = {
        "org": org,
        "username": username,
        "name": name,
        "email": email,
        "pubkey": pubkey
    }

    response = requests.post(url, headers=headers, data=json.dumps(data))

    print(response.status_code)
    print(response.json())

#rep_list_orgs
def rep_list_orgs():
    print("rep_list_orgs")
    url = state['REP_ADDRESS'] + '/organization/list'

    response = requests.get(url)

    print(response.status_code)
    print(response.json())

#rep_get_file
def rep_get_file(file_handle, file_name=None):
    print("rep_get_file")
    url = state['REP_ADDRESS'] + '/file/get'

    params = {"file_handle" : file_handle}
    response = requests.get(url, params=params)
    print("Response status code: "+str(response.status_code))
    if response.status_code == 200:
        if not file_name:
            print(response.text)
            return
        try:
            with open(file_name, 'wb') as f:
                f.write(response.text)
        except Exception as e:
            print(e)
        print(response.text)


# DOCUMENTS

# rep_add_doc <session file> <document name> <file>
def rep_add_doc(session_file, document_name, file):
    print("document_name=%s" % (document_name))
    url = state['REP_ADDRESS'] + '/document/add'
    headers = {"Content-Type": "application/json"}

    try:
        #files = {'doc_file': open(file,'rb'), 'session_file': open(session_file,'r')}    sou mesmo mesmo mesmo mesmo mesmo mesmo burro
        files = {'doc_file': open(file,'rb')}
    except Exception as e:
        print(e)
        return
    
    with open( session_file, 'r' ) as f:               
        session = f.read()
    session = json.loads(session) 

    data = {
        "session_file": session,
        "document_name": document_name
    }

    response = requests.post(url, headers=headers, files=files, data=json.dumps(data))

    print(response.status_code)
    print(response.json())

# rep_list_docs <session file> [ -s username] [ -d nt/ot/et ]
def rep_list_docs(session_file, username=None, date_filter=None, date=None):
    print("rep_list_docs")
    url = state['REP_ADDRESS'] + '/document/list'

    with open( session_file, 'r' ) as f:               
        session = f.read()
    session = json.loads(session) 

    params = {
        "session_file": session,
        "username": username,
        "date_filter": date_filter,
        "date": date
    }

    response = requests.get(url, params=params)

    print(response.status_code)
    print(response.json())

def rep_get_doc(session_file, doc_name):
    print("rep_get_doc")
    url = state['REP_ADDRESS'] + '/document/get'

    with open( session_file, 'r' ) as f:                   
        session = f.read()
    session = json.loads(session) 

    params = {
        "session_file": session,
        "doc_name": doc_name
    }

    response = requests.get(url, params=params)

    print(response.status_code)
    print(response.json())

def rep_get_doc_metadata(session_file, doc_name):
    print("rep_get_doc_metadata")
    url = state['REP_ADDRESS'] + '/get/doc/metadata'

    with open( session_file, 'r' ) as f:                   
        session = f.read()
    session = json.loads(session) 

    params = {
        "session_file": session,
        "doc_name": doc_name
    }

    response = requests.get(url, params=params)

    print(response.status_code)
    print(response.json())

def rep_get_doc_file(session_file, doc_name):
    print("rep_get_doc_file")

    with open( session_file, 'r' ) as f:                   
        session = f.read()
    session = json.loads(session) 

    url_metadata = state['REP_ADDRESS'] + '/get/doc/metadata'

    response = requests.get(url_metadata, params=params)
    params = {
        "session_file": session,
        "doc_name": doc_name
    }

    metadata = response.json()
    file_handle = metadata["pub_metadata"]["file_handle"]

    url_file = state['REP_ADDRESS'] + '/file/get'
    params = {
        "file_handle": file_handle,
        "file": None
    }
    response = requests.get(url_file, params=params)

    rep_decrypt_file(response.text, metadata["priv_metadata"])

    print(response.status_code)
    print(response.json())

def rep_delete_doc(session_file, doc_name):
    print("rep_delete_doc")
    url = state['REP_ADDRESS'] + '/delete/doc'

    with open( session_file, 'r' ) as f:                   
        session = f.read()
    session = json.loads(session) 

    headers = {"Content-Type": "application/json"}
    data = {
        "session_file": session,
        "doc_name": doc_name
    }

    response = requests.post(url, headers=headers, data=json.dumps(data))

    print(response.status_code)
    print(response.json())

# SESSIONS

# rep_create_session <organization> <username> <password> <credentials file> <session file>
def rep_create_session(organization, username, password, credentials_file, session_file):
    # TO DO -> authenticate user with password and credentials
    # if make credentials with pass given = credentials
    # let do function
    # else 
    # cannot call create session

    pub_key_client = ""
    with open(credentials_file) as f:
        copy = False
        for line in f:
            if line.strip() == "-----BEGIN PUBLIC KEY-----":
                copy = True
            elif line.strip() == "-----END PUBLIC KEY-----":
                copy = False
            elif copy:
                pub_key_client += line

    params = {
        "pub_key" : pub_key_client,
        "username" : username,
        "organization": organization
    }
    headers = {'content-type': 'application/json'}
    response = requests.post(state["REP_ADDRESS"] + "/session/create", data=json.dumps(params), headers=headers)
    print("Response status code: "+str(response.status_code))
    if response.status_code == 200:
        url = state["REP_ADDRESS"] + "/key/request"
        response = requests.get(url)
        if response.status_code == 200:
            pub_key_server = response.json()["public_key"]
            challenge = response.json()["challenge"]
            challenge_response = encrypt_data(challenge+username, pub_key_client)
            params["pub_key"] = challenge_response      # it clearly isnt the pub_key but the challenge response
            response = requests.post(state["REP_ADDRESS"] + "/session/create", data=json.dumps(params), headers=headers)
            print("Response status code: "+str(response.status_code))
            if response.status_code == 200:
                with open(session_file, 'w') as f:
                    f.write(response.text)

# list subjects
def rep_list_subjects(session_file, username):
    # get session file
    with open( session_file, 'r' ) as f:                    # verificar depois se tem session id
        session = f.read()
    session = json.loads(session) 

    params = {"session_id" : session["session_id"], "user" : username}
    response = requests.get(state["REP_ADDRESS"] + "/subject/list", params=params)
    print("Response status code: "+str(response.status_code))
    if response.status_code == 200:
        print(response.text)

# add subject
def rep_add_subject(session_file, username, name, email, credentials_file):
    with open( session_file, 'r' ) as f:                   
        session = f.read()
    session = json.loads(session) 

    pub_key = ""
    with open(credentials_file) as f:
        copy = False
        for line in f:
            if line.strip() == "-----BEGIN PUBLIC KEY-----":
                copy = True
            elif line.strip() == "-----END PUBLIC KEY-----":
                copy = False
            elif copy:
                pub_key += line

    params = {
        "session_id" : session["session_id"],
        "username" : username,
        "name" : name,
        "email" : email,
        "pub_key" : pub_key
    }
    response = requests.post(state["REP_ADDRESS"] + "/subject/add", params=params)
    print("Response status code: "+str(response.status_code))
    if response.status_code == 200:
        print(response.text)

# suspend subject
def rep_suspend_subject(session_file, username):
    with open( session_file, 'r' ) as f:                   
        session = f.read()
    session = json.loads(session) 

    params = {"session_id" : session["session_id"], "username" : username}
    response = requests.post(state["REP_ADDRESS"] + "/subject/suspend", params=params)
    print("Response status code: "+str(response.status_code))
    if response.status_code == 200:
        print(response.text)

# activate subject
def rep_activate_subject(session_file, username):
    with open( session_file, 'r' ) as f:                   
        session = f.read()
    session = json.loads(session) 

    params = {"session_id" : session["session_id"], "username" : username}
    response = requests.post(state["REP_ADDRESS"] + "/subject/activate", params=params)
    print("Response status code: "+str(response.status_code))
    if response.status_code == 200:
        print(response.text)

# Encryption

def generate_keys_client(password: str, key_size=2048):
    # Gerar chave privada
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=key_size
    )

    # Gerar chave pública
    public_key = private_key.public_key()

    # Derivar uma chave de cifragem da senha do cliente
    kdf = PBKDF2HMAC(
        algorithm=SHA256(),
        length=32,
        salt=b"fixed_salt_value",
        iterations=100000
    )
    derived_key = kdf.derive(password.encode())

    # Serializar e cifrar a chave privada
    encrypted_private_key = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.BestAvailableEncryption(derived_key)
    )

    # Serializar a chave pública
    public_key_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    return encrypted_private_key, public_key_pem

#Encripta os dados usando uma chave
def encrypt_data(data: str, key) -> bytes:
    encrypted = key.encrypt(
        data.encode('utf-8'),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=SHA256()),
            algorithm=SHA256()
        )
    )
    return encrypted

#Desencripta os dados usando uma chave
def decrypt_data(encrypted_data: bytes, key) -> str:
    decrypted = key.decrypt(
        encrypted_data,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=SHA256()),
            algorithm=SHA256()
        )
    )
    return decrypted.decode('utf-8')

def rep_subject_credentials(password, credentials_file):
    """
    Gera um par de chaves RSA e salva em um arquivo, com a chave privada protegida pela password.
    """
    logger.info("Generating key pair...")

    # Gerar chave privada e pública
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048
    )
    public_key = private_key.public_key()

    # Salt e derivação de senha
    salt = os.urandom(16)
    kdf = PBKDF2HMAC(
        algorithm=SHA256(),
        length=32,
        salt=salt,
        iterations=100000
    )
    key_encryption = base64.urlsafe_b64encode(kdf.derive(password.encode()))

    # Serializar chave privada criptografada
    encrypted_private_key = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.BestAvailableEncryption(key_encryption)
    )

    # Serializar chave pública
    public_key_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    # Salvar no arquivo
    with open(credentials_file, 'wb') as f:
        
        f.write(encrypted_private_key)
        
        f.write(b"\n")
        
        f.write(public_key_bytes)
        

    logger.info(f"Credentials saved in {credentials_file}")

def rep_encrypt_file(input_file, output_file, metadata_file, key):
    try:
        # Ler o ficheiro de entrada
        with open(input_file, 'rb') as in_file:
            data = in_file.read()

        # Gerar IV e salt
        iv = os.urandom(16)
        salt = os.urandom(16)

        # Derivar a chave usando KDF
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000
        )
        derived_key = kdf.derive(key.encode('utf-8'))

        # Configurar o algoritmo de cifra
        cipher = Cipher(algorithms.AES(derived_key), modes.CBC(iv))
        encryptor = cipher.encryptor()

        # Adicionar padding aos dados
        pad_len = 16 - (len(data) % 16)
        data += bytes([pad_len] * pad_len)

        # Encriptar os dados
        encrypted_data = encryptor.update(data) + encryptor.finalize()

        # Escrever os dados encriptados no ficheiro de saída
        with open(output_file, 'wb') as out_file:
            out_file.write(encrypted_data)

        # Criar e escrever os metadados
        metadata = {
            "alg": "AES-CBC",
            "key": key,
            "iv": iv.hex(),
            "salt": salt.hex()
        }
        with open(metadata_file, 'w') as meta_file:
            json.dump(metadata, meta_file)

        print("File encrypted successfully.")

    except Exception as e:
        print(f"Error during encryption: {e}", file=sys.stderr)
        sys.exit(1)

# É PRECISO MUDAR PARA SÓ TER ALG e KEY
def rep_decrypt_file(encrypted_file, metadata):
    try:
        # Ler o ficheiro encriptado
        with open(encrypted_file, 'rb') as enc_file:
            encrypted_data = enc_file.read()

        # Ler os metadados de encriptação
        metadata = json.load(metadata)

        # Validar se todos os campos necessários estão presentes
        required_keys = ["alg", "key", "iv", "salt"]
        for key in required_keys:
            if key not in metadata:
                raise ValueError(f"Metadata file is missing required key: {key}")

        # Extrair os metadados
        algorithm = metadata["alg"]
        key = metadata["key"].encode('utf-8')
        iv = bytes.fromhex(metadata["iv"])
        salt = bytes.fromhex(metadata["salt"])

        # Derivar a chave usando KDF (se necessário)
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000)
        
        derived_key = kdf.derive(key)

        # Configurar o algoritmo de cifra
        if algorithm == "AES-CBC":
            cipher = Cipher(algorithms.AES(derived_key), modes.CBC(iv))
        else:
            raise ValueError(f"Unsupported encryption algorithm: {algorithm}")

        # Desencriptar os dados
        decryptor = cipher.decryptor()
        decrypted_data = decryptor.update(encrypted_data) + decryptor.finalize()

        # Imprimir os dados desencriptados no stdout
        print(decrypted_data.decode('utf-8'))

    except Exception as e:
        print(f"Error during decryption: {e}", file=sys.stderr)
        sys.exit(1)

## ROLES
def rep_assume_role(session_file, role_name):
    with open( session_file, 'r' ) as f:                   
        session = f.read()
    session = json.loads(session) 

    params = {"session_id" : session["session_id"], "role_name" : role_name}
    response = requests.post(state["REP_ADDRESS"] + "/role/assume", params=params)
    print(f"Response status code: {response.status_code}")
    if response.status_code == 200:
        print(response.text)

def rep_drop_role(session_file, role_name):
    with open( session_file, 'r' ) as f:                   
        session = f.read()
    session = json.loads(session) 

    params = {"session_id" : session["session_id"], "role_name" : role_name}
    response = requests.post(state["REP_ADDRESS"] + "/role/drop", params=params)
    print(f"Response status code: {response.status_code}")
    if response.status_code == 200:
        print(response.text)

def rep_add_role(session_file, role_name):
    with open( session_file, 'r' ) as f:                   
        session = f.read()
    session = json.loads(session) 

    params = {"session_id" : session["session_id"], "role_name" : role_name}
    response = requests.post(state["REP_ADDRESS"] + "/role/add", params=params)
    print(f"Response status code: {response.status_code}")
    if response.status_code == 200:
        print(response.text)

def rep_list_roles(session_file, role_name):
    with open( session_file, 'r' ) as f:                   
        session = f.read()
    session = json.loads(session) 

    params = {"session_id" : session["session_id"], "role_name" : role_name}
    response = requests.get(state["REP_ADDRESS"] + "/role/list", params=params)
    print(f"Response status code: {response.status_code}")
    if response.status_code == 200:
        print(response.text)

def rep_add_permission(session_file, role_name, permission):
    with open(session_file, 'r') as f:
        session = f.read()
    session = json.loads(session)

    # Parâmetros para o POST
    params = {
        "session_id": session["session_id"],
        "role_name": role_name,
        "permission": permission
    }

    response = requests.post(state["REP_ADDRESS"] + "/role/add/permission", params=params)
    print(f"Response status code: {response.status_code}")
    if response.status_code == 200:
        print(response.text)
    else:
        print(f"Error: {response.text}")

def rep_remove_permission(session_file, role_name, permission):
    # Ler o arquivo da sessão
    with open(session_file, 'r') as f:
        session = f.read()
    session = json.loads(session)

    # Parâmetros para o POST
    params = {
        "session_id": session["session_id"],
        "role_name": role_name,
        "permission": permission
    }

    response = requests.post(state["REP_ADDRESS"] + "/role/remove/permission", params=params)
    print(f"Response status code: {response.status_code}")
    if response.status_code == 200:
        print(response.text)
    else:
        print(f"Error: {response.text}")

def rep_list_role_subjects(session_file, role_name):
    with open(session_file, 'r') as f:
        session = f.read()
    session = json.loads(session)

    # Parâmetros para o GET
    params = {
        "session_file": session_file,
        "role_name": role_name
    }
    response = requests.get(state["REP_ADDRESS"] + "/role/subject/list", params=params)
    print(f"Response status code: {response.status_code}")
    if response.status_code == 200:
        print(response.json())

def rep_list_role_permissions(session_file, role_name):
    with open(session_file, 'r') as f:
        session = f.read()
    session = json.loads(session)

    # Parâmetros para o GET
    params = {
        "session_file": session_file,
        "role_name": role_name
    }
    response = requests.get(state["REP_ADDRESS"] + "/role/permissions/list", params=params)
    print(f"Response status code: {response.status_code}")
    if response.status_code == 200:
        print(response.json())

def rep_list_permission_roles(session_file, permission):
    with open(session_file, 'r') as f:
        session = f.read()
    session = json.loads(session)

    # Parâmetros para o GET
    params = {
        "session_file": session_file,
        "permission": permission
    }
    response = requests.get(state["REP_ADDRESS"] + "/permission/roles/list", params=params)
    print(f"Response status code: {response.status_code}")
    if response.status_code == 200:
        print(response.json())

def rep_list_subject_roles(session_file, username):
    with open(session_file, 'r') as f:
        session = f.read()
    session = json.loads(session)
    
    # Parâmetros para o GET
    params = {
        "session_file": session_file,
        "username": username
    }
    response = requests.get(state["REP_ADDRESS"] + "/subject/roles/list", params=params)
    print(f"Response status code: {response.status_code}")
    if response.status_code == 200:
        print(response.json())

def rep_suspend_role(session_file, role_name):
    with open(session_file, 'r') as f:
        session = f.read()
    session = json.loads(session)

    params = {"session_id": session["session_id"], "role_name": role_name}
    response = requests.get(state["REP_ADDRESS"] + "/role/suspend", params=params)
    print(f"Response status code: {response.status_code}")
    if response.status_code == 200:
        print(response.text)

def rep_reactivate_role(session_file, role_name):
    with open(session_file, 'r') as f:
        session = f.read()
    session = json.loads(session)

    params = {"session_id": session["session_id"], "role_name": role_name}
    response = requests.get(state["REP_ADDRESS"] + "/role/reactivate", params=params)
    print(f"Response status code: {response.status_code}")
    if response.status_code == 200:
        print(response.text)

#####################################################################
print("Program name:", args["command"])

if not state['REP_ADDRESS'].startswith('http://'):
    state['REP_ADDRESS'] = 'http://' + state['REP_ADDRESS']

if args["command"]  == "rep_create_org":
    rep_create_org(args["arg0"], args["arg1"], args["arg2"], args["arg3"], args["arg4"])

elif args["command"] == "rep_list_orgs":
    rep_list_orgs()

elif args["command"] == "rep_get_file":
    rep_get_file(args["arg0"], args["arg1"])

elif args["command"] == "rep_list_subjects":
    if not args["arg1"]:
        args["arg1"] = ""
    rep_list_subjects(args["arg0"], args["arg1"])

elif args["command"] == "rep_add_subject":
    rep_add_subject(args["arg0"], args["arg1"], args["arg2"], args["arg3"], args["arg4"])

elif args["command"] == "rep_create_session":
    rep_create_session(args["arg0"], args["arg1"], args["arg2"], args["arg3"], args["arg4"])

elif args["command"] == "rep_subject_credentials":
    rep_subject_credentials(args["arg0"], args["arg1"])

elif args["command"] == "rep_decrypt_file":
    rep_decrypt_file(args["arg0"], args["arg1"]
                     )
elif args["command"] == "rep_assume_role":
    rep_assume_role(args["arg0"], args["arg1"])

elif args["command"] == "rep_drop_role":
    rep_drop_role(args["arg0"], args["arg1"])

elif args["command"] == "rep_add_role":
    rep_add_role(args["arg0"], args["arg1"])

elif args["command"] == "rep_list_roles":
    rep_list_roles(args["arg0"], args["arg1"])

elif args["command"] == "rep_add_doc":
    rep_add_doc(args["arg0"], args["arg1"], args["arg2"])

elif args["command"] == "rep_add_permission":
    rep_add_permission(args["arg0"], args["arg1"], args["arg2"])

elif args["command"] == "rep_remove_permission":
    rep_remove_permission(args["arg0"], args["arg1"], args["arg2"])

elif args["command"] == "rep_list_role_subjects":
    rep_list_role_subjects(args["arg0"], args["arg1"])

elif args["command"] == "rep_list_role_permissions":
    rep_list_role_permissions(args["arg0"], args["arg1"])

elif args["command"] == "rep_list_permission_roles":
    rep_list_permission_roles(args["arg0"], args["arg1"])

elif args["command"] == "rep_list_subject_roles":
    rep_list_subject_roles(args["arg0"], args["arg1"])

elif args["command"] == "rep_list_docs":
    # Get arguments
    username = args.username
    date_type = args.date
    date = args.date

    rep_list_docs(args["arg0"], username, date_type, date)

elif args["command"] == "rep_get_doc":
    rep_get_doc(args["arg0"], args["arg1"])

elif args["command"] == "rep_get_doc_file":
    rep_get_doc_file(args["arg0"], args["arg1"])

elif args["command"] == "rep_get_doc_metadata":
    rep_get_doc_metadata(args["arg0"], args["arg1"])

elif args["command"] == "rep_delete_doc":
    rep_delete_doc(args["arg0"], args["arg1"])

elif args["command"] == "rep_get_file":
    rep_get_file(args["arg0"], args["arg1"])

elif args["command"] == "rep_suspend_role":
    rep_suspend_role(args["arg0"], args["arg1"])

elif args["command"] == "rep_reactivate_role":
    rep_reactivate_role(args["arg0"], args["arg1"])

else:
    logger.error("Invalid command")

# to run the client.py open the right enviroment
# run the command python3 client.py
# there is no need for any params but if needed
# "-k" or '--key' + "Path to the key file"
# "-r" or '--repo' + "Address:Port" -> these are refering to the repository address
# "-v" or '--verbose' -> "Increase verbosity"