###########################################################

#					Job done by:
#				Diogo Carvalho, n113221
#				José Fernandes, n114472
#				Carlos Verenzuela, n114597

###########################################################

# MODIFICAÇÕES FEITAS

    *rep_add_subject parte do client

    *rep_activate_subject parte do client
    
    *rep_suspend_subject parte do client

Isto tinha sido esquecido, mas foi implementado. Também foram adicionadas as permissões desses comandos do lado do servidor

    *suspend_role
    
    *reactivate_role

Funções que tinham sido esquecidas previamente e foram implementadas em ambos os lados (Server e Client)

A AUTENTICAÇÃO FOI FINALMENTE IMPLEMENTADA COM CHALLENGE-RESPONSE!!!

Foi corrigida a questão de assegurar a existência de um manager ativo

O Manager passou a ser considerado um role