from flask import Flask,request, jsonify
import secrets
import json
from datetime import datetime,timedelta
import os
import hashlib
import enum
import signal
import sys
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.serialization import load_pem_private_key, load_pem_public_key
from getpass import getpass
from cryptography.hazmat.primitives.hashes import SHA256

# TO-DO:
# [x] - Create folder structure (if not correct) before running the app
# [ ] - Implement challenge (w/timeout) PROPERLY (might have to be added to other endpoints)
# [ ] - Check if all session fields match (beyond just being present)
# [ ] - Sanitize input sent in by user
# [ ] - We need to fix it for the add subject method too (I forgot what this to-do entry was)

app = Flask(__name__)

SESSION_LIFETIME = timedelta(minutes=2)
SESSION_DIRNAME = "sessions"
SESSION_FIELDS = ["session_id", "organization", "username", "key_list", "lifetime", "time_last_method"]
FILE_DIRNAME = "files"
DATABASE_DIRNAME = "databases"
KEYS_DIRNAME = "keys"

class Permissions(enum.IntFlag):
    # Document permissions
    DOC_NEW = enum.auto()
    DOC_ACL = enum.auto()
    DOC_READ = enum.auto()
    DOC_DELETE = enum.auto()
    # Role permissions
    ROLE_ACL = enum.auto()
    ROLE_NEW = enum.auto()
    ROLE_DOWN = enum.auto()
    ROLE_UP = enum.auto()
    ROLE_MOD = enum.auto()
    # Subject permissions
    SUBJECT_NEW = enum.auto()
    SUBJECT_UP = enum.auto()
    SUBJECT_DOWN = enum.auto()

# by default, if there are no organizations stored persistently
# it will load a default Example_Organization to aid testing
organizations = { 
    "Example_Organization":{
        "subjects": {
            "first_user":{
                "name"  : "First User",
                "email" : "first@hotmail.com",
                "pubkey": None,
                "status": True
            },
            "second_user":{
                "name"  : "Second User",
                "email" : "second@hotmail.com",
                "pubkey": None,
                "status": False
            }
        },
        "roles": {
            "manager": {
                "permissions": Permissions.DOC_NEW | Permissions.DOC_ACL | Permissions.DOC_READ | Permissions.DOC_DELETE 
                            | Permissions.ROLE_ACL | Permissions.ROLE_NEW | Permissions.ROLE_DOWN | Permissions.ROLE_UP 
                            | Permissions.ROLE_MOD | Permissions.SUBJECT_NEW | Permissions.SUBJECT_UP | Permissions.SUBJECT_DOWN,
                "subjects": ["first_user"],
                "status": True
            },
            "custom_role" : {
                "permissions": Permissions.DOC_ACL | Permissions.DOC_READ | Permissions.DOC_DELETE,
                "subjects": ["first_user"],
                "status": False
            },
        },
        "documents": ["aaa","bbb","ccc"]
    }
}
challenges = {}

# Reusable (or generic) methods

def create_keys():
    if not os.path.exists(KEYS_DIRNAME+"/private_key.pem") and not os.path.exists(KEYS_DIRNAME+"/public_key.pem"):
        private_key, public_key = generate_server_keys()
        with open(KEYS_DIRNAME+"/private_key.pem", "wb") as f:
            f.write(private_key)
        with open(KEYS_DIRNAME+"/public_key.pem", "wb") as f:
            f.write(public_key)

def valid_permissions(session, required_permissions):
    perm = False
    org = session["organization"]
    username = session["username"]
    for role in organizations[org]["roles"]:
        if username in organizations[org]["roles"][role]["subjects"] and organizations[org]["roles"][role]["permissions"] & required_permissions:
                if(organizations[org]["roles"][role]["status"]):
                    perm = True
                break
    if not perm:
        return jsonify({"error": "Permission denied"}), 403
    return "Permission granted", 200

def has_role(session, role):
    org = session["organization"]
    username = session["username"]
    if role not in organizations[org]["roles"]:
        return False
    if username in organizations[org]["roles"][role]["subjects"]:
        return True
    return False

def active_managers(session):
    org = session["organization"]
    managers = 0
    for username in organizations[org]["roles"]["manager"]["subjects"]:
        if organizations[org]["subjects"][username]["status"]:
            managers = managers + 1
    return managers

def valid_acl(session, doc_name, required_permissions):
    perm = False
    org = session["organization"]
    username = session["username"]
    user_roles = []
    for role in organizations[org]["roles"]:
        if username in organizations[org]["roles"][role]["subjects"]:
                user_roles.append(role)
    with open(os.path.join(DATABASE_DIRNAME, "DOCUMENTS.json"), 'r') as f:
        docs = json.load(f)
        for doc in docs.keys():
            if doc == doc_name:
                for role in user_roles:
                    if docs[doc]["pub_metadata"]["acl"][role] & required_permissions:
                        perm = True
    if not perm:
        return jsonify({"error": "Permission denied"}), 403
    return "Permission granted", 200

def ensure_structure():
    directories = [SESSION_DIRNAME, FILE_DIRNAME, DATABASE_DIRNAME, KEYS_DIRNAME]
    for directory in directories:
        try:
            if not os.path.exists(directory):
                os.makedirs(directory)
                print(f"Created directory: {directory}")
        except OSError as e:
            print(f"Error creating directory {directory}: {e}")
            sys.exit(1)

def exit_gracefully(signal, frame):
    clear_directory(SESSION_DIRNAME)
    sys.exit(0)

def valid_session(client_session):
    try:
        with open(os.path.join(SESSION_DIRNAME, f"{client_session['session_id']}.json"), 'r') as f:
            data = json.load(f)
            for key in SESSION_FIELDS:
                if key not in data or data[key] != client_session[key]:
                    return jsonify({"error": "Session field is missing or mismatching fields"}), 500
            # checking if an organization exists probably doesn't matter, but could in another iteration
            if data["organization"] not in organizations:
                return jsonify({"error": "Invalid organization in session file"}), 500
            creation_time = datetime.fromisoformat(data["time_last_method"])
            lifetime = timedelta(seconds=data["lifetime"])
            if datetime.now() > creation_time + lifetime:
                return jsonify({"error": "Session has expired"}),401
    except FileNotFoundError:
        return jsonify({"error": "Session file does not exist"}),404
    except json.JSONDecodeError:
        return jsonify({"error": "Error decoding session file"}),500
    except ValueError:
        return jsonify({"error": "Invalid session creation time format"}),500
    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}),500
    return data,200

def valid_query(data,required_fields):
    if not all(key in data and data[key] is not None for key in required_fields):
        return jsonify({"error": "Missing or None fields"}),400
    return "",200

def clear_directory(directory):
    if os.path.exists(directory):
        for filename in os.listdir(directory):
            file_path = os.path.join(directory, filename)
            try:
                if os.path.isfile(file_path):
                    os.unlink(file_path)
            except Exception as e:
                print(f"Failed to delete {file_path}. Reason: {e}")

# since the structure we're using to store the organizations has a set
# we have to clean it before sending the json dump to the client
def normalize_dictionary(obj):
    if isinstance(obj, dict):
        return {k: normalize_dictionary(v) for k, v in obj.items()}
    elif isinstance(obj, set):
        return list(obj)
    elif isinstance(obj, list):
        return [normalize_dictionary(i) for i in obj]
    else:
        return obj

def has_permission(org, username, permission):
    roles = organizations[org]["roles"]
    for role in roles.values():
        if username in role["subjects"] and (role["permissions"] & permission):
            return True
    return False

def role_exists(org, role_name): 
    return role_name in organizations.get(org, {}).get("roles", {})

def is_subject_in_role(org, role_name, username):
    return username in organizations[org]["roles"].get(role_name, {}).get("subjects", set())

# Encryption

#Carrega a chave privada RSA do servidor a partir de dados PEM
def load_server_private_key(private_key_data: bytes, password: None | str = None) -> rsa.RSAPrivateKey:
    try:
        # Tentar carregar a chave sem senha
        private_key = load_pem_private_key(private_key_data, password=None)
        if password is not None and not password:
            raise ValueError("A password was provided for a key with no password.")
    except TypeError:
        # Caso uma senha seja necessária, solicitá-la se não foi fornecida
        if password is None:
            password = getpass("Enter the password for the server's private key: ")
        password = password.encode("utf-8") if password else None

        # Carregar a chave com a senha fornecida
        private_key = load_pem_private_key(private_key_data, password)

    return private_key

#Carrega a chave pública RSA do servidor a partir de dados PEM
def load_server_public_key(public_key_data: bytes) -> rsa.RSAPublicKey:
    try:
        # Tentar carregar a chave pública diretamente
        return load_pem_public_key(public_key_data)
    except ValueError:
        # Caso a chave pública não esteja disponível, derivar a partir da chave privada
        print("No public key available. Using Private Key to Derive Public Key.", file=sys.stderr)
        private_key = load_server_private_key(public_key_data)
        return private_key.public_key()

#Gera chave_privada, chave_pública) em formato PEM (para o server)
def generate_server_keys(password: None | str = None, key_size: int = 2048) -> tuple[bytes, bytes]:
    # Gerar a chave privada RSA
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=key_size)

    # Serializar a chave privada, com ou sem senha
    encryption_algorithm = (
        serialization.BestAvailableEncryption(password.encode("utf-8"))
        if password
        else serialization.NoEncryption()
    )
    private_key_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=encryption_algorithm,
    )

    # Serializar a chave pública
    public_key = private_key.public_key()
    public_key_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    return private_key_pem, public_key_pem

#Encripta os dados usando uma chave
def encrypt_data(data: str, key) -> bytes:
    encrypted = key.encrypt(
        data.encode('utf-8'),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=SHA256()),
            algorithm=SHA256()
        )
    )
    return encrypted

#Desencripta os dados usando uma chave
def decrypt_data(encrypted_data: bytes, key) -> str:
    decrypted = key.decrypt(
        encrypted_data,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=SHA256()),
            algorithm=SHA256()        
        )
    )
    return decrypted.decode('utf-8')

# NO SESSION REQUIRED

## Roles - Permissions

#rep_assume_role <session file> <role>
@app.route("/role/assume", methods=["POST"])
def assume_role():
    data = request.get_json()
    required_fields = ["session_file", "role_name"]

    message, code = valid_query(data, required_fields)
    if code != 200:
        return message, code

    session_file = data["session_file"]
    role_name = data["role_name"]

    session_data, session_code = valid_session(session_file)
    if session_code != 200:
        return session_data, session_code

    username = session_data["username"]
    org = session_data["organization"]

    if not role_exists(org, role_name):
        return jsonify({"error": f"Role '{role_name}' does not exist in organization '{org}'"}), 404

    if not is_subject_in_role(org, role_name, username):
        return jsonify({"error": f"User '{username}' is not assigned to role '{role_name}'"}), 403

    session_data["current_role"] = role_name

    session_path = os.path.join(SESSION_DIRNAME, f"{session_file}.json")
    try:
        with open(session_path, "w") as session_file:
            json.dump(session_data, session_file)
    except Exception as e:
        return jsonify({"error": f"Failed to save session: {str(e)}"}), 500

    return jsonify({
        "message": f"Role '{role_name}' assumed successfully",
        "session": session_data
    }), 200

#rep_drop_role <session file> <role>
@app.route("/role/drop", methods=["POST"])
def drop_role():
    data = request.get_json()
    required_fields = ["session_file", "role_name"]

    message, code = valid_query(data, required_fields)
    if code != 200:
        return message, code

    session_file = data["session_file"]
    role_name = data["role_name"]

    session_data, session_code = valid_session(session_file)
    if session_code != 200:
        return session_data, session_code

    username = session_data["username"]
    org = session_data["organization"]

    if not role_exists(org, role_name):
        return jsonify({"error": f"Role '{role_name}' does not exist in organization '{org}'"}), 404

    if session_data.get("current_role") != role_name:
        return jsonify({"error": f"Role '{role_name}' is not the current role for the session"}), 400

    session_data["current_role"] = None

    session_path = os.path.join(SESSION_DIRNAME, f"{session_file}.json")
    try:
        with open(session_path, "w") as session_file:
            json.dump(session_data, session_file)
    except Exception as e:
        return jsonify({"error": f"Failed to update session: {str(e)}"}), 500

    return jsonify({
        "message": f"Role '{role_name}' dropped successfully",
        "session": session_data
    }), 200

#rep_add_role <session file> <role>
@app.route("/role/add", methods=["POST"])
def add_role():
    data = request.get_json()
    required_fields = ["session_file", "role_name"]

    message, code = valid_query(data, required_fields)
    if code != 200:
        return message, code

    session, code = valid_session(data["session_file"])
    if code != 200:
        return session, code

    org = session["organization"]
    username = session["username"]

    if not has_permission(org, username, Permissions.ROLE_NEW):
        return jsonify({"error": "Permission denied"}), 403

    role_name = data["role_name"]
    permissions = Permissions(int(data["permissions"]))

    #if role_name in organizations[org]["roles"]:
    #    return jsonify({"error": "Role already exists"}), 409
    if role_exists(org, role_name):
        return jsonify({"error": f"Role '{role_name}' already exists in organization '{org}'"}), 409

    try:
        permissions = Permissions(int(data["permissions"]))
        organizations[org]["roles"][role_name] = {"permissions": permissions, "subjects": set(), "status": True}

    except ValueError:
        return jsonify({"error": "Invalid permissions value"}), 400
    except Exception as e:
        return jsonify({"error": f"An error occurred while creating the role: {str(e)}"}), 500

    return jsonify({"message": f"Role '{role_name}' created successfully"}), 200

#rep_list_roles <session file> <role>
@app.route("/role/list", methods=["GET"])
def list_roles():
    data = request.args()
    required_fields = ["session_file"]

    message,code = valid_query(data,required_fields)
    if code != 200:
        return message,code
    
    session, code = valid_session(data["session_file"])
    if code != 200:
        return session,code

    if not session:
        return jsonify({"error": "Missing session_file"}), 400

    org = session["organization"]
    roles = organizations[org]["roles"]
    return jsonify({"roles": normalize_dictionary(roles)}), 200

#rep_add_permission <session file> <role> <permission>
@app.route("/role/add/permission", methods=["POST"])
def add_permission():
    data = request.get_json()
    required_fields = ["session_file", "role_name", "permission"]

    message, code = valid_query(data, required_fields)
    if code != 200:
        return message, code

    session, code = valid_session(data["session_file"])
    if code != 200:
        return session, code

    org = session["organization"]
    admin_user = session["username"]

    if not has_permission(org, admin_user, Permissions.ROLE_MOD):
        return jsonify({"error": "Permission denied"}), 403

    role_name = data["role_name"]
    permission = data["permission"]

    if role_name not in organizations[org]["roles"]:
        return jsonify({"error": "Role does not exist"}), 404

    try:
        permission_value = Permissions[permission]
        organizations[org]["roles"][role_name]["permissions"] |= permission_value
        return jsonify({"message": "Permission added successfully"}), 200
    except KeyError:
        return jsonify({"error": "Invalid permission"}), 400

#rep_remove_permission <session file> <role> <permission>
@app.route("/role/remove/permission", methods=["POST"])
def remove_permission():
    data = request.get_json()
    required_fields = ["session_file", "role_name", "permission"]

    message, code = valid_query(data, required_fields)
    if code != 200:
        return message, code

    session, code = valid_session(data["session_file"])
    if code != 200:
        return session, code

    org = session["organization"]
    admin_user = session["username"]

    if not has_permission(org, admin_user, Permissions.ROLE_MOD):
        return jsonify({"error": "Permission denied"}), 403

    role_name = data["role_name"]
    permission = data["permission"]

    if role_name not in organizations[org]["roles"]:
        return jsonify({"error": "Role does not exist"}), 404

    try:
        permission_value = Permissions[permission]
        organizations[org]["roles"][role_name]["permissions"] &= ~permission_value
        return jsonify({"message": "Permission removed successfully"}), 200
    except KeyError:
        return jsonify({"error": "Invalid permission"}), 400

#rep_list_role_subjects <session file> <role>
@app.route("/role/subject/list", methods=["GET"])
def list_role_subjects():
    data = request.args
    required_fields = ["session_file", "role_name"]

    message, code = valid_query(data, required_fields)
    if code != 200:
        return message, code

    session_file = data["session_file"]
    role_name = data["role_name"]

    session_data, session_code = valid_session(session_file)
    if session_code != 200:
        return session_data, session_code

    org = session_data["organization"]

    if not role_exists(org, role_name):
        return jsonify({"error": f"Role '{role_name}' does not exist in organization '{org}'"}), 404

    role_data = organizations[org]["roles"].get(role_name, {})
    subjects = role_data.get("subjects", [])

    return jsonify({
        "role_name": role_name,
        "subjects": normalize_dictionary(subjects)
    }), 200

#rep_list_role_permissions <session file> <role>
@app.route("/role/permissions/list", methods=["GET"])
def list_role_permissions():
    data = request.args
    required_fields = ["session_file", "role_name"]

    message, code = valid_query(data, required_fields)
    if code != 200:
        return message, code

    session_file = data["session_file"]
    role_name = data["role_name"]

    session_data, session_code = valid_session(session_file)
    if session_code != 200:
        return session_data, session_code

    org = session_data["organization"]

    if not role_exists(org, role_name):
        return jsonify({"error": f"Role '{role_name}' does not exist in organization '{org}'"}), 404

    role_data = organizations[org]["roles"][role_name]
    permissions = role_data.get("permissions", Permissions(0))

    permission_names = [perm.name for perm in Permissions if perm in permissions]

    return jsonify({
        "role_name": role_name,
        "permissions": permission_names
    }), 200

#rep_list_permission_roles <session file> <permission>
@app.route("/permission/roles/list", methods=["GET"])
def list_permission_roles():
    data = request.args
    required_fields = ["session_file", "permission"]

    message, code = valid_query(data, required_fields)
    if code != 200:
        return message, code

    session_file = data["session_file"]
    permission = data["permission"]

    session_data, session_code = valid_session(session_file)
    if session_code != 200:
        return session_data, session_code

    org = session_data["organization"]

    try:
        permission_value = Permissions[permission]
    except KeyError:
        return jsonify({"error": f"Invalid permission: '{permission}'"}), 400

    roles_with_permission = {}

    for role_name, role_data in organizations[org]["roles"].items():
        if role_data["permissions"] & permission_value:
            roles_with_permission[role_name] = "organization"

    for doc in organizations[org]["documents"]:
        doc_roles = doc.get("roles", {})
        for role_name, role_permissions in doc_roles.items():
            if role_permissions & permission_value:
                if role_name in roles_with_permission:
                    roles_with_permission[role_name] = "organization and document"
                else:
                    roles_with_permission[role_name] = "document"

    response = [{"role_name": role, "scope": scope} for role, scope in roles_with_permission.items()]

    return jsonify(response), 200

## Organization

@app.route("/organization/list", methods=["GET"])
def org_list():
    return json.dumps(normalize_dictionary(organizations))

@app.route("/organization/create", methods=["POST"])
def org_create():
    data = request.get_json()
    required_fields = ["organization", "username", "name", "email", "pub_key"]

    message,code = valid_query(data,required_fields)
    if code != 200:
        return message,code

    organization = data["organization"]
    data.pop("organization")
    username = data["username"]
    print(type(data))
    data.pop("username")
    # data[username]["status"] = True
    data.setdefault(username, {})["status"] = True

    if organization in organizations:
        return jsonify({"error": "Organization already exists"}), 409

    organizations.setdefault(organization, {}).setdefault("subjects", {})[username] = data
    organizations.setdefault(organization, {}).setdefault("roles", {})["manager"] = {
        "permissions": Permissions.DOC_NEW | Permissions.DOC_ACL | Permissions.DOC_READ | Permissions.DOC_DELETE 
                    | Permissions.ROLE_ACL | Permissions.ROLE_NEW | Permissions.ROLE_DOWN | Permissions.ROLE_UP
                    | Permissions.ROLE_MOD | Permissions.SUBJECT_NEW | Permissions.SUBJECT_UP | Permissions.SUBJECT_DOWN,
        "subjects": {username},
        "status": True
    }
    return json.dumps(normalize_dictionary(organizations))

## Session

@app.route("/session/create", methods=["POST"])
def session_create():
    data = request.get_json()
    required_fields = ["pub_key", "username", "organization"]

    message,code = valid_query(data,required_fields)
    if code != 200:
        return message,code

    pub_key = data["pub_key"]
    username = data["username"]
    org = data["organization"]

    if org not in organizations:
        return jsonify({"error": "Invalid organization"}), 404
    if username not in organizations[org]["subjects"]:
        return jsonify({"error": "User not in organization"}), 404

    stored_pubkey = organizations[org]["subjects"][username]["pubkey"]

    if pub_key == stored_pubkey:
        challenge = secrets.token_hex(16)
        challenges[f"{username}_{org}"] = challenge
        challenges.append(challenge)
        return jsonify({"challenge": challenge}), 200
    else:
        challenge_name = f"{username}_{org}"
        if challenge_name not in challenges:
            return jsonify({"error": "No pending challenge found"}), 400

        signature = pub_key # this is not the pub_key, but the challenge response

        with open(os.path.join(KEYS_DIRNAME, "private_key.pem"), 'rb') as f:
            srv_private_key = load_server_public_key(f.read())

        # this is not very secure
        # serves as a demonstration or placeholder
        expected_signature = challenges[challenge_name]+username
        if decrypt_data(signature, srv_private_key) == expected_signature:
            session_id = secrets.token_hex(16)
            creation_date = datetime.now().isoformat()
            key_list = [""]

            session = {
                "session_id": session_id,
                "organization": org,
                "username": username,
                "key_list": key_list,
                "lifetime": str(SESSION_LIFETIME),
                "time_last_method": creation_date
            }

            with open(os.path.join(SESSION_DIRNAME, f"{session_id}.json"), 'w') as f:
                json.dump(session, f)

            challenges.popitem(challenge_name)

            return json.dumps(session), 200
        else:
            return jsonify({"error": "Invalid signature"}), 401

## File

@app.route("/file/get", methods=["GET"])
def get_file():
    data = request.args()
    required_fields = ["file_handle"]
    
    message,code = valid_query(data,required_fields)
    if code != 200:
        return message,code
    file_handle = data["file_handle"]

    for doc_handle in os.listdir(FILE_DIRNAME):
        if file_handle == doc_handle["metadata"]["file_handle"]:
            with open(os.path.join(FILE_DIRNAME, doc_handle["enc_file_name"]), 'r') as f:
                return jsonify({"file_content": f.read()}), 200
    return jsonify({"file_content": ""}), 404

# SESSION REQUIRED

## Roles

# rep_suspend_role <session file> <role>
@app.route("/role/suspend", methods=["GET"])
def role_suspend():
    data = request.args()
    required_fields = ["session_file", "role"]

    message,code = valid_query(data,required_fields)
    if code != 200:
        return message,code

    role = data["role"]

    session,code = valid_session(data["session"])
    if code != 200:
        return session,code

    org = session["organization"]

    required_permissions = Permissions.ROLE_DOWN
    message, code = valid_permissions(session, required_permissions)
    if code != 200:
        return message, code

    if role not in organizations[org]["roles"]:
        return jsonify({"error": "Organization does not feature said role"}), 404
    if role == "manager":
        return jsonify({"error": "The manager role cannot be suspended"}), 404
    if not organizations[org]["roles"][role]["status"]:
        return jsonify({"message": "Role is already suspended"}), 409
    organizations[org]["roles"][role]["status"] = False
    return jsonify({"message": "Role suspended successfully"}), 200

# rep_reactivate_role <session file> <role>
@app.route("/role/reactivate", methods=["GET"])
def role_reactivate():
    data = request.args()
    required_fields = ["session_file", "role"]

    message,code = valid_query(data,required_fields)
    if code != 200:
        return message,code

    role = data["role"]

    session,code = valid_session(data["session"])
    if code != 200:
        return session,code

    org = session["organization"]

    required_permissions = Permissions.ROLE_UP
    message, code = valid_permissions(session, required_permissions)
    if code != 200:
        return message, code

    if role not in organizations[org]["roles"]:
        return jsonify({"error": "Organization does not feature said role"}), 404
    if organizations[org]["roles"][role]["status"]:
        return jsonify({"message": "Role is already active"}), 409
    organizations[org]["roles"][role]["status"] = True
    return jsonify({"message": "Role activated successfully"}), 200

## Subject

@app.route("/subject/list", methods=["GET"])
def subjects_list():
    data = request.args()
    required_fields = ["session_file"]

    message,code = valid_query(data,required_fields)
    if code != 200:
        return message,code
    session,code = valid_session(data["session_file"])
    if code != 200:
        return session,code

    subjects = organizations[session["organization"]]["subjects"]

    if "username" not in data:
        return jsonify({"subjects": subjects}), 200

    username = data["username"]
    if username in subjects:
        return jsonify({"subjects": subjects[username]}), 200

@app.route("/subject/add", methods=["POST"])
def add_subject():
    data = request.get_json()
    required_fields = ["session_file", "username", "name", "email", "pub_key"]

    message, code = valid_query(data, required_fields)
    if code != 200:
        return message, code

    session, code = valid_session(data["session_file"])
    if code != 200:
        return session, code

    org = session["organization"]
    username = data["username"]

    required_permissions = Permissions.SUBJECT_NEW
    message, code = valid_permissions(session, required_permissions)
    if code != 200:
        return message, code

    if username in organizations[org]["subjects"]:
        return jsonify({"error": "Username already exists in organization"}), 409

    new_user = {
        "name": data["name"],
        "email": data["email"],
        "pubkey": data["pub_key"],
        "status": True
    }

    organizations[org]["subjects"][username] = new_user
    return jsonify({"message": "User added successfully"}), 200

@app.route("/subject/activate", methods=["GET"])
def subject_activate():
    data = request.args()
    required_fields = ["session_file", "username"]

    message,code = valid_query(data,required_fields)
    if code != 200:
        return message,code

    username = data["username"]

    session,code = valid_session(data["session_file"])
    if code != 200:
        return session,code

    org = session["organization"]
    required_permissions = Permissions.SUBJECT_UP
    message, code = valid_permissions(session, required_permissions)
    if code != 200:
        return message, code

    if username not in organizations[org]["subjects"]:
        return jsonify({"error": "Username doesn't belong to any organization"}), 404
    if organizations[org]["subjects"][username]["status"]:
        return jsonify({"message": "User was already activated"}), 409

    organizations[org]["subjects"][username]["status"] = True
    return jsonify({"message": "User activated successfully"}), 200

@app.route("/subject/suspend", methods=["GET"])
def subject_suspend():
    data = request.args()
    required_fields = ["session_file", "username"]

    message,code = valid_query(data,required_fields)
    if code != 200:
        return message,code

    username = data["username"]

    session,code = valid_session(data["session"])
    if code != 200:
        return session,code

    org = session["organization"]

    required_permissions = Permissions.SUBJECT_DOWN
    message, code = valid_permissions(session, required_permissions)
    if code != 200:
        return message, code

    if username not in organizations[org]["subjects"]:
        return jsonify({"error": "Username doesn't belong to any organization"}), 404
    if not organizations[org]["subjects"][username]["status"]:
        return jsonify({"message": "User was already suspended"}), 409
    if active_managers(data["session"]) == 1:
        return jsonify({"message": "Can't suspend the only manager"}), 409

    organizations[org]["subjects"][username]["status"] = False
    return jsonify({"message": "User suspended successfully"}), 200

#rep_list_subject_roles <session file> <username>
@app.route("/subject/roles/list", methods=["GET"])
def list_subject_roles():
    data = request.args
    required_fields = ["session_file", "username"]

    # Validação dos campos obrigatórios
    message, code = valid_query(data, required_fields)
    if code != 200:
        return message, code

    session_file = data["session_file"]
    username = data["username"]

    # Verificação da validade da sessão
    session_data, session_code = valid_session(session_file)
    if session_code != 200:
        return session_data, session_code

    org = session_data["organization"]

    # Verificar se o sujeito existe na organização
    subjects = organizations[org].get("subjects", {})
    if username not in subjects:
        return jsonify({"error": f"Subject '{username}' does not exist in organization '{org}'"}), 404

    # Encontrar os papéis associados ao sujeito
    roles = []
    for role_name, role_data in organizations[org]["roles"].items():
        if username in role_data.get("subjects", set()):
            roles.append(role_name)

    return jsonify({
        "username": username,
        "roles": roles
    }), 200

## Document

@app.route("/document/add", methods=["POST"])
def add_documents():
    files = request.files
    session_file = json.loads(files["session_file"].stream.read().decode('utf-8'))
    document_name = request.form.get("document_name")
    required_permissions = Permissions.DOC_NEW

    data = {
        "document_name": document_name,
        "session_file": session_file
    }

    required_fields = ["session_file", "document_name"]

    message, code = valid_query(data, required_fields)
    if code != 200:
        return message, code

    session, code = valid_session(session_file)
    if code != 200:
        return session, code
    
    message, code = valid_permissions(session, required_permissions)
    if code != 200:
        return message, code
    
    message, code = valid_acl(session, doc_name, required_permissions)
    if code != 200:
        return message, code

    doc_name = data["document_name"]

    doc_handle = hashlib.sha256(doc_name.encode("utf-8")).hexdigest()

    try:
        with open(os.path.join(DATABASE_DIRNAME, "DOCUMENTS.json"), 'r') as f:
            docs = json.load(f)
            for doc_h in docs.keys():
                if doc_name == docs[doc_h]["pub_metadata"]["name"]:
                    return jsonify({"error": "Document already exists"}), 409
    except FileNotFoundError:
        docs = {}
        with open(os.path.join(DATABASE_DIRNAME, "DOCUMENTS.json"), 'w') as f:
            f.write(json.dumps(docs))
            # json.dump(docs, f)
    except json.JSONDecodeError:
        # delete file or clean it idfk
        docs = {}
        docs[doc_handle] = {
            "pub_metadata": {
                "name": doc_name,
                "create_date": datetime.now().isoformat(),
                "file_handle": doc_name,
                "acl": [],
                "deleter" : ""
            },
            "priv_metadata": {
                "alg": "",
                "key": ""
            }
        }
        with open(os.path.join(DATABASE_DIRNAME, "DOCUMENTS.json"), 'w') as f:
            f.write(json.dumps(docs))
    except ValueError:
        return jsonify({"error": "Invalid data format in DOCUMENTS.json"}), 500
    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500

    try:
        with open(os.path.join(DATABASE_DIRNAME, "DOCUMENTS.json"), 'w') as f:
            docs[doc_handle] = {
                "pub_metadata": {
                    "name": doc_name,
                    "create_date": datetime.now().isoformat(),
                    "file_handle": doc_name,
                    "acl": [],
                    "deleter" : ""
                },
                "priv_metadata": {
                    "alg": "",
                    "key": ""
                }
            }
            json.dump(docs, f)
    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500
    return jsonify({"message": "Document added successfully"}), 200

@app.route("/document/list", methods=["GET"])
def list_documents():
    data = request.args
    required_fields = ["session_id"]
    
    message,code = valid_query(data,required_fields)
    if code != 200:
        return message,code

    session,code = valid_session(data["session_id"])
    if code != 200:
        return session,code
    
    try:    
        with open(os.path.join(DATABASE_DIRNAME, "DOCUMENTS.json"), 'r') as f:
            docs = json.load(f)
    except FileNotFoundError:
        return jsonify({"error": "Database error, file not found"}), 404
    
    doc_list = {}

    for org in organizations:
        if org == session["organization"]:
            for doc in organizations[org]["documents"]:
                if doc in docs:
                    doc_list[doc] = docs[doc]

    username = request.args.get("username")
    date_filter = request.args.get("date_filter")
    date = request.args.get("date")

    if username:
        doc_list = {k: v["pub_metadata"] for k, v in doc_list.items() if v["pub_metadata"]["creator"] == username}

    if date_filter and date:
        try:
            date = datetime.strptime(date, '%d-%m-%Y')
        except ValueError:
            return jsonify({"error": "Invalid date format. Use DD-MM-YYYY."}), 400
        empty_dict = {}
        for k, v in doc_list.items():
            formatted_date = datetime.strptime(datetime.fromisoformat(v["pub_metadata"]["create_date"]).strftime('%d-%m-%Y'), '%d-%m-%Y')
            if date_filter == "nt" and formatted_date > date:
                empty_dict[k] = v["pub_metadata"]
            elif date_filter == "ot" and formatted_date < date:
                empty_dict[k] = v["pub_metadata"]
            elif date_filter == "et" and formatted_date == date:
                empty_dict[k] = v["pub_metadata"]
        doc_list = empty_dict

    if doc_list:
        return jsonify(doc_list), 200
    return "No documents found", 200

@app.route("/get/doc/metadata", methods=["GET"])
def get_doc_metadata():
    data = request.args
    required_fields = ["session_id", "document_name"]
    required_permissions = Permissions.DOC_READ
    doc_name = data.get("document_name")

    message,code = valid_query(data,required_fields)
    if code != 200:
        return message,code

    session,code = valid_session(data["session_id"])
    if code != 200:
        return session,code
    
    message, code = valid_permissions(session, required_permissions)
    if code != 200:
        return message, code
    
    message, code = valid_acl(session, doc_name, required_permissions)
    if code != 200:
        return message, code
    
    doc_handle = hashlib.sha256(doc_name.encode("utf-8")).hexdigest()

    if doc_handle not in organizations[session["organization"]]["documents"]:
        return jsonify({"error": "Document does not belong to org"}), 404
    
    try:    
        with open(os.path.join(DATABASE_DIRNAME, "DOCUMENTS.json"), 'r') as f:
            docs = json.load(f)
    except FileNotFoundError:
        return jsonify({"error": "Database error, file not found"}), 404
    
    for doc in docs.keys():
        if doc == doc_handle:
            return jsonify(docs[doc]), 200
    return "No documents found", 200

@app.route("/get/doc/file", methods=["GET"])
def get_doc_file():
    # i dont know if this is even necessary
    pass

#rep_delete_doc <session file> <document name>
@app.route("/delete/doc", methods=["POST"])
def delete_doc():
    # Verify DOC_DELETE permission
    # don't destroy information, just clear the file_handle 
    #"deleter" Add reference to the subject that deleted the file
    data = request.get_json()
    print(data)
    required_fields = ["session_id", "document_name"]
    required_permissions = Permissions.DOC_DELETE
    doc_name = data["doc_name"]

    message,code = valid_query(data,required_fields)
    if code != 200:
        return message,code

    session,code = valid_session(data["session_id"])
    if code != 200:
        return session,code

    message, code = valid_permissions(session, required_permissions)
    if code != 200:
        return message, code
    
    message, code = valid_acl(session, doc_name, required_permissions)
    if code != 200:
        return message, code
    
    doc_handle = hashlib.sha256(doc_name.encode("utf-8")).hexdigest()

    if doc_handle not in organizations[session["organization"]]["documents"]:
        return jsonify({"error": "Document does not belong to org"}), 404
    
    try:    
        with open(os.path.join(DATABASE_DIRNAME, "DOCUMENTS.json"), "r+") as jsonFile:
            data = json.load(jsonFile)
            file_handle = data[doc_handle]["pub_metadata"]["file_handle"]
            data[doc_handle]["pub_metadata"]["file_handle"] = ""
            data[doc_handle]["pub_metadata"]["deleter"] = session["username"]

            jsonFile.seek(0)  # rewind
            json.dump(data, jsonFile)
            jsonFile.truncate()

    except FileNotFoundError:
        return jsonify({"error": "Database error, file not found"}), 404
    
    return jsonify({"file_handle": file_handle}), 200

# rep_acl_doc <session file> <document name> [+/-] <role> <permission>
@app.route("/acl/doc", methods=["GET"])
def edit_acl():
    data = request.args
    required_fields = ["session_id", "doc_name", "action", "role", "permission"]
    required_permissions = Permissions.DOC_ACL
    doc_name = data["document_name"]
    action = data["action"]
    role = data["role"]
    permission = data["permission"]

    message,code = valid_query(data,required_fields)
    if code != 200:
        return message,code

    session,code = valid_session(data["session_id"])
    if code != 200:
        return session,code

    message, code = valid_permissions(session, required_permissions)
    if code != 200:
        return message, code
    
    message, code = valid_acl(session, doc_name, required_permissions)
    if code != 200:
        return message, code
    
    try:
        with open(os.path.join(DATABASE_DIRNAME, "DOCUMENTS.json"), 'r+') as f:
            docs = json.load(f)
            for doc in docs.keys():
                if doc == doc_name:
                    docs[doc]["pub_metadata"]["acl"].setdefault(role, 0)
                    if action == "+":
                        docs[doc]["pub_metadata"]["acl"][role] |= Permissions[permission]
                    elif action == "-":
                        docs[doc]["pub_metadata"]["acl"][role] &= ~Permissions[permission]
                    else:
                        return jsonify({"error": "Invalid action"}), 400
            f.seek(0)
            json.dump(docs, f)
            f.truncate()
    except FileNotFoundError:
        return jsonify({"error": "Database error, file not found"}), 404
    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500
    
    return jsonify({"message": "ACL updated successfully"}), 200

# Request keys

@app.route("/key/request", methods=["GET"])
def key_request():
    try:
        with open(os.path.join(KEYS_DIRNAME, "public_key.pem"), 'r') as f:
            public_key = f.read()
        return jsonify({"message": "Key request successful", "public_key": public_key}), 200
    except FileNotFoundError:
        return jsonify({"error": "Database error, file not found"}), 404
    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500

if __name__ == "__main__":
    signal.signal(signal.SIGTERM, exit_gracefully)
    signal.signal(signal.SIGINT, exit_gracefully)
    ensure_structure()
    create_keys()
    clear_directory(SESSION_DIRNAME)

    # here we'll load the data from storage to memory for fast access
    # load_orgs()
    try:
        app.run(host="0.0.0.0", port=5000, debug=True)
    except Exception as e:
        clear_directory(SESSION_DIRNAME)
        raise e
