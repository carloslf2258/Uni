from flask import Flask,request, jsonify
from hashlib import sha256
import json
import datetime
import os

app = Flask(__name__)

organizations = { 
    "Example_Organization":{
        "first_user":{
            "name"  : "First User",
            "email" : "first@hotmail.com",
            "pubkey": "no_pub_key",
            "status": True
        },
        "second_user":{
            "name"  : "Second User",
            "email" : "second@hotmail.com",
            "pubkey": "no_pub_key",
            "status": False
        }
    }
}
sessions = {}
documents = {}

@app.route("/organization/list")
def org_list():
    return json.dumps(organizations)

@app.route("/subject/list", methods=["GET"])
def list_subjects():
    session_id = request.args.get("s_id")
    user = request.args.get("user")
    flag = 0

    for filename in os.listdir("sessions"):                            # falta fazer a verificacao para ver se a /sessions existe
        with open( "./sessions/"+filename, 'r') as f:
            session = f.read()
        session = json.loads(session) 
        if session["s_id"] == session_id:                           # depois verificar o tempo 
            flag = 1
            org = session["organization"]
    if flag == 0:
       return jsonify({"error": "Session does not exist"})             # NEEDS A BETTER ERROR AND A SPECIFIC CODE 

    return json.dumps(organizations[org]) if not user else json.dumps(organizations[org][user]) # FALTA VERIFICAR SE A ORG EXISTE

@app.route("/organization/create", methods=["POST"])
def org_create():
    json_request = request.get_json()
    required_fields = ["org", "username", "name", "email", "pubkey"]

    if not all(field in json_request and json_request[field] is not None for field in required_fields):
        return jsonify({"error": "Missing or None fields"}),         # NEEDS A BETTER ERROR AND A SPECIFIC CODE

    org = json_request["org"]
    json_request.pop("org")
    usr = json_request["username"]
    json_request.pop("username")
    json_request[usr]["status"] = True

    if org in organizations:
        return jsonify({"error": "Org already exists"}),             # NEEDS A BETTER ERROR AND A SPECIFIC CODE

    organizations.update({ org: { usr: json_request } })
    return json.dumps(organizations)

@app.route("/session/create", methods=["POST"])
def session_create():
    data = request.get_json()

    required_fields = ["pub_key", "username", "organization"]

    if not all(key in data and data[key] is not None for key in required_fields):
        return jsonify({"error": "Missing or None fields"}), 400    # NEEDS A BETTER ERROR AND A SPECIFIC CODE

    now = datetime.datetime.now()

    pub_key = data["pub_key"]
    date_time = now.strftime("%d%m%Y%H%M%S%f")
    user = data["username"]
    org = data["organization"]

    if org not in organizations:
        return jsonify({"error": "Invalid organization"}), 400      # NEEDS A BETTER ERROR AND A SPECIFIC CODE
    if user not in organizations[org]:
        return jsonify({"error": "User not in organization"}), 400  # NEEDS A BETTER ERROR AND A SPECIFIC CODE

    s_id = pub_key+date_time                                        # MUDAR NA SEGUNDA ENTREGA PARA NAO UTILIZAR DADOS DO USER, USAR RANDOM TOKEN

    s_id = sha256(s_id.encode('utf-8')).hexdigest()
    key_list = [""]                                                 # NOT IMPLEMENTED IN FIRST DELIVERY

    lifetime = 120                                                  # in seconds

    session = {
        "s_id" : s_id,
        "organization" : org,
        "username" : user,
        "key_list" : key_list, 
        "lifetime": lifetime, 
        "time_last_method" : date_time
    }

    # lembrar que em cada metodo e preciso dar reset ao time_last_method
    # a = dt.datetime(2013,12,30,23,59,59)
    # b = dt.datetime(2013,12,31,23,59,59)

    # (b-a).total_seconds()

    directory_name = 'sessions'
    try:
        os.mkdir(directory_name)
        print(f"Directory '{directory_name}' created successfully.")
    except FileExistsError:
        print(f"Directory '{directory_name}' already exists.")
    except PermissionError:
        return jsonify({"error": "Permission denied: Unable to create '{directory_name}'."}), 403
    except Exception as e:
        return jsonify({"error": f"An error occurred: {e}"}), 500

    with open(directory_name+"/"+org+"_"+user+".json", 'w') as f:
        f.write(json.dumps(session))

    return json.dumps({ "s_id" : s_id })

@app.route("/document/list", methods=["GET"])
def list_documents():
    org_name = request.args.get("organization")

    if not org_name:
        return jsonify({"error": "Organization name is required"}), 400

    if org_name not in organizations:
        return jsonify({"error": "Organization does not exist"}), 400

    doc_handles = organizations[org_name]["documents"]
    docs = [documents[handle] for handle in doc_handles]

    return jsonify({"documents": docs})

@app.route("/subjects/list", methods=["GET"])
def subjects_list():
    org_name = request.args.get("organization") 

    if not org_name:
        return jsonify({"error": "Organization name is required"}), 400

    if org_name not in organizations:
        return jsonify({"error": "Organization does not exist"}), 400

    if "subjects" not in organizations[org_name]:
        return jsonify({"error": "No subjects found for this organization"}), 404

    subjects = organizations[org_name]["subjects"] 

    return jsonify({"subjects": subjects}), 200

@app.route("/subject/activate", methods=["GET"])
def subject_activate():
    data = request.get_json()

    required_fields = ["session", "username"]

    if not all(key in data and data[key] is not None for key in required_fields):
        return jsonify({"error": "Missing or None fields"}), 400    # NEEDS A BETTER ERROR AND A SPECIFIC CODE

    session = data["session"]
    username = data["username"]

    for org in organizations:
        if username == org["username"]:
            organizations[org]["username"]["status"] = True
        else:
            return jsonify({"error": "User doesn't belong to any org"}), 400    # NEEDS A BETTER ERROR AND A SPECIFIC CODE

@app.route("/subject/suspend", methods=["GET"])
def subject_suspend():
    data = request.get_json()

    required_fields = ["session", "username"]

    if not all(key in data and data[key] is not None for key in required_fields):
        return jsonify({"error": "Missing or None fields"}), 400    # NEEDS A BETTER ERROR AND A SPECIFIC CODE

    session = data["session"]
    username = data["username"]

    for org in organizations:
        if username == org["username"]:
            organizations[org]["username"]["status"] = False
        else:
            return jsonify({"error": "User doesn't belong to any org"}), 400    # NEEDS A BETTER ERROR AND A SPECIFIC CODE

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)