HOW TO RUN:

- Run a Virtual Enviroment with requirements.txt
- Start server with python repository.py
- Each script was made to execute each method easily with ./method_name <param1> <param2> <...>
- Methods Implemented:
    - rep_create_org <organization> <username> <name> <email> <public key file>
    - rep_list_orgs
    - rep_create_session <organization> <username> <password> <credentials file> <session file>
    - rep_subject_credentials <password> <credentials file>
    - rep_decrypt_file <encrypted file> <encryption metadata>
    - rep_encrypt_example
    - rep_list_subjects <session file> [username] ( not every exception is tested ) 
