###########################################################

#					Job done by:
#				Diogo Carvalho, n113221
#				José Fernandes, n114472
#				Carlos Verenzuela, n114597

###########################################################

# REPOSITORY METHODS

*italic = (mostly or fully) implemented*

## NO SESSION FILE REQUIRED

### Organization

- *GET /organization/list*
    - Query: None

- *POST /organization/create*
    - Input JSON: {"org_name":"...","username":"...","name":"...","email":"..."}

### Session

- *POST /session/create*
    - Input JSON: {"organization":"...","username":"...","credentials_file":"..."}

### File

- *GET /file/get*
    - Query: file handle, optionally file

## SESSION FILE REQUIRED

### Subject

- *POST /subjects/list*
    - Query: session_file, optionally username (to search for)

- *POST /subject/add*
    - Input JSON: {"session_file":"...","username":"...","name":"...","email":"..."}

- *POST /subject/suspend*
    - Input JSON: {"session_file":"...","username":"..."}

- *POST /subject/activate*
    - Input JSON: {"session_file":"...","username":"..."}

### Document

- *POST /document/add*
    - Input JSON: {"session_file":"...","document_name":"...","file":"..."}

- *GET /document/list*
    - Query: None

- *GET /get/doc/metadata*
    - Query: session_file, document_name

- *GET /get/doc/file*
    - Query: session_file, document_name, optionally file

- *POST /delete/doc*
    - Input JSON: {"session_file":"...","document_name":"..."}

# CLIENT METHODS

- *rep_create_org <organization> <username> <name> <email> <public key file>*
- *rep_list_orgs*
- *rep_get_file <file_handle> <file_name>*
- *rep_add_doc <session file> <document name> <file>*
- *rep_list_docs <session file> [ -s username] [ -d nt/ot/et ]*
- *rep_create_session <organization> <username> <password> <credentials file> <session file>*
- *rep_list_subjects <session file> <username>*
- *rep_subject_credentials <password> <credentials file>*
- *rep_decrypt_file <encrypted_file> <metadata_file>*
- *rep_assume_role <session file> <role_name>*
- *rep_drop_role <session file> <role_name>*
- *rep_add_role <session file> <role_name>*
- *rep_list_roles <session file> <role_name>*