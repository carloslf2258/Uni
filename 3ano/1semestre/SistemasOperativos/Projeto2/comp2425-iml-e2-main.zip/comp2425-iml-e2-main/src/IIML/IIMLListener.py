# Generated from IIML.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .IIMLParser import IIMLParser
else:
    from IIMLParser import IIMLParser

# This class defines a complete listener for a parse tree produced by IIMLParser.
class IIMLListener(ParseTreeListener):

    # Enter a parse tree produced by IIMLParser#program.
    def enterProgram(self, ctx:IIMLParser.ProgramContext):
        pass

    # Exit a parse tree produced by IIMLParser#program.
    def exitProgram(self, ctx:IIMLParser.ProgramContext):
        pass


    # Enter a parse tree produced by IIMLParser#statement.
    def enterStatement(self, ctx:IIMLParser.StatementContext):
        pass

    # Exit a parse tree produced by IIMLParser#statement.
    def exitStatement(self, ctx:IIMLParser.StatementContext):
        pass


    # Enter a parse tree produced by IIMLParser#assignment.
    def enterAssignment(self, ctx:IIMLParser.AssignmentContext):
        pass

    # Exit a parse tree produced by IIMLParser#assignment.
    def exitAssignment(self, ctx:IIMLParser.AssignmentContext):
        pass


    # Enter a parse tree produced by IIMLParser#type.
    def enterType(self, ctx:IIMLParser.TypeContext):
        pass

    # Exit a parse tree produced by IIMLParser#type.
    def exitType(self, ctx:IIMLParser.TypeContext):
        pass


    # Enter a parse tree produced by IIMLParser#rowColStm.
    def enterRowColStm(self, ctx:IIMLParser.RowColStmContext):
        pass

    # Exit a parse tree produced by IIMLParser#rowColStm.
    def exitRowColStm(self, ctx:IIMLParser.RowColStmContext):
        pass


    # Enter a parse tree produced by IIMLParser#imageCreate.
    def enterImageCreate(self, ctx:IIMLParser.ImageCreateContext):
        pass

    # Exit a parse tree produced by IIMLParser#imageCreate.
    def exitImageCreate(self, ctx:IIMLParser.ImageCreateContext):
        pass


    # Enter a parse tree produced by IIMLParser#shapeCircle.
    def enterShapeCircle(self, ctx:IIMLParser.ShapeCircleContext):
        pass

    # Exit a parse tree produced by IIMLParser#shapeCircle.
    def exitShapeCircle(self, ctx:IIMLParser.ShapeCircleContext):
        pass


    # Enter a parse tree produced by IIMLParser#shapeRect.
    def enterShapeRect(self, ctx:IIMLParser.ShapeRectContext):
        pass

    # Exit a parse tree produced by IIMLParser#shapeRect.
    def exitShapeRect(self, ctx:IIMLParser.ShapeRectContext):
        pass


    # Enter a parse tree produced by IIMLParser#shapeCross.
    def enterShapeCross(self, ctx:IIMLParser.ShapeCrossContext):
        pass

    # Exit a parse tree produced by IIMLParser#shapeCross.
    def exitShapeCross(self, ctx:IIMLParser.ShapeCrossContext):
        pass


    # Enter a parse tree produced by IIMLParser#shapePlus.
    def enterShapePlus(self, ctx:IIMLParser.ShapePlusContext):
        pass

    # Exit a parse tree produced by IIMLParser#shapePlus.
    def exitShapePlus(self, ctx:IIMLParser.ShapePlusContext):
        pass


    # Enter a parse tree produced by IIMLParser#forStmt.
    def enterForStmt(self, ctx:IIMLParser.ForStmtContext):
        pass

    # Exit a parse tree produced by IIMLParser#forStmt.
    def exitForStmt(self, ctx:IIMLParser.ForStmtContext):
        pass


    # Enter a parse tree produced by IIMLParser#readStmt.
    def enterReadStmt(self, ctx:IIMLParser.ReadStmtContext):
        pass

    # Exit a parse tree produced by IIMLParser#readStmt.
    def exitReadStmt(self, ctx:IIMLParser.ReadStmtContext):
        pass


    # Enter a parse tree produced by IIMLParser#drawStmt.
    def enterDrawStmt(self, ctx:IIMLParser.DrawStmtContext):
        pass

    # Exit a parse tree produced by IIMLParser#drawStmt.
    def exitDrawStmt(self, ctx:IIMLParser.DrawStmtContext):
        pass


    # Enter a parse tree produced by IIMLParser#storeStmt.
    def enterStoreStmt(self, ctx:IIMLParser.StoreStmtContext):
        pass

    # Exit a parse tree produced by IIMLParser#storeStmt.
    def exitStoreStmt(self, ctx:IIMLParser.StoreStmtContext):
        pass


    # Enter a parse tree produced by IIMLParser#ScaleOpExpr.
    def enterScaleOpExpr(self, ctx:IIMLParser.ScaleOpExprContext):
        pass

    # Exit a parse tree produced by IIMLParser#ScaleOpExpr.
    def exitScaleOpExpr(self, ctx:IIMLParser.ScaleOpExprContext):
        pass


    # Enter a parse tree produced by IIMLParser#PixelOpAddSub.
    def enterPixelOpAddSub(self, ctx:IIMLParser.PixelOpAddSubContext):
        pass

    # Exit a parse tree produced by IIMLParser#PixelOpAddSub.
    def exitPixelOpAddSub(self, ctx:IIMLParser.PixelOpAddSubContext):
        pass


    # Enter a parse tree produced by IIMLParser#UnaryExpr.
    def enterUnaryExpr(self, ctx:IIMLParser.UnaryExprContext):
        pass

    # Exit a parse tree produced by IIMLParser#UnaryExpr.
    def exitUnaryExpr(self, ctx:IIMLParser.UnaryExprContext):
        pass


    # Enter a parse tree produced by IIMLParser#PixelOpMulDiv.
    def enterPixelOpMulDiv(self, ctx:IIMLParser.PixelOpMulDivContext):
        pass

    # Exit a parse tree produced by IIMLParser#PixelOpMulDiv.
    def exitPixelOpMulDiv(self, ctx:IIMLParser.PixelOpMulDivContext):
        pass


    # Enter a parse tree produced by IIMLParser#IndexExpr.
    def enterIndexExpr(self, ctx:IIMLParser.IndexExprContext):
        pass

    # Exit a parse tree produced by IIMLParser#IndexExpr.
    def exitIndexExpr(self, ctx:IIMLParser.IndexExprContext):
        pass


    # Enter a parse tree produced by IIMLParser#StringCastExpr.
    def enterStringCastExpr(self, ctx:IIMLParser.StringCastExprContext):
        pass

    # Exit a parse tree produced by IIMLParser#StringCastExpr.
    def exitStringCastExpr(self, ctx:IIMLParser.StringCastExprContext):
        pass


    # Enter a parse tree produced by IIMLParser#PercentageCastExpr.
    def enterPercentageCastExpr(self, ctx:IIMLParser.PercentageCastExprContext):
        pass

    # Exit a parse tree produced by IIMLParser#PercentageCastExpr.
    def exitPercentageCastExpr(self, ctx:IIMLParser.PercentageCastExprContext):
        pass


    # Enter a parse tree produced by IIMLParser#LiteralExpr.
    def enterLiteralExpr(self, ctx:IIMLParser.LiteralExprContext):
        pass

    # Exit a parse tree produced by IIMLParser#LiteralExpr.
    def exitLiteralExpr(self, ctx:IIMLParser.LiteralExprContext):
        pass


    # Enter a parse tree produced by IIMLParser#VarExpr.
    def enterVarExpr(self, ctx:IIMLParser.VarExprContext):
        pass

    # Exit a parse tree produced by IIMLParser#VarExpr.
    def exitVarExpr(self, ctx:IIMLParser.VarExprContext):
        pass


    # Enter a parse tree produced by IIMLParser#NumberCastExpr.
    def enterNumberCastExpr(self, ctx:IIMLParser.NumberCastExprContext):
        pass

    # Exit a parse tree produced by IIMLParser#NumberCastExpr.
    def exitNumberCastExpr(self, ctx:IIMLParser.NumberCastExprContext):
        pass


    # Enter a parse tree produced by IIMLParser#ArithOpMulDiv.
    def enterArithOpMulDiv(self, ctx:IIMLParser.ArithOpMulDivContext):
        pass

    # Exit a parse tree produced by IIMLParser#ArithOpMulDiv.
    def exitArithOpMulDiv(self, ctx:IIMLParser.ArithOpMulDivContext):
        pass


    # Enter a parse tree produced by IIMLParser#ListExpr.
    def enterListExpr(self, ctx:IIMLParser.ListExprContext):
        pass

    # Exit a parse tree produced by IIMLParser#ListExpr.
    def exitListExpr(self, ctx:IIMLParser.ListExprContext):
        pass


    # Enter a parse tree produced by IIMLParser#UnaryMinusExpr.
    def enterUnaryMinusExpr(self, ctx:IIMLParser.UnaryMinusExprContext):
        pass

    # Exit a parse tree produced by IIMLParser#UnaryMinusExpr.
    def exitUnaryMinusExpr(self, ctx:IIMLParser.UnaryMinusExprContext):
        pass


    # Enter a parse tree produced by IIMLParser#ArithOpAddSub.
    def enterArithOpAddSub(self, ctx:IIMLParser.ArithOpAddSubContext):
        pass

    # Exit a parse tree produced by IIMLParser#ArithOpAddSub.
    def exitArithOpAddSub(self, ctx:IIMLParser.ArithOpAddSubContext):
        pass


    # Enter a parse tree produced by IIMLParser#NumberLiteral.
    def enterNumberLiteral(self, ctx:IIMLParser.NumberLiteralContext):
        pass

    # Exit a parse tree produced by IIMLParser#NumberLiteral.
    def exitNumberLiteral(self, ctx:IIMLParser.NumberLiteralContext):
        pass


    # Enter a parse tree produced by IIMLParser#PercentageLiteral.
    def enterPercentageLiteral(self, ctx:IIMLParser.PercentageLiteralContext):
        pass

    # Exit a parse tree produced by IIMLParser#PercentageLiteral.
    def exitPercentageLiteral(self, ctx:IIMLParser.PercentageLiteralContext):
        pass


    # Enter a parse tree produced by IIMLParser#StringLiteral.
    def enterStringLiteral(self, ctx:IIMLParser.StringLiteralContext):
        pass

    # Exit a parse tree produced by IIMLParser#StringLiteral.
    def exitStringLiteral(self, ctx:IIMLParser.StringLiteralContext):
        pass



del IIMLParser