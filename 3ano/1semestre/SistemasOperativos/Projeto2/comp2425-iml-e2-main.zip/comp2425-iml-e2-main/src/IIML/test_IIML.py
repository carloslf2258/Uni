import IIMLMain
from Types import ImagePGM

def test_main():
   test = IIMLMain.main("../../examples/des-iiml-01.iiml")
   test.store("test.pgm")

if __name__ == "__main__":
    test_main()
    print("Test completed successfully.")