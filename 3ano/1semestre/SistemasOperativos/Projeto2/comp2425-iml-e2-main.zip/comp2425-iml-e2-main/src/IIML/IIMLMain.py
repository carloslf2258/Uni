import sys
import os
if (sys.path[0].split("/")[0] != "src"):
    sys.path.insert(0, os.path.abspath(os.path.join("..", "")))

from antlr4 import *
from IIML.IIMLLexer import IIMLLexer
from IIML.IIMLParser import IIMLParser
from IIML.Visitor import Visitor
from IIML.Types import ImagePGM

def main(filename=None):
   visitor0 = Visitor()
   if filename is not None:
      if filename.endswith('.iiml'):
         print(f"Processing file: {filename}")
         input_stream = FileStream(filename)
      else:
         raise ValueError("Filename must end with .iiml")
   else:
      input_stream = StdinStream()
   lexer = IIMLLexer(input_stream)
   stream = CommonTokenStream(lexer)
   parser = IIMLParser(stream)
   tree = parser.program()
   if parser.getNumberOfSyntaxErrors() == 0:
      result = visitor0.visit(tree)
      return result

if __name__ == '__main__':
   main()
