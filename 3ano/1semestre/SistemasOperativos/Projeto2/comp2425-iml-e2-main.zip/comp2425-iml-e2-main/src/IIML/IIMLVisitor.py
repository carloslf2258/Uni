# Generated from IIML.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .IIMLParser import IIMLParser
else:
    from IIMLParser import IIMLParser

# This class defines a complete generic visitor for a parse tree produced by IIMLParser.

class IIMLVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by IIMLParser#program.
    def visitProgram(self, ctx:IIMLParser.ProgramContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#statement.
    def visitStatement(self, ctx:IIMLParser.StatementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#assignment.
    def visitAssignment(self, ctx:IIMLParser.AssignmentContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#type.
    def visitType(self, ctx:IIMLParser.TypeContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#rowColStm.
    def visitRowColStm(self, ctx:IIMLParser.RowColStmContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#imageCreate.
    def visitImageCreate(self, ctx:IIMLParser.ImageCreateContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#shapeCircle.
    def visitShapeCircle(self, ctx:IIMLParser.ShapeCircleContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#shapeRect.
    def visitShapeRect(self, ctx:IIMLParser.ShapeRectContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#shapeCross.
    def visitShapeCross(self, ctx:IIMLParser.ShapeCrossContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#shapePlus.
    def visitShapePlus(self, ctx:IIMLParser.ShapePlusContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#forStmt.
    def visitForStmt(self, ctx:IIMLParser.ForStmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#readStmt.
    def visitReadStmt(self, ctx:IIMLParser.ReadStmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#drawStmt.
    def visitDrawStmt(self, ctx:IIMLParser.DrawStmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#storeStmt.
    def visitStoreStmt(self, ctx:IIMLParser.StoreStmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#ScaleOpExpr.
    def visitScaleOpExpr(self, ctx:IIMLParser.ScaleOpExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#PixelOpAddSub.
    def visitPixelOpAddSub(self, ctx:IIMLParser.PixelOpAddSubContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#UnaryExpr.
    def visitUnaryExpr(self, ctx:IIMLParser.UnaryExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#PixelOpMulDiv.
    def visitPixelOpMulDiv(self, ctx:IIMLParser.PixelOpMulDivContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#IndexExpr.
    def visitIndexExpr(self, ctx:IIMLParser.IndexExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#StringCastExpr.
    def visitStringCastExpr(self, ctx:IIMLParser.StringCastExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#PercentageCastExpr.
    def visitPercentageCastExpr(self, ctx:IIMLParser.PercentageCastExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#LiteralExpr.
    def visitLiteralExpr(self, ctx:IIMLParser.LiteralExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#VarExpr.
    def visitVarExpr(self, ctx:IIMLParser.VarExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#NumberCastExpr.
    def visitNumberCastExpr(self, ctx:IIMLParser.NumberCastExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#ArithOpMulDiv.
    def visitArithOpMulDiv(self, ctx:IIMLParser.ArithOpMulDivContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#ListExpr.
    def visitListExpr(self, ctx:IIMLParser.ListExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#UnaryMinusExpr.
    def visitUnaryMinusExpr(self, ctx:IIMLParser.UnaryMinusExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#ArithOpAddSub.
    def visitArithOpAddSub(self, ctx:IIMLParser.ArithOpAddSubContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#NumberLiteral.
    def visitNumberLiteral(self, ctx:IIMLParser.NumberLiteralContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#PercentageLiteral.
    def visitPercentageLiteral(self, ctx:IIMLParser.PercentageLiteralContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IIMLParser#StringLiteral.
    def visitStringLiteral(self, ctx:IIMLParser.StringLiteralContext):
        return self.visitChildren(ctx)



del IIMLParser