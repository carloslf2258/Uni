from skimage import morphology
from PIL import Image as PILImage
from skimage.transform import resize
import numpy

class ImagePGM:

    @staticmethod
    def extract_metadata(path: str) -> dict:
        metadata = {}
        with open(path, 'rb') as f:
            values = []
            while len(values) < 4:
                line = f.readline()
                if line.startswith(b'#') or line.strip() == b'': # comments
                    continue
                values.extend(line.strip().split())
            metadata['format'] = values[0].decode()  # P2 ou P5
            metadata['width'] = int(values[1])
            metadata['height'] = int(values[2])
            metadata['maxval'] = int(values[3])
        return metadata

    @staticmethod
    def load(path: str) -> 'ImagePGM':
        img = PILImage.open(path)
        metadata = ImagePGM.extract_metadata(path)
        array = numpy.array(img, dtype=float) / metadata['maxval']
        return ImagePGM(array, metadata)

    @staticmethod
    def create_gif(image_list,output_path,duration=500):
        if not all(isinstance(img, ImagePGM) for img in image_list):
            raise TypeError("Todos os elementos da lista devem ser do tipo ImagePGM.")
        pil_images = [PILImage.fromarray((img.data * 255).astype('uint8')) for img in image_list]
        pil_images[0].save(output_path,save_all=True,append_images=pil_images[1:],duration=duration, loop=0)

    def __init__(self, data:numpy.ndarray, metadata:dict = None):
        if not isinstance(data, numpy.ndarray):
            raise TypeError("Data must be a numpy array.")
        if len(data.shape) != 2: 
           raise ValueError("Imagem deve ser uma matriz 2D")
        self.data = data
        self.metadata = metadata or {}

    def __add__(self, other):
        if isinstance(other, ImagePGM):
            if self.data.shape != other.data.shape:
                raise ValueError("Images must be the same size for addition.")
            result = numpy.clip(self.data + other.data, 0, 1)
            return ImagePGM(result, self.metadata)
        elif isinstance(other, (int, float)):
            result = numpy.clip(self.data + float(other), 0, 1)
            return ImagePGM(result, self.metadata)
        elif isinstance(other, Percentage):
             result = numpy.clip(self.data + self.data*other.to_float(), 0, 1)
             return ImagePGM(result, self.metadata)
        elif isinstance(other, Number):
            result = numpy.clip(self.data + float(other.value), 0, 1)
            return ImagePGM(result, self.metadata)
        else:
            raise TypeError(f"Type {type(other)} not supported for addition.")
        
    def __sub__(self, other):
        if isinstance(other, ImagePGM):
            if self.data.shape != other.data.shape:
                raise ValueError("Images must be the same size for subtraction.")
            result = numpy.clip(self.data - other.data, 0, 1)
            return ImagePGM(result, self.metadata)
        elif isinstance(other, (int, float)):
            result = numpy.clip(self.data - float(other), 0, 1)
            return ImagePGM(result, self.metadata)
        elif isinstance(other, Percentage):
            result = numpy.clip(self.data - self.data*other.to_float(), 0, 1)
            return ImagePGM(result, self.metadata)
        elif isinstance(other, Number):
            result = numpy.clip(self.data - float(other.value), 0, 1)
            return ImagePGM(result, self.metadata)
        else:
            raise TypeError(f"Type {type(other)} not supported for subtraction.")

    def __mul__(self, other):
        if isinstance(other, ImagePGM):
            if self.data.shape != other.data.shape:
                raise ValueError("Images must be the same size for multiplication.")
            result = numpy.clip(self.data * other.data, 0, 1)
            return ImagePGM(result, self.metadata)

        if isinstance(other, Percentage):
            value = other.to_float()
        elif isinstance(other, (int, float)):
            value = float(other)
        elif isinstance(other, Number):
            value = float(other.value)
        else:
            raise TypeError("Type not supported for multiplication.")
        result = numpy.clip(self.data * value, 0, 1)
        return ImagePGM(result, self.metadata)

    def __truediv__(self, other):
        if isinstance(other, ImagePGM):
            if self.data.shape != other.data.shape:
                raise ValueError("Images must be the same size for division.")
            if numpy.any(other.data == 0):
                raise ZeroDivisionError("Division by zero in image data.")
            result = numpy.clip(self.data / (other.data + 1e-10), 0, 1)
            return ImagePGM(result, self.metadata)

        if isinstance(other, Percentage):
            value = other.to_float()
        elif isinstance(other, Number):
            value = float(other.value)
        elif isinstance(other, (int, float)):
            value = float(other)
        else:
            raise TypeError("Tipe not supported for division.")

        if value == 0:
            raise ZeroDivisionError("Division by zero.")

        result = numpy.clip(self.data / value, 0, 1)
        return ImagePGM(result, self.metadata)


    def store(self, path: str) -> None:
        array = (self.data * self.metadata.get('maxval', 255)).astype('uint8')
        img = PILImage.fromarray(array, mode='L')
        img.save(path)

    def draw(self) -> None:

        array = (self.data * self.metadata.get('maxval', 255)).astype('uint8')
        img = PILImage.fromarray(array, mode='L')
        img.show()

    def get_metadata(self, key:str = None) -> dict:
        if key is None:
            return self.metadata
        if key not in self.metadata:
            raise KeyError(f"Metadata key '{key}' not found.")
        return self.metadata.get(key, None)

    def invert(self):
        inverted_data = 1 - self.data
        return ImagePGM(inverted_data, self.metadata)

    def rows(self):
        return self.data.shape[0]
    
    def columns(self):
        return self.data.shape[1]
    
    # Scale operations
    # Horizontal scale:  -*
    def scale_horizontal(self, factor):
        new_cols = int(self.columns() * float(factor))
        resized = resize(self.data, (self.rows(), new_cols), preserve_range=True)
        return ImagePGM(resized)

    # Vertical scale:  |*
    def scale_vertical(self, factor):
        new_rows = int(self.rows() * float(factor))
        resized = resize(self.data, (new_rows, self.columns()), preserve_range=True)
        return ImagePGM(resized)

    # Scale both:  +*
    def scale_both(self, factor):
        return self.scale_horizontal(factor).scale_vertical(factor)

    # Draw operations
    def draw_circle(self, center_x, center_y, radius, intensity=1):
        for y in range(self.data.shape[0]):
            for x in range(self.data.shape[1]):
                if (x - center_x) ** 2 + (y - center_y) ** 2 <= radius ** 2:
                    if 0 <= y < self.data.shape[0] and 0 <= x < self.data.shape[1]:
                        self.data[y, x] = intensity

    def draw_rect(self, top_left_x, top_left_y, width, height, intensity=1):
        for y in range(top_left_y, top_left_y + height):
            for x in range(top_left_x, top_left_x + width):
                if 0 <= y < self.data.shape[0] and 0 <= x < self.data.shape[1]:
                    self.data[y, x] = intensity


    def draw_plus(self, center_x, center_y, width, height, intensity=1):
        half_w = width // 2
        half_h = height // 2
        for x in range(center_x - half_w, center_x + half_w + 1):
            if 0 <= x < self.data.shape[1] and 0 <= center_y < self.data.shape[0]:
                self.data[center_y, x] = intensity
        for y in range(center_y - half_h, center_y + half_h + 1):
            if 0 <= y < self.data.shape[0] and 0 <= center_x < self.data.shape[1]:
                self.data[y, center_x] = intensity

    def draw_cross(self, center_x, center_y, width, height, intensity=1):
            half_w = width // 2
            half_h = height // 2
            for d in range(-min(half_w, half_h), min(half_w, half_h) + 1):
                x = center_x + d
                y = center_y + d
                if 0 <= x < self.data.shape[1] and 0 <= y < self.data.shape[0]:
                    self.data[y, x] = intensity
            for d in range(-min(half_w, half_h), min(half_w, half_h) + 1):
                x = center_x + d
                y = center_y - d
                if 0 <= x < self.data.shape[1] and 0 <= y < self.data.shape[0]:
                    self.data[y, x] = intensity
        


    # Flip operations
    # Flip vertical: -
    def flip_vertical(self):
        return ImagePGM(numpy.flipud(self.data), self.metadata)
    # Flip horizontal: /
    def flip_horizontal(self):
        return ImagePGM(numpy.fliplr(self.data), self.metadata)
    # Flip both:  +
    def flip_both(self):
        return ImagePGM(numpy.flip(self.data, axis=(0, 1)), self.metadata)

    # Morphological operations

    # Erosion:  -
    def erode(self, filtro):
        filtro_data = filtro.data if isinstance(filtro, ImagePGM) else filtro
        result_metadata = self.metadata.copy()
        if isinstance(filtro, ImagePGM):
            result_metadata['filter_metadata'] = filtro.metadata
        return ImagePGM(morphology.erosion(self.data, filtro_data), result_metadata)
    # Dilation:  +
    def dilate(self, filtro):
        filtro_data = filtro.data if isinstance(filtro, ImagePGM) else filtro
        result_metadata = self.metadata.copy()
        if isinstance(filtro, ImagePGM):
            result_metadata['filter_metadata'] = filtro.metadata
        return ImagePGM(morphology.dilation(self.data, filtro_data), result_metadata)
    # Opening:  -*
    def open(self, filtro):
        filtro_data = filtro.data if isinstance(filtro, ImagePGM) else filtro
        result_metadata = self.metadata.copy()
        if isinstance(filtro, ImagePGM):
            result_metadata['filter_metadata'] = filtro.metadata
        return ImagePGM(morphology.opening(self.data, filtro_data), result_metadata)
    # Closing:  +*
    def close(self, filtro):
        filtro_data = filtro.data if isinstance(filtro, ImagePGM) else filtro
        result_metadata = self.metadata.copy()
        if isinstance(filtro, ImagePGM):
            result_metadata['filter_metadata'] = filtro.metadata
        return ImagePGM(morphology.closing(self.data, filtro_data), result_metadata)
    # Top hat:
    def top_hat(self, filtro):
        filtro_data = filtro.data if isinstance(filtro, ImagePGM) else filtro
        result_metadata = self.metadata.copy()
        if isinstance(filtro, ImagePGM):
            result_metadata['filter_metadata'] = filtro.metadata
        return ImagePGM(morphology.white_tophat(self.data, filtro_data), result_metadata)
    # Black hat:
    def black_hat(self, filtro):
        filtro_data = filtro.data if isinstance(filtro, ImagePGM) else filtro
        result_metadata = self.metadata.copy()
        if isinstance(filtro, ImagePGM):
            result_metadata['filter_metadata'] = filtro.metadata
        return ImagePGM(morphology.black_tophat(self.data, filtro_data), result_metadata)

    def __str__(self):
        return f"ImagePGM({self.metadata})"
    
    def __eq__(self, other):
        if isinstance(other, ImagePGM):
            if isinstance(other, ImagePGM):
               if self.data.shape != other.data.shape:
                    return False
            return self.data == other.data
        if isinstance(other, (int, float)):
            return numpy.all(self.data == other)
        if isinstance(other, Percentage):
            return numpy.all(self.data == other.to_float())
        if isinstance(other, Number):
            return numpy.all(self.data == other.value)
        raise TypeError("Unsupported type for comparison with ImagePGM")
    
    def __ne__(self, other):
        if isinstance(other, ImagePGM):
            return not self.__eq__(other)
        if isinstance(other, (int, float)):
            return not self.data == other
        if isinstance(other, Percentage):
            return not self.data == other.to_float()
        if isinstance(other, Number):
            return not self.data == other.value
        raise TypeError("Unsupported type for comparison with ImagePGM")
        
    def __lt__(self, other):
        if isinstance(other, ImagePGM):
            return self.data < other.data
        if isinstance(other, (int, float)):
            return self.data < other
        if isinstance(other, Percentage):
            return self.data < other.to_float()
        if isinstance(other, Number):
            return self.data < other.value
        raise TypeError("Unsupported type for comparison with ImagePGM")

    def __le__(self, other):
        if isinstance(other, ImagePGM):
            return self.data <= other.data
        if isinstance(other, (int, float)):
            return self.data <= other
        if isinstance(other, Percentage):
            return self.data <= other.to_float()
        if isinstance(other, Number):
            return self.data <= other.value
        raise TypeError("Unsupported type for comparison with ImagePGM")

    def __gt__(self, other):
        if isinstance(other, ImagePGM):
            return self.data > other.data
        if isinstance(other, (int, float)):
            return self.data > other
        if isinstance(other, Percentage):
            return self.data > other.to_float()
        if isinstance(other, Number):
            return self.data > other.value
        else:
            raise TypeError("Unsupported type for comparison with ImagePGM")
    def __ge__(self, other):
        if isinstance(other, ImagePGM):
            return self.data >= other.data
        if isinstance(other, (int, float)):
            return self.data >= other
        if isinstance(other, Percentage):
            return self.data >= other.to_float()
        if isinstance(other, Number):
            return self.data >= other.value
        else: 
            raise TypeError("Unsupported type for comparison with ImagePGM")

    def logical_expression(self, operator, condition1, condition2):
        if operator == 'and':
            return numpy.logical_and(condition1, condition2)
        elif operator == 'or':
            return numpy.logical_or(condition1, condition2)
        elif operator == 'not':
            return numpy.logical_not(condition1)
        else:
            raise ValueError(f"Operator '{operator}' not supported.")

    def any_pixel(self, condition):
        return numpy.any(condition)

    def all_pixel(self, condition):
        return numpy.all(condition)

    def count_pixel_in(self, intensity):
        if isinstance(intensity, (int, float)):
            return numpy.sum(self.data == intensity)
        elif isinstance(intensity, Percentage):
            return numpy.sum(self.data == intensity.to_float())
        elif isinstance(intensity, Number):
            return numpy.sum(self.data == intensity.value)
        else:
            raise TypeError("Type not supported for counting pixels.")


class Percentage:
    def __init__(self, value):
        if isinstance(value, str) and value.strip().endswith('%'):
            try:
                value = float(value.strip()[:-1]) / 100
            except ValueError:
                raise ValueError("Invalid percentage string format.")
        if isinstance(value, String) and value.strip().endswith('%'):
            try:
                value = float(value.strip()[:-1]) / 100
            except ValueError:
                raise ValueError("Invalid percentage string format.")
        elif isinstance(value, (int, float)):
            value = float(value)
        elif isinstance(value, Percentage):
            value = value.value
        elif isinstance(value, Number):
            value = float(value.value)
        else:
            raise TypeError("Percentage must be a number or string ending with '%'")

        self.value = value

    def __str__(self):
        return f"{self.value * 100:.1f}%"

    def __repr__(self):
        return f"Percentage({self.value})"

    def __add__(self, other):
        if isinstance(other, Percentage):
            return Percentage(self.value + other.value)
        elif isinstance(other, (int, float)):
            return float(self.value)*other + other
        elif isinstance(other, str) and other.strip().endswith('%'):
            try:
                other_value = float(other.strip()[:-1]) / 100
                return Percentage(self.value + other_value)
            except ValueError:
                raise ValueError("Invalid percentage string format.")
        elif isinstance(other, Number):
            return Number(self.value*other.value + other.value)
        elif isinstance(other, ImagePGM):
             result = numpy.clip(other.data + other.data*self.to_float(), 0, 1)
             return ImagePGM(result, other.metadata.copy())
        else:
            raise TypeError("Unsupported type for addition with Percentage")

    def __sub__(self, other):
        if isinstance(other, Percentage):
            return Percentage(self.value - other.value)
        elif isinstance(other, (int, float)):
            return float(self.value)*other - other
        elif isinstance(other, str) and other.strip().endswith('%'):
            try:
                other_value = float(other.strip()[:-1]) / 100
                return Percentage(self.value - other_value)
            except ValueError:
                raise ValueError("Invalid percentage string format.")
        elif isinstance(other, Number):
            return Number(self.value*other.value - other.value)
        elif isinstance(other, ImagePGM):
            result = numpy.clip(other.data - other.data*self.to_float(), 0, 1)
            return ImagePGM(result, other.metadata.copy())
        else:
            raise TypeError("Unsupported type for subtraction with Percentage")

    def __mul__(self, other):
        if isinstance(other, Percentage):
            return Percentage(self.value * other.value)
        elif isinstance(other, (int, float)):
            return self.value * other
        elif isinstance(other, str) and other.strip().endswith('%'):
            try:
                other_value = float(other.strip()[:-1]) / 100
                return Percentage(self.value * other_value)
            except ValueError:
                raise ValueError("Invalid percentage string format.")
        elif isinstance(other, Number):
            return Number(self.value * other.value)
        elif isinstance(other, ImagePGM):
            result = numpy.clip(other.data * self.to_float(), 0, 1)
            return ImagePGM(result, other.metadata.copy())
        else:
            raise TypeError("Unsupported type for multiplication with Percentage")

    def __truediv__(self, other):
        if isinstance(other, Percentage):
            denom = other.value
            if denom == 0:
               raise ZeroDivisionError("Division by zero is not allowed.")
            return Percentage(self.value / denom)
        elif isinstance(other, (int, float)):
            denom = other
        elif isinstance(other, str) and other.strip().endswith('%'):
            try:
                denom = float(other.strip()[:-1]) / 100
                if denom == 0:
                   raise ZeroDivisionError("Division by zero is not allowed.")
                return Percentage(self.value / denom)
            except ValueError:
                raise ValueError("Invalid percentage string format.")
        elif isinstance(other, Number):
            denom = other.value
            if denom == 0:
                raise ZeroDivisionError("Division by zero is not allowed.")
            return Number(self.value / denom)            
        else:
            raise TypeError("Unsupported type for division with Percentage")
        if denom == 0:
            raise ZeroDivisionError("Division by zero is not allowed.")
        return self.value / denom

    def to_float(self):
        return self.value
    
    def __eq__(self, other):
        if isinstance(other, Percentage):
            return self.value == other.value
        raise TypeError("Unsupported type for comparison with Percentage")
    
    def __ne__(self, other):
        if isinstance(other, Percentage):
            return not self.__eq__(other)
        raise TypeError("Unsupported type for comparison with Percentage")
        
    def __lt__(self, other):
        if isinstance(other, Percentage):
            return self.value < other.value
        raise TypeError("Unsupported type for comparison with Percentage")

    def __le__(self, other):
        if isinstance(other, Percentage):
            return self.value <= other.value
        raise TypeError("Unsupported type for comparison with Percentage")

    def __gt__(self, other):
        if isinstance(other, Percentage):
            return self.value > other.value
        else:
            raise TypeError("Unsupported type for comparison with Percentage")

    def __ge__(self, other):
        if isinstance(other, Percentage):
            return self.value >= other.value
        else: 
            raise TypeError("Unsupported type for comparison with Percentage")


class Number:

    def __init__(self, value):
        if isinstance(value, str):
            try:
                value = int(value.strip()) if len(value.strip().split(".")) == 1 else float(value.strip())
            except ValueError:
                raise ValueError("Invalid format for number.")
        if isinstance(value, String):
            try:
                value = int(value.strip()) if len(value.strip().split(".")) == 1 else float(value.strip())
            except ValueError:
                raise ValueError("Invalid format for number.")
        elif isinstance(value, Percentage):
            value = value.to_float()
        elif isinstance(value, Number):
            value = value.value
        elif not isinstance(value, (int, float)):
            raise TypeError("Number must be a number or a string convertible to a number.")
        self.value = value

    def __str__(self):
        return (f"{self.value:.10g}")

    def __repr__(self):
        return f"Number({self.value})"

    def __add__(self, other):
        if isinstance(other, Percentage):
            return Number(self.value + self.get_val(other)* self.value)
        elif isinstance(other, ImagePGM):
            result = numpy.clip(other.data + float(self.value), 0, 1)
            return ImagePGM(result, other.metadata.copy())
        return Number(self.value + self.get_val(other))

    def __sub__(self, other):
        if isinstance(other, Percentage):
            return Number(self.value - self.get_val(other)* self.value)
        elif isinstance(other, ImagePGM):
            result = numpy.clip(other.data - float(self.value), 0, 1)
            return ImagePGM(result, other.metadata.copy())
        return Number(self.value - self.get_val(other))

    def __mul__(self, other):
        if isinstance(other, ImagePGM):
            value = float(self.value)
            result = numpy.clip(other.data * value, 0, 1)
            return ImagePGM(result, self.metadata.copy())
        return Number(self.value * self.get_val(other))

    def __truediv__(self, other):
        denom = self.get_val(other)
        if denom == 0:
            raise ZeroDivisionError("Division by zero is not allowed.")
        return Number(self.value / denom)
    
    def get_val(self, other):
        if isinstance(other, Number):
            return other.value
        elif isinstance(other, Percentage):
            return other.to_float()
        elif isinstance(other, (int, float)):
            return other
        raise TypeError("Unsupported type for operation with Number")
    
    def __eq__(self, other):
        if isinstance(other, Number):
            return self.value == other.value
        elif isinstance(other, (int, float)):
            return self.value == other
        raise TypeError("Unsupported type for comparison with Number")
    
    def __ne__(self, other):
        if isinstance(other, Number):
            return not self.__eq__(other)
        elif isinstance(other, (int, float)):
            return not self.__eq__(other)
        raise TypeError("Unsupported type for comparison with Number")
        
    def __lt__(self, other):
        if isinstance(other, Number):
            return self.value < other.value
        elif isinstance(other, (int, float)):
            return self.value < other
        raise TypeError("Unsupported type for comparison with Number")

    def __le__(self, other):
        if isinstance(other, Number):
            return self.value <= other.value
        elif isinstance(other, (int, float)):
            return self.value <= other
        raise TypeError("Unsupported type for comparison with Number")

    def __gt__(self, other):
        if isinstance(other, Number):
            return self.value > other.value
        elif isinstance(other, (int, float)):
            return self.value > other
        else:
            raise TypeError("Unsupported type for comparison with Number")

    def __ge__(self, other):
        if isinstance(other, Number):
            return self.value >= other.value
        elif isinstance(other, (int, float)):
            return self.value >= other
        else: 
            raise TypeError("Unsupported type for comparison with Number")


class String:

    def __init__(self, value):
        if not isinstance(value, (str, int, float, Number, Percentage)):
            raise TypeError(f"String must be a string, int, float, Number, or Percentage.")
        self.value = str(value)

    def __str__(self):
        return self.value

    def __repr__(self):
        return f'String("{self.value}")'

    def __add__(self, other):
        if isinstance(other, String):
            return String(self.value + other.value)
        else:
            raise TypeError(f"Unsupported type for addition with String: {type(other)}")

    def __sub__(self, other):
       raise TypeError("Subtraction with String is not supported.")

    def __truediv__(self, other):
        raise TypeError("Division with String is not supported.")
    
    def __mul__(self, other):
        if isinstance(other, String):
            raise TypeError("Multiplication with another String is not supported.")
        elif isinstance(other, (int,Number)):
            n = self.count(other)
            return String(self.value * n)
        else: 
            raise TypeError(f"Unsupported type for multiplication with String: {type(other)}")

    def count(self, other):
        if isinstance(other, Number):
            return int(other.value)
        if isinstance(other, int):
            return other
        raise TypeError("Multiplition with non-numeric type is not supported.")
    
    def __eq__(self, other):
        if isinstance(other, String):
            return self.value == other.value
        raise TypeError("Unsupported type for comparison with String")
    
    def __ne__(self, other):
        if isinstance(other, String):
            return not self.__eq__(other)
        raise TypeError("Unsupported type for comparison with String")
        
    def __lt__(self, other):
        if isinstance(other, String):
            return self.value < other.value
        raise TypeError("Unsupported type for comparison with String")

    def __le__(self, other):
        if isinstance(other, String):
            return self.value <= other.value
        raise TypeError("Unsupported type for comparison with String")

    def __gt__(self, other):
        if isinstance(other, String):
            return self.value > other.value
        else:
            raise TypeError("Unsupported type for comparison with String")

    def __ge__(self, other):
        if isinstance(other, String):
            return self.value >= other.value
        else: 
            raise TypeError("Unsupported type for comparison with String")


class ListType:
    def __init__(self, type):
        self.type = type
        self.elements = []

    def __str__(self):
        return f"ListType({[str(e) for e in self.elements]})"

    def __len__(self):
        return len(self.elements)

    def __getitem__(self, index):
        return self.elements[index]

    def __setitem__(self, index, value):
        if not isinstance(value, self.type):
            raise TypeError(f"Elements need to be of type {self.type.__name__}")
        self.elements[index] = value

    def __delitem__(self, index):
        del self.elements[index]

    def add(self, element):
        if not isinstance(element, self.type):
            raise TypeError(f"Elemento deve ser do tipo {self.type.__name__}")
        self.elements.append(element)

    def remove(self, element):
        if element not in self.elements:
            raise ValueError("Elemento não encontrado na lista.")
        self.elements.remove(element)

    def clear(self):
        self.elements.clear()
