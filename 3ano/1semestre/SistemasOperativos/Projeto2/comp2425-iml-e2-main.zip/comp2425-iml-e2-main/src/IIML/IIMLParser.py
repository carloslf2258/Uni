# Generated from IIML.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,50,235,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,1,0,5,0,34,8,0,10,0,12,0,37,9,0,1,0,1,0,1,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,52,8,1,1,2,3,2,55,8,
        2,1,2,1,2,1,2,1,2,1,2,1,2,3,2,63,8,2,1,3,1,3,1,3,1,3,1,3,1,3,1,3,
        3,3,72,8,3,1,4,1,4,1,4,1,4,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,6,1,
        6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,7,1,7,1,7,1,7,1,7,1,7,1,
        7,1,7,1,7,1,7,1,7,1,7,1,7,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,8,1,
        8,1,8,1,8,1,8,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,1,
        9,1,10,1,10,1,10,1,10,1,10,1,10,4,10,142,8,10,11,10,12,10,143,1,
        11,1,11,3,11,148,8,11,1,12,1,12,1,12,1,13,1,13,1,13,1,13,1,13,1,
        14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,3,14,169,8,
        14,1,14,1,14,1,14,1,14,1,14,1,14,3,14,177,8,14,1,14,1,14,1,14,1,
        14,1,14,1,14,3,14,185,8,14,1,14,1,14,1,14,1,14,1,14,1,14,5,14,193,
        8,14,10,14,12,14,196,9,14,3,14,198,8,14,1,14,3,14,201,8,14,1,14,
        1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,
        1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,5,14,225,8,14,10,14,12,14,
        228,9,14,1,15,1,15,1,15,3,15,233,8,15,1,15,0,1,28,16,0,2,4,6,8,10,
        12,14,16,18,20,22,24,26,28,30,0,5,1,0,8,9,1,0,32,33,2,0,33,33,36,
        36,1,0,31,32,1,0,38,40,260,0,35,1,0,0,0,2,51,1,0,0,0,4,54,1,0,0,
        0,6,71,1,0,0,0,8,73,1,0,0,0,10,77,1,0,0,0,12,85,1,0,0,0,14,96,1,
        0,0,0,16,109,1,0,0,0,18,122,1,0,0,0,20,135,1,0,0,0,22,145,1,0,0,
        0,24,149,1,0,0,0,26,152,1,0,0,0,28,200,1,0,0,0,30,232,1,0,0,0,32,
        34,3,2,1,0,33,32,1,0,0,0,34,37,1,0,0,0,35,33,1,0,0,0,35,36,1,0,0,
        0,36,38,1,0,0,0,37,35,1,0,0,0,38,39,5,0,0,1,39,1,1,0,0,0,40,52,3,
        4,2,0,41,52,3,10,5,0,42,52,3,12,6,0,43,52,3,14,7,0,44,52,3,16,8,
        0,45,52,3,18,9,0,46,52,3,28,14,0,47,52,3,22,11,0,48,52,3,24,12,0,
        49,52,3,26,13,0,50,52,3,20,10,0,51,40,1,0,0,0,51,41,1,0,0,0,51,42,
        1,0,0,0,51,43,1,0,0,0,51,44,1,0,0,0,51,45,1,0,0,0,51,46,1,0,0,0,
        51,47,1,0,0,0,51,48,1,0,0,0,51,49,1,0,0,0,51,50,1,0,0,0,52,3,1,0,
        0,0,53,55,3,6,3,0,54,53,1,0,0,0,54,55,1,0,0,0,55,56,1,0,0,0,56,57,
        5,47,0,0,57,62,5,1,0,0,58,63,3,10,5,0,59,63,3,28,14,0,60,63,3,8,
        4,0,61,63,3,22,11,0,62,58,1,0,0,0,62,59,1,0,0,0,62,60,1,0,0,0,62,
        61,1,0,0,0,63,5,1,0,0,0,64,72,5,2,0,0,65,72,5,3,0,0,66,72,5,4,0,
        0,67,72,5,5,0,0,68,69,5,6,0,0,69,72,3,6,3,0,70,72,5,7,0,0,71,64,
        1,0,0,0,71,65,1,0,0,0,71,66,1,0,0,0,71,67,1,0,0,0,71,68,1,0,0,0,
        71,70,1,0,0,0,72,7,1,0,0,0,73,74,7,0,0,0,74,75,5,10,0,0,75,76,5,
        47,0,0,76,9,1,0,0,0,77,78,5,2,0,0,78,79,5,11,0,0,79,80,3,28,14,0,
        80,81,5,12,0,0,81,82,3,28,14,0,82,83,5,13,0,0,83,84,3,28,14,0,84,
        11,1,0,0,0,85,86,5,14,0,0,86,87,5,15,0,0,87,88,5,16,0,0,88,89,3,
        28,14,0,89,90,5,17,0,0,90,91,3,28,14,0,91,92,3,28,14,0,92,93,5,18,
        0,0,93,94,5,19,0,0,94,95,3,28,14,0,95,13,1,0,0,0,96,97,5,14,0,0,
        97,98,5,20,0,0,98,99,5,21,0,0,99,100,3,28,14,0,100,101,5,22,0,0,
        101,102,3,28,14,0,102,103,5,17,0,0,103,104,3,28,14,0,104,105,3,28,
        14,0,105,106,5,18,0,0,106,107,5,19,0,0,107,108,3,28,14,0,108,15,
        1,0,0,0,109,110,5,14,0,0,110,111,5,23,0,0,111,112,5,21,0,0,112,113,
        3,28,14,0,113,114,5,22,0,0,114,115,3,28,14,0,115,116,5,17,0,0,116,
        117,3,28,14,0,117,118,3,28,14,0,118,119,5,18,0,0,119,120,5,19,0,
        0,120,121,3,28,14,0,121,17,1,0,0,0,122,123,5,14,0,0,123,124,5,24,
        0,0,124,125,5,21,0,0,125,126,3,28,14,0,126,127,5,22,0,0,127,128,
        3,28,14,0,128,129,5,17,0,0,129,130,3,28,14,0,130,131,3,28,14,0,131,
        132,5,18,0,0,132,133,5,19,0,0,133,134,3,28,14,0,134,19,1,0,0,0,135,
        136,5,25,0,0,136,137,3,6,3,0,137,138,5,47,0,0,138,139,5,26,0,0,139,
        141,3,28,14,0,140,142,3,2,1,0,141,140,1,0,0,0,142,143,1,0,0,0,143,
        141,1,0,0,0,143,144,1,0,0,0,144,21,1,0,0,0,145,147,5,27,0,0,146,
        148,5,46,0,0,147,146,1,0,0,0,147,148,1,0,0,0,148,23,1,0,0,0,149,
        150,5,28,0,0,150,151,5,47,0,0,151,25,1,0,0,0,152,153,5,47,0,0,153,
        154,5,29,0,0,154,155,5,30,0,0,155,156,5,46,0,0,156,27,1,0,0,0,157,
        158,6,14,-1,0,158,201,3,30,15,0,159,201,5,47,0,0,160,161,5,31,0,
        0,161,201,3,28,14,12,162,163,7,1,0,0,163,201,3,28,14,11,164,165,
        5,3,0,0,165,168,5,41,0,0,166,169,3,28,14,0,167,169,3,22,11,0,168,
        166,1,0,0,0,168,167,1,0,0,0,169,170,1,0,0,0,170,171,5,42,0,0,171,
        201,1,0,0,0,172,173,5,5,0,0,173,176,5,41,0,0,174,177,3,28,14,0,175,
        177,3,22,11,0,176,174,1,0,0,0,176,175,1,0,0,0,177,178,1,0,0,0,178,
        179,5,42,0,0,179,201,1,0,0,0,180,181,5,4,0,0,181,184,5,41,0,0,182,
        185,3,28,14,0,183,185,3,22,11,0,184,182,1,0,0,0,184,183,1,0,0,0,
        185,186,1,0,0,0,186,187,5,42,0,0,187,201,1,0,0,0,188,197,5,34,0,
        0,189,194,3,28,14,0,190,191,5,43,0,0,191,193,3,28,14,0,192,190,1,
        0,0,0,193,196,1,0,0,0,194,192,1,0,0,0,194,195,1,0,0,0,195,198,1,
        0,0,0,196,194,1,0,0,0,197,189,1,0,0,0,197,198,1,0,0,0,198,199,1,
        0,0,0,199,201,5,35,0,0,200,157,1,0,0,0,200,159,1,0,0,0,200,160,1,
        0,0,0,200,162,1,0,0,0,200,164,1,0,0,0,200,172,1,0,0,0,200,180,1,
        0,0,0,200,188,1,0,0,0,201,226,1,0,0,0,202,203,10,9,0,0,203,204,7,
        2,0,0,204,225,3,28,14,10,205,206,10,8,0,0,206,207,7,3,0,0,207,225,
        3,28,14,9,208,209,10,7,0,0,209,210,5,37,0,0,210,211,7,2,0,0,211,
        225,3,28,14,8,212,213,10,6,0,0,213,214,5,37,0,0,214,215,7,3,0,0,
        215,225,3,28,14,7,216,217,10,5,0,0,217,218,7,4,0,0,218,225,3,28,
        14,6,219,220,10,10,0,0,220,221,5,34,0,0,221,222,3,28,14,0,222,223,
        5,35,0,0,223,225,1,0,0,0,224,202,1,0,0,0,224,205,1,0,0,0,224,208,
        1,0,0,0,224,212,1,0,0,0,224,216,1,0,0,0,224,219,1,0,0,0,225,228,
        1,0,0,0,226,224,1,0,0,0,226,227,1,0,0,0,227,29,1,0,0,0,228,226,1,
        0,0,0,229,233,5,45,0,0,230,233,5,44,0,0,231,233,5,46,0,0,232,229,
        1,0,0,0,232,230,1,0,0,0,232,231,1,0,0,0,233,31,1,0,0,0,16,35,51,
        54,62,71,143,147,168,176,184,194,197,200,224,226,232
    ]

class IIMLParser ( Parser ):

    grammarFileName = "IIML.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'is'", "'image'", "'number'", "'string'", 
                     "'percentage'", "'list of '", "'list'", "'rows'", "'columns'", 
                     "'of'", "'size'", "'by'", "'background'", "'place'", 
                     "'circle'", "'radius'", "'at'", "'with'", "'intensity'", 
                     "'rect'", "'width'", "'height'", "'cross'", "'plus'", 
                     "'for'", "'within'", "'read'", "'draw'", "'store'", 
                     "'into'", "'-'", "'+'", "'/'", "'['", "']'", "'*'", 
                     "'.'", "'-*'", "'|*'", "'+*'", "'('", "')'", "','" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "PERCENTAGE", "NUMBER", "STRING", "ID", "LINE_COMMENT", 
                      "COMMENT", "WS" ]

    RULE_program = 0
    RULE_statement = 1
    RULE_assignment = 2
    RULE_type = 3
    RULE_rowColStm = 4
    RULE_imageCreate = 5
    RULE_shapeCircle = 6
    RULE_shapeRect = 7
    RULE_shapeCross = 8
    RULE_shapePlus = 9
    RULE_forStmt = 10
    RULE_readStmt = 11
    RULE_drawStmt = 12
    RULE_storeStmt = 13
    RULE_expression = 14
    RULE_literal = 15

    ruleNames =  [ "program", "statement", "assignment", "type", "rowColStm", 
                   "imageCreate", "shapeCircle", "shapeRect", "shapeCross", 
                   "shapePlus", "forStmt", "readStmt", "drawStmt", "storeStmt", 
                   "expression", "literal" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    T__25=26
    T__26=27
    T__27=28
    T__28=29
    T__29=30
    T__30=31
    T__31=32
    T__32=33
    T__33=34
    T__34=35
    T__35=36
    T__36=37
    T__37=38
    T__38=39
    T__39=40
    T__40=41
    T__41=42
    T__42=43
    PERCENTAGE=44
    NUMBER=45
    STRING=46
    ID=47
    LINE_COMMENT=48
    COMMENT=49
    WS=50

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(IIMLParser.EOF, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(IIMLParser.StatementContext)
            else:
                return self.getTypedRuleContext(IIMLParser.StatementContext,i)


        def getRuleIndex(self):
            return IIMLParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = IIMLParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 35
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 263915439145212) != 0):
                self.state = 32
                self.statement()
                self.state = 37
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 38
            self.match(IIMLParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def assignment(self):
            return self.getTypedRuleContext(IIMLParser.AssignmentContext,0)


        def imageCreate(self):
            return self.getTypedRuleContext(IIMLParser.ImageCreateContext,0)


        def shapeCircle(self):
            return self.getTypedRuleContext(IIMLParser.ShapeCircleContext,0)


        def shapeRect(self):
            return self.getTypedRuleContext(IIMLParser.ShapeRectContext,0)


        def shapeCross(self):
            return self.getTypedRuleContext(IIMLParser.ShapeCrossContext,0)


        def shapePlus(self):
            return self.getTypedRuleContext(IIMLParser.ShapePlusContext,0)


        def expression(self):
            return self.getTypedRuleContext(IIMLParser.ExpressionContext,0)


        def readStmt(self):
            return self.getTypedRuleContext(IIMLParser.ReadStmtContext,0)


        def drawStmt(self):
            return self.getTypedRuleContext(IIMLParser.DrawStmtContext,0)


        def storeStmt(self):
            return self.getTypedRuleContext(IIMLParser.StoreStmtContext,0)


        def forStmt(self):
            return self.getTypedRuleContext(IIMLParser.ForStmtContext,0)


        def getRuleIndex(self):
            return IIMLParser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatement" ):
                return visitor.visitStatement(self)
            else:
                return visitor.visitChildren(self)




    def statement(self):

        localctx = IIMLParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statement)
        try:
            self.state = 51
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 40
                self.assignment()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 41
                self.imageCreate()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 42
                self.shapeCircle()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 43
                self.shapeRect()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 44
                self.shapeCross()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 45
                self.shapePlus()
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 46
                self.expression(0)
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 47
                self.readStmt()
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 48
                self.drawStmt()
                pass

            elif la_ == 10:
                self.enterOuterAlt(localctx, 10)
                self.state = 49
                self.storeStmt()
                pass

            elif la_ == 11:
                self.enterOuterAlt(localctx, 11)
                self.state = 50
                self.forStmt()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignmentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(IIMLParser.ID, 0)

        def imageCreate(self):
            return self.getTypedRuleContext(IIMLParser.ImageCreateContext,0)


        def expression(self):
            return self.getTypedRuleContext(IIMLParser.ExpressionContext,0)


        def rowColStm(self):
            return self.getTypedRuleContext(IIMLParser.RowColStmContext,0)


        def readStmt(self):
            return self.getTypedRuleContext(IIMLParser.ReadStmtContext,0)


        def type_(self):
            return self.getTypedRuleContext(IIMLParser.TypeContext,0)


        def getRuleIndex(self):
            return IIMLParser.RULE_assignment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignment" ):
                listener.enterAssignment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignment" ):
                listener.exitAssignment(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignment" ):
                return visitor.visitAssignment(self)
            else:
                return visitor.visitChildren(self)




    def assignment(self):

        localctx = IIMLParser.AssignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_assignment)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 54
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 252) != 0):
                self.state = 53
                self.type_()


            self.state = 56
            self.match(IIMLParser.ID)
            self.state = 57
            self.match(IIMLParser.T__0)
            self.state = 62
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [2]:
                self.state = 58
                self.imageCreate()
                pass
            elif token in [3, 4, 5, 31, 32, 33, 34, 44, 45, 46, 47]:
                self.state = 59
                self.expression(0)
                pass
            elif token in [8, 9]:
                self.state = 60
                self.rowColStm()
                pass
            elif token in [27]:
                self.state = 61
                self.readStmt()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def type_(self):
            return self.getTypedRuleContext(IIMLParser.TypeContext,0)


        def getRuleIndex(self):
            return IIMLParser.RULE_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterType" ):
                listener.enterType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitType" ):
                listener.exitType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitType" ):
                return visitor.visitType(self)
            else:
                return visitor.visitChildren(self)




    def type_(self):

        localctx = IIMLParser.TypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_type)
        try:
            self.state = 71
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [2]:
                self.enterOuterAlt(localctx, 1)
                self.state = 64
                self.match(IIMLParser.T__1)
                pass
            elif token in [3]:
                self.enterOuterAlt(localctx, 2)
                self.state = 65
                self.match(IIMLParser.T__2)
                pass
            elif token in [4]:
                self.enterOuterAlt(localctx, 3)
                self.state = 66
                self.match(IIMLParser.T__3)
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 4)
                self.state = 67
                self.match(IIMLParser.T__4)
                pass
            elif token in [6]:
                self.enterOuterAlt(localctx, 5)
                self.state = 68
                self.match(IIMLParser.T__5)
                self.state = 69
                self.type_()
                pass
            elif token in [7]:
                self.enterOuterAlt(localctx, 6)
                self.state = 70
                self.match(IIMLParser.T__6)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RowColStmContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.op = None # Token

        def ID(self):
            return self.getToken(IIMLParser.ID, 0)

        def getRuleIndex(self):
            return IIMLParser.RULE_rowColStm

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRowColStm" ):
                listener.enterRowColStm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRowColStm" ):
                listener.exitRowColStm(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRowColStm" ):
                return visitor.visitRowColStm(self)
            else:
                return visitor.visitChildren(self)




    def rowColStm(self):

        localctx = IIMLParser.RowColStmContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_rowColStm)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 73
            localctx.op = self._input.LT(1)
            _la = self._input.LA(1)
            if not(_la==8 or _la==9):
                localctx.op = self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 74
            self.match(IIMLParser.T__9)
            self.state = 75
            self.match(IIMLParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ImageCreateContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(IIMLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(IIMLParser.ExpressionContext,i)


        def getRuleIndex(self):
            return IIMLParser.RULE_imageCreate

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImageCreate" ):
                listener.enterImageCreate(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImageCreate" ):
                listener.exitImageCreate(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitImageCreate" ):
                return visitor.visitImageCreate(self)
            else:
                return visitor.visitChildren(self)




    def imageCreate(self):

        localctx = IIMLParser.ImageCreateContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_imageCreate)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 77
            self.match(IIMLParser.T__1)
            self.state = 78
            self.match(IIMLParser.T__10)
            self.state = 79
            self.expression(0)
            self.state = 80
            self.match(IIMLParser.T__11)
            self.state = 81
            self.expression(0)
            self.state = 82
            self.match(IIMLParser.T__12)
            self.state = 83
            self.expression(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShapeCircleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(IIMLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(IIMLParser.ExpressionContext,i)


        def getRuleIndex(self):
            return IIMLParser.RULE_shapeCircle

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShapeCircle" ):
                listener.enterShapeCircle(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShapeCircle" ):
                listener.exitShapeCircle(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitShapeCircle" ):
                return visitor.visitShapeCircle(self)
            else:
                return visitor.visitChildren(self)




    def shapeCircle(self):

        localctx = IIMLParser.ShapeCircleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_shapeCircle)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 85
            self.match(IIMLParser.T__13)
            self.state = 86
            self.match(IIMLParser.T__14)
            self.state = 87
            self.match(IIMLParser.T__15)
            self.state = 88
            self.expression(0)
            self.state = 89
            self.match(IIMLParser.T__16)
            self.state = 90
            self.expression(0)
            self.state = 91
            self.expression(0)
            self.state = 92
            self.match(IIMLParser.T__17)
            self.state = 93
            self.match(IIMLParser.T__18)
            self.state = 94
            self.expression(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShapeRectContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(IIMLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(IIMLParser.ExpressionContext,i)


        def getRuleIndex(self):
            return IIMLParser.RULE_shapeRect

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShapeRect" ):
                listener.enterShapeRect(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShapeRect" ):
                listener.exitShapeRect(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitShapeRect" ):
                return visitor.visitShapeRect(self)
            else:
                return visitor.visitChildren(self)




    def shapeRect(self):

        localctx = IIMLParser.ShapeRectContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_shapeRect)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 96
            self.match(IIMLParser.T__13)
            self.state = 97
            self.match(IIMLParser.T__19)
            self.state = 98
            self.match(IIMLParser.T__20)
            self.state = 99
            self.expression(0)
            self.state = 100
            self.match(IIMLParser.T__21)
            self.state = 101
            self.expression(0)
            self.state = 102
            self.match(IIMLParser.T__16)
            self.state = 103
            self.expression(0)
            self.state = 104
            self.expression(0)
            self.state = 105
            self.match(IIMLParser.T__17)
            self.state = 106
            self.match(IIMLParser.T__18)
            self.state = 107
            self.expression(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShapeCrossContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(IIMLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(IIMLParser.ExpressionContext,i)


        def getRuleIndex(self):
            return IIMLParser.RULE_shapeCross

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShapeCross" ):
                listener.enterShapeCross(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShapeCross" ):
                listener.exitShapeCross(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitShapeCross" ):
                return visitor.visitShapeCross(self)
            else:
                return visitor.visitChildren(self)




    def shapeCross(self):

        localctx = IIMLParser.ShapeCrossContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_shapeCross)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 109
            self.match(IIMLParser.T__13)
            self.state = 110
            self.match(IIMLParser.T__22)
            self.state = 111
            self.match(IIMLParser.T__20)
            self.state = 112
            self.expression(0)
            self.state = 113
            self.match(IIMLParser.T__21)
            self.state = 114
            self.expression(0)
            self.state = 115
            self.match(IIMLParser.T__16)
            self.state = 116
            self.expression(0)
            self.state = 117
            self.expression(0)
            self.state = 118
            self.match(IIMLParser.T__17)
            self.state = 119
            self.match(IIMLParser.T__18)
            self.state = 120
            self.expression(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShapePlusContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(IIMLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(IIMLParser.ExpressionContext,i)


        def getRuleIndex(self):
            return IIMLParser.RULE_shapePlus

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShapePlus" ):
                listener.enterShapePlus(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShapePlus" ):
                listener.exitShapePlus(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitShapePlus" ):
                return visitor.visitShapePlus(self)
            else:
                return visitor.visitChildren(self)




    def shapePlus(self):

        localctx = IIMLParser.ShapePlusContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_shapePlus)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 122
            self.match(IIMLParser.T__13)
            self.state = 123
            self.match(IIMLParser.T__23)
            self.state = 124
            self.match(IIMLParser.T__20)
            self.state = 125
            self.expression(0)
            self.state = 126
            self.match(IIMLParser.T__21)
            self.state = 127
            self.expression(0)
            self.state = 128
            self.match(IIMLParser.T__16)
            self.state = 129
            self.expression(0)
            self.state = 130
            self.expression(0)
            self.state = 131
            self.match(IIMLParser.T__17)
            self.state = 132
            self.match(IIMLParser.T__18)
            self.state = 133
            self.expression(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ForStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def type_(self):
            return self.getTypedRuleContext(IIMLParser.TypeContext,0)


        def ID(self):
            return self.getToken(IIMLParser.ID, 0)

        def expression(self):
            return self.getTypedRuleContext(IIMLParser.ExpressionContext,0)


        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(IIMLParser.StatementContext)
            else:
                return self.getTypedRuleContext(IIMLParser.StatementContext,i)


        def getRuleIndex(self):
            return IIMLParser.RULE_forStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterForStmt" ):
                listener.enterForStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitForStmt" ):
                listener.exitForStmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitForStmt" ):
                return visitor.visitForStmt(self)
            else:
                return visitor.visitChildren(self)




    def forStmt(self):

        localctx = IIMLParser.ForStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_forStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 135
            self.match(IIMLParser.T__24)
            self.state = 136
            self.type_()
            self.state = 137
            self.match(IIMLParser.ID)
            self.state = 138
            self.match(IIMLParser.T__25)
            self.state = 139
            self.expression(0)
            self.state = 141 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 140
                    self.statement()

                else:
                    raise NoViableAltException(self)
                self.state = 143 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,5,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReadStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING(self):
            return self.getToken(IIMLParser.STRING, 0)

        def getRuleIndex(self):
            return IIMLParser.RULE_readStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReadStmt" ):
                listener.enterReadStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReadStmt" ):
                listener.exitReadStmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReadStmt" ):
                return visitor.visitReadStmt(self)
            else:
                return visitor.visitChildren(self)




    def readStmt(self):

        localctx = IIMLParser.ReadStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_readStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 145
            self.match(IIMLParser.T__26)
            self.state = 147
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.state = 146
                self.match(IIMLParser.STRING)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DrawStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(IIMLParser.ID, 0)

        def getRuleIndex(self):
            return IIMLParser.RULE_drawStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDrawStmt" ):
                listener.enterDrawStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDrawStmt" ):
                listener.exitDrawStmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDrawStmt" ):
                return visitor.visitDrawStmt(self)
            else:
                return visitor.visitChildren(self)




    def drawStmt(self):

        localctx = IIMLParser.DrawStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_drawStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 149
            self.match(IIMLParser.T__27)
            self.state = 150
            self.match(IIMLParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StoreStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(IIMLParser.ID, 0)

        def STRING(self):
            return self.getToken(IIMLParser.STRING, 0)

        def getRuleIndex(self):
            return IIMLParser.RULE_storeStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStoreStmt" ):
                listener.enterStoreStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStoreStmt" ):
                listener.exitStoreStmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStoreStmt" ):
                return visitor.visitStoreStmt(self)
            else:
                return visitor.visitChildren(self)




    def storeStmt(self):

        localctx = IIMLParser.StoreStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_storeStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 152
            self.match(IIMLParser.ID)
            self.state = 153
            self.match(IIMLParser.T__28)
            self.state = 154
            self.match(IIMLParser.T__29)
            self.state = 155
            self.match(IIMLParser.STRING)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return IIMLParser.RULE_expression

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class ScaleOpExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(IIMLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(IIMLParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterScaleOpExpr" ):
                listener.enterScaleOpExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitScaleOpExpr" ):
                listener.exitScaleOpExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitScaleOpExpr" ):
                return visitor.visitScaleOpExpr(self)
            else:
                return visitor.visitChildren(self)


    class PixelOpAddSubContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(IIMLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(IIMLParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPixelOpAddSub" ):
                listener.enterPixelOpAddSub(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPixelOpAddSub" ):
                listener.exitPixelOpAddSub(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPixelOpAddSub" ):
                return visitor.visitPixelOpAddSub(self)
            else:
                return visitor.visitChildren(self)


    class UnaryExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(IIMLParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnaryExpr" ):
                listener.enterUnaryExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnaryExpr" ):
                listener.exitUnaryExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryExpr" ):
                return visitor.visitUnaryExpr(self)
            else:
                return visitor.visitChildren(self)


    class PixelOpMulDivContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(IIMLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(IIMLParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPixelOpMulDiv" ):
                listener.enterPixelOpMulDiv(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPixelOpMulDiv" ):
                listener.exitPixelOpMulDiv(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPixelOpMulDiv" ):
                return visitor.visitPixelOpMulDiv(self)
            else:
                return visitor.visitChildren(self)


    class IndexExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(IIMLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(IIMLParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIndexExpr" ):
                listener.enterIndexExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIndexExpr" ):
                listener.exitIndexExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIndexExpr" ):
                return visitor.visitIndexExpr(self)
            else:
                return visitor.visitChildren(self)


    class StringCastExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(IIMLParser.ExpressionContext,0)

        def readStmt(self):
            return self.getTypedRuleContext(IIMLParser.ReadStmtContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStringCastExpr" ):
                listener.enterStringCastExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStringCastExpr" ):
                listener.exitStringCastExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStringCastExpr" ):
                return visitor.visitStringCastExpr(self)
            else:
                return visitor.visitChildren(self)


    class PercentageCastExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(IIMLParser.ExpressionContext,0)

        def readStmt(self):
            return self.getTypedRuleContext(IIMLParser.ReadStmtContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPercentageCastExpr" ):
                listener.enterPercentageCastExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPercentageCastExpr" ):
                listener.exitPercentageCastExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPercentageCastExpr" ):
                return visitor.visitPercentageCastExpr(self)
            else:
                return visitor.visitChildren(self)


    class LiteralExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def literal(self):
            return self.getTypedRuleContext(IIMLParser.LiteralContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteralExpr" ):
                listener.enterLiteralExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteralExpr" ):
                listener.exitLiteralExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLiteralExpr" ):
                return visitor.visitLiteralExpr(self)
            else:
                return visitor.visitChildren(self)


    class VarExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(IIMLParser.ID, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVarExpr" ):
                listener.enterVarExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVarExpr" ):
                listener.exitVarExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVarExpr" ):
                return visitor.visitVarExpr(self)
            else:
                return visitor.visitChildren(self)


    class NumberCastExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(IIMLParser.ExpressionContext,0)

        def readStmt(self):
            return self.getTypedRuleContext(IIMLParser.ReadStmtContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumberCastExpr" ):
                listener.enterNumberCastExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumberCastExpr" ):
                listener.exitNumberCastExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumberCastExpr" ):
                return visitor.visitNumberCastExpr(self)
            else:
                return visitor.visitChildren(self)


    class ArithOpMulDivContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(IIMLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(IIMLParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArithOpMulDiv" ):
                listener.enterArithOpMulDiv(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArithOpMulDiv" ):
                listener.exitArithOpMulDiv(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArithOpMulDiv" ):
                return visitor.visitArithOpMulDiv(self)
            else:
                return visitor.visitChildren(self)


    class ListExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(IIMLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(IIMLParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterListExpr" ):
                listener.enterListExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitListExpr" ):
                listener.exitListExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitListExpr" ):
                return visitor.visitListExpr(self)
            else:
                return visitor.visitChildren(self)


    class UnaryMinusExprContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(IIMLParser.ExpressionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnaryMinusExpr" ):
                listener.enterUnaryMinusExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnaryMinusExpr" ):
                listener.exitUnaryMinusExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryMinusExpr" ):
                return visitor.visitUnaryMinusExpr(self)
            else:
                return visitor.visitChildren(self)


    class ArithOpAddSubContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(IIMLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(IIMLParser.ExpressionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArithOpAddSub" ):
                listener.enterArithOpAddSub(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArithOpAddSub" ):
                listener.exitArithOpAddSub(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArithOpAddSub" ):
                return visitor.visitArithOpAddSub(self)
            else:
                return visitor.visitChildren(self)



    def expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = IIMLParser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 28
        self.enterRecursionRule(localctx, 28, self.RULE_expression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 200
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [44, 45, 46]:
                localctx = IIMLParser.LiteralExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 158
                self.literal()
                pass
            elif token in [47]:
                localctx = IIMLParser.VarExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 159
                self.match(IIMLParser.ID)
                pass
            elif token in [31]:
                localctx = IIMLParser.UnaryMinusExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 160
                self.match(IIMLParser.T__30)
                self.state = 161
                self.expression(12)
                pass
            elif token in [32, 33]:
                localctx = IIMLParser.UnaryExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 162
                localctx.op = self._input.LT(1)
                _la = self._input.LA(1)
                if not(_la==32 or _la==33):
                    localctx.op = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 163
                self.expression(11)
                pass
            elif token in [3]:
                localctx = IIMLParser.NumberCastExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 164
                self.match(IIMLParser.T__2)
                self.state = 165
                self.match(IIMLParser.T__40)
                self.state = 168
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [3, 4, 5, 31, 32, 33, 34, 44, 45, 46, 47]:
                    self.state = 166
                    self.expression(0)
                    pass
                elif token in [27]:
                    self.state = 167
                    self.readStmt()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 170
                self.match(IIMLParser.T__41)
                pass
            elif token in [5]:
                localctx = IIMLParser.PercentageCastExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 172
                self.match(IIMLParser.T__4)
                self.state = 173
                self.match(IIMLParser.T__40)
                self.state = 176
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [3, 4, 5, 31, 32, 33, 34, 44, 45, 46, 47]:
                    self.state = 174
                    self.expression(0)
                    pass
                elif token in [27]:
                    self.state = 175
                    self.readStmt()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 178
                self.match(IIMLParser.T__41)
                pass
            elif token in [4]:
                localctx = IIMLParser.StringCastExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 180
                self.match(IIMLParser.T__3)
                self.state = 181
                self.match(IIMLParser.T__40)
                self.state = 184
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [3, 4, 5, 31, 32, 33, 34, 44, 45, 46, 47]:
                    self.state = 182
                    self.expression(0)
                    pass
                elif token in [27]:
                    self.state = 183
                    self.readStmt()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 186
                self.match(IIMLParser.T__41)
                pass
            elif token in [34]:
                localctx = IIMLParser.ListExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 188
                self.match(IIMLParser.T__33)
                self.state = 197
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 263915002921016) != 0):
                    self.state = 189
                    self.expression(0)
                    self.state = 194
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==43:
                        self.state = 190
                        self.match(IIMLParser.T__42)
                        self.state = 191
                        self.expression(0)
                        self.state = 196
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)



                self.state = 199
                self.match(IIMLParser.T__34)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 226
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,14,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 224
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
                    if la_ == 1:
                        localctx = IIMLParser.ArithOpMulDivContext(self, IIMLParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 202
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 203
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==33 or _la==36):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 204
                        self.expression(10)
                        pass

                    elif la_ == 2:
                        localctx = IIMLParser.ArithOpAddSubContext(self, IIMLParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 205
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 206
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==31 or _la==32):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 207
                        self.expression(9)
                        pass

                    elif la_ == 3:
                        localctx = IIMLParser.PixelOpMulDivContext(self, IIMLParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 208
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 209
                        self.match(IIMLParser.T__36)
                        self.state = 210
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==33 or _la==36):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 211
                        self.expression(8)
                        pass

                    elif la_ == 4:
                        localctx = IIMLParser.PixelOpAddSubContext(self, IIMLParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 212
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 213
                        self.match(IIMLParser.T__36)
                        self.state = 214
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==31 or _la==32):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 215
                        self.expression(7)
                        pass

                    elif la_ == 5:
                        localctx = IIMLParser.ScaleOpExprContext(self, IIMLParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 216
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 217
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1924145348608) != 0)):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 218
                        self.expression(6)
                        pass

                    elif la_ == 6:
                        localctx = IIMLParser.IndexExprContext(self, IIMLParser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 219
                        if not self.precpred(self._ctx, 10):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 10)")
                        self.state = 220
                        self.match(IIMLParser.T__33)
                        self.state = 221
                        self.expression(0)
                        self.state = 222
                        self.match(IIMLParser.T__34)
                        pass

             
                self.state = 228
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,14,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class LiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return IIMLParser.RULE_literal

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class StringLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(IIMLParser.STRING, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStringLiteral" ):
                listener.enterStringLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStringLiteral" ):
                listener.exitStringLiteral(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStringLiteral" ):
                return visitor.visitStringLiteral(self)
            else:
                return visitor.visitChildren(self)


    class PercentageLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def PERCENTAGE(self):
            return self.getToken(IIMLParser.PERCENTAGE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPercentageLiteral" ):
                listener.enterPercentageLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPercentageLiteral" ):
                listener.exitPercentageLiteral(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPercentageLiteral" ):
                return visitor.visitPercentageLiteral(self)
            else:
                return visitor.visitChildren(self)


    class NumberLiteralContext(LiteralContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a IIMLParser.LiteralContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUMBER(self):
            return self.getToken(IIMLParser.NUMBER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumberLiteral" ):
                listener.enterNumberLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumberLiteral" ):
                listener.exitNumberLiteral(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumberLiteral" ):
                return visitor.visitNumberLiteral(self)
            else:
                return visitor.visitChildren(self)



    def literal(self):

        localctx = IIMLParser.LiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_literal)
        try:
            self.state = 232
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [45]:
                localctx = IIMLParser.NumberLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 229
                self.match(IIMLParser.NUMBER)
                pass
            elif token in [44]:
                localctx = IIMLParser.PercentageLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 230
                self.match(IIMLParser.PERCENTAGE)
                pass
            elif token in [46]:
                localctx = IIMLParser.StringLiteralContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 231
                self.match(IIMLParser.STRING)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[14] = self.expression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expression_sempred(self, localctx:ExpressionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 8)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 10)
         




