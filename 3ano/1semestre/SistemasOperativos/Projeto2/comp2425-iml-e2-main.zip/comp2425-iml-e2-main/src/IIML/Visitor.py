import sys
import os

if (sys.path[0].split("/")[0] != "src"):
    sys.path.insert(0, os.path.abspath(os.path.join("..", "")))

from antlr4 import *
from IIML.IIMLParser import IIMLParser
from IIML.IIMLVisitor import IIMLVisitor
from IIML.Types import Number, Percentage, String, ImagePGM
import numpy

class Visitor(IIMLVisitor):

    def __init__(self):
        self.variables = {} # Dictionary to store variables
        self.image: ImagePGM = None
        self.reserved_keywords = ( "False", "None", "True", "and", "as", "assert", "async", "await","break", "class", "continue", "def", "del", "elif", "else","except","finally", "for", "from","global", "if", "import", "in", "is","lambda", "nonlocal", "not", "or", "pass", "raise", "return" ,"try", "while", "with", "yield" )

    def visitProgram(self, ctx:IIMLParser.ProgramContext):
        self.visitChildren(ctx)
        return self.image

    def visitStatement(self, ctx:IIMLParser.StatementContext):
        return self.visitChildren(ctx)

    def visitAssignment(self, ctx:IIMLParser.AssignmentContext):
        varname = ctx.ID().getText()

        if (varname in self.reserved_keywords):
            varname = "_" + varname

        if (ctx.imageCreate() != None): value = self.visit(ctx.imageCreate())
        elif (ctx.expression() != None): value = self.visit(ctx.expression())
        elif (ctx.rowColStm() != None): value = self.visit(ctx.rowColStm())
        elif (ctx.readStmt() != None): value = self.visit(ctx.readStmt())

        if ctx.type_():
            type_name = self.visit(ctx.type_())
            if type_name == 'number' and isinstance(value, (int, float, Number)):
                value = Number(value)
            elif type_name == 'percentage' and isinstance(value, Percentage):
                value = Percentage(value)
            elif type_name == 'string' and isinstance(value, (str, String)):
                value = String(value)
            elif type_name == 'image' and  isinstance(value, ImagePGM):
                value = value
            elif type_name.startswith('list') and isinstance(value, list):
                    value = value
            else:
                raise ValueError("Declared type does not match input type!")
        elif ctx.type_() is None and self.variables.get(varname) is None:
            raise ValueError(f"Variable {varname} not defined")

        self.variables[varname] = value
        return value

    def visitType(self, ctx:IIMLParser.TypeContext):
        return ctx.getText()
    
    def visitIndexExpr(self, ctx:IIMLParser.IndexExprContext):
        collection = self.visit(ctx.expression(0))
        index = self.visit(ctx.expression(1)) 
        if isinstance(index, Number):
            index = index.value
        elif not isinstance(index, (int,Number)):
            raise TypeError("Index must be an integer or Number type")
        try:
            return collection[index]
        except (IndexError, TypeError):
            raise ValueError(f"Invalid index {index} for collection {collection}")

    def visitRowColStm(self, ctx:IIMLParser.RowColStmContext):
        varname = ctx.ID().getText()
        op = ctx.op.text if ctx.op else None
        if varname not in self.variables or not isinstance(self.variables[varname], ImagePGM):
            raise ValueError(f"{varname} is not an image")
        image = self.variables[varname]
        if op == 'rows':
            return image.data.shape[0]
        elif op == 'columns':
            return image.data.shape[1]
        return None

    def visitImageCreate(self, ctx:IIMLParser.ImageCreateContext):
        width = self.visit(ctx.expression(0))
        height = self.visit(ctx.expression(1))
        background = self.visit(ctx.expression(2))

        if not isinstance(width, (int,float,Number)) or not isinstance(height, (int, float,Number)):
            raise ValueError("Image dimensions must be numbers")
        if not isinstance(background, (int,float,Number)):
            raise ValueError("Background must be a number")
        if isinstance(width, Number):
            width = width.value
        if isinstance(height, Number):
            height = height.value
        width, height = int(width), int(height)
        if width <= 0 or height <= 0:
            raise ValueError("Image dimensions must be positive integers")
        if isinstance(background, Number):
            background = background.value
        
        background = background.to_float() if isinstance(background, Percentage) else float(background)
        background = numpy.clip(background, 0, 1)
        
        data = numpy.full((height, width), background, dtype=float)
        metadata = {'width': width, 'height': height, 'maxval': 255, 'format': 'P5'}
        image = ImagePGM(data, metadata)
        self.image = image

        return image

    def visitShapeCircle(self, ctx:IIMLParser.ShapeCircleContext):
        if (self.image is None):
            raise ValueError("No image object in sight mi lord!")
        
        image = self.image
        radius = self.visit(ctx.expression(0))
        x = self.visit(ctx.expression(1))
        y = self.visit(ctx.expression(2))
        intensity = self.visit(ctx.expression(3))
        
        if not isinstance(radius, (int, float, Number)):
            raise ValueError("Size must be a number")
        if not isinstance(x, (int, float, Number)) or not isinstance(y, (int, float, Number)):
            raise ValueError("Coordinates must be numbers")
        if not isinstance(intensity, (int, float, Number)):
            raise ValueError("Intensity must be a number")

        if isinstance(radius, Number):
            radius = radius.value
        if isinstance(x, Number):
            x = x.value
        if isinstance(y, Number):
            y = y.value
        if isinstance(intensity, Number):
            intensity = intensity.value
        intensity = intensity.to_float() if isinstance(intensity, Percentage) else float(intensity)
        intensity = numpy.clip(intensity, 0, 1)
        radius, x, y = int(radius), int(x), int(y)
        image.draw_circle(x, y, radius, intensity)
        return image

    def visitShapeRect(self, ctx:IIMLParser.ShapeRectContext):
         if (self.image is None):
             raise ValueError("No image object in sight mi lord!")
         
         image = self.image
         width = self.visit(ctx.expression(0))
         height = self.visit(ctx.expression(1))
         x = self.visit(ctx.expression(2))
         y = self.visit(ctx.expression(3))
         intensity = self.visit(ctx.expression(4))
         
         if not isinstance(width, (int, float, Number)) or not isinstance(height, (int, float, Number)):
            raise ValueError("width  and height must be numbers")
         if not isinstance(x, (int, float, Number)) or not isinstance(y, (int, float, Number)):
            raise ValueError("Coordinates must be numbers")
         if not isinstance(intensity, (int, float, Number)):
            raise ValueError("Intensity must be a number")

         if isinstance(width, Number):
            width = width.value
         if isinstance(height, Number):
            height = height.value
         if isinstance(x, Number):
            x = x.value
         if isinstance(y, Number):
            y = y.value
         if isinstance(intensity, Number):
            intensity = intensity.value

         intensity = intensity.to_float() if isinstance(intensity, Percentage) else float(intensity)
         intensity = numpy.clip(intensity, 0, 1)
         width, height, x, y = int(width), int(height), int(x), int(y)
         image.draw_rect(x, y, width, height, intensity)

         return image

    def visitShapeCross(self, ctx:IIMLParser.ShapeCrossContext):
         if (self.image is None):
             raise ValueError("No image object in sight mi lord!")
         
         image = self.image
         width = self.visit(ctx.expression(0))
         height = self.visit(ctx.expression(1))
         x = self.visit(ctx.expression(2))
         y = self.visit(ctx.expression(3))
         intensity = self.visit(ctx.expression(4))

         
         if not isinstance(width, (int, float, Number)) or not isinstance(height, (int, float, Number)):
            raise ValueError("width  and height must be numbers")
         if not isinstance(x, (int, float, Number)) or not isinstance(y, (int, float, Number)):
            raise ValueError("Coordinates must be numbers")
         if not isinstance(intensity, (int, float, Number)):
            raise ValueError("Intensity must be a number")

         
         if isinstance(width, Number):
            width = width.value
         if isinstance(height, Number):
            height = height.value
         if isinstance(x, Number):
            x = x.value
         if isinstance(y, Number):
            y = y.value
         if isinstance(intensity, Number):
            intensity = intensity.value

         intensity = intensity.to_float() if isinstance(intensity, Percentage) else float(intensity)
         intensity = numpy.clip(intensity, 0, 1)
         width, height, x, y = int(width), int(height), int(x), int(y)

         image.draw_cross(x, y, width, height, intensity)

         return image

    def visitShapePlus(self, ctx:IIMLParser.ShapePlusContext):
         if (self.image is None):
             raise ValueError("No image object in sight mi lord!")
         
         image = self.image
         width = self.visit(ctx.expression(0))
         height = self.visit(ctx.expression(1))
         x = self.visit(ctx.expression(2))
         y = self.visit(ctx.expression(3))
         intensity = self.visit(ctx.expression(4))

         if not isinstance(width, (int, float, Number)) or not isinstance(height, (int, float, Number)):
            raise ValueError("Width and Height must be numbers")
         if not isinstance(x, (int, float, Number)) or not isinstance(y, (int, float, Number)):
            raise ValueError("Coordinates must be numbers")
         if not isinstance(intensity, (int, float, Number)):
            raise ValueError("Intensity must be a number")

         if isinstance(width, Number):
            width = width.value
         if isinstance(height, Number):
            height = height.value
         if isinstance(x, Number):
            x = x.value
         if isinstance(y, Number):
            y = y.value
         if isinstance(intensity, Number):
            intensity = intensity.value

         intensity = intensity.to_float() if isinstance(intensity, Percentage) else float(intensity)
         intensity = numpy.clip(intensity, 0, 1)
         size, x, y = int(size), int(x), int(y)
         
         image.draw_plus(x, y, width, height, intensity)
         
         return image

    def visitForStmt(self, ctx:IIMLParser.ForStmtContext):
        _type = ctx.type_().getText() if ctx.type_() else None
        _varname = ctx.ID().getText()
        _expression = self.visit(ctx.expression())
        for value in _expression:
            self.variables[_varname] = value
            for statement in ctx.statement():
                self.visit(statement)
        return None


    def visitReadStmt(self, ctx:IIMLParser.ReadStmtContext):
        prompt = ctx.STRING().getText()[1:-1] if ctx.STRING() else ""
        with open("/dev/tty", 'r') as file:
            sys.stdin = file
            user_input = input(prompt)
        try:
            if user_input.endswith('%'):
                return Percentage(user_input)
            return Number(user_input)
        except ValueError:
            return user_input

    def visitDrawStmt(self, ctx:IIMLParser.DrawStmtContext):
        varname = ctx.ID().getText()
        if varname not in self.variables or not isinstance(self.variables[varname], ImagePGM):
            raise ValueError(f"{varname} is not an image")
        image = self.variables[varname]
        image.draw()

    def visitStoreStmt(self, ctx:IIMLParser.StoreStmtContext):
        varname = ctx.ID().getText()
        filename = ctx.STRING().getText()
        if varname not in self.variables or not isinstance(self.variables[varname], ImagePGM):
            raise ValueError(f"{varname} is not an image")
        image = self.variables[varname]
        image.store(filename)
        return None

    def visitScaleOpExpr(self, ctx:IIMLParser.ScaleOpExprContext):
        left = self.visit(ctx.expression(0))
        right = self.visit(ctx.expression(1))
        op = ctx.op.text
         
        if isinstance(left, ImagePGM):
            if op == '-*':
               return  left.scale_horizontal(right)
            elif op == '|*':
               return left.scale_vertical(right)
            elif op == '+*':
               return left.scale_both(right)
        elif isinstance(right, ImagePGM):
            if op == '-*':
               return  right.scale_horizontal(left)
            elif op == '|*':
               return right.scale_vertical(left)
            elif op == '+*':
               return right.scale_both(left)
        else:
            raise ValueError("Scale operation requires an image as operand") 
        return None

    def visitPixelOpAddSub(self, ctx:IIMLParser.PixelOpAddSubContext):
        left = self.visit(ctx.expression(0))
        right = self.visit(ctx.expression(1))
        op = ctx.op.text
        if isinstance(left, ImagePGM) or isinstance(right, ImagePGM):
               if op == '+':
                  return left + right
               elif op == '-':
                  return left - right
        else:
               raise ValueError("Pixel operation requires an image as operand")
        return None

    def visitUnaryExpr(self, ctx:IIMLParser.UnaryExprContext):
        value = self.visit(ctx.expression())
        if not isinstance(value, ImagePGM):
               raise ValueError("Unary operation requires an image")
        if ctx.op.text == '/':
               return value.flip_horizontal()
        elif ctx.op.text == '+':
               return value.flip_both()
        else:
             raise ValueError(f"Unknown unary operation: {ctx.op.text}")

    def visitPixelOpMulDiv(self, ctx:IIMLParser.PixelOpMulDivContext):
        left = self.visit(ctx.expression(0))
        right = self.visit(ctx.expression(1))
        op = ctx.op.text
         
        if isinstance(left, ImagePGM):
               if op == '*':
                  return left * right
               elif op == '/':
                  if numpy.any(right == 0):
                     raise ZeroDivisionError("Pixel-wise division by zero")
                  return left / right
        elif isinstance(right, ImagePGM):
               if op == '*':
                  return  right * left
               elif op == '/':
                  return right / left
        else:
               raise ValueError("Pixel operation requires an image as operand")
        return None

    def visitStringCastExpr(self, ctx:IIMLParser.StringCastExprContext):
        value = self.visit(ctx.expression()) if ctx.expression() else self.visit(ctx.readStmt())
        return String(value)

    def visitPercentageCastExpr(self, ctx:IIMLParser.PercentageCastExprContext):
        value = self.visit(ctx.expression()) if ctx.expression() else self.visit(ctx.readStmt())
        return Percentage(value)

    def visitLiteralExpr(self, ctx:IIMLParser.LiteralExprContext):
        return self.visit(ctx.literal())

    def visitVarExpr(self, ctx:IIMLParser.VarExprContext):
        var_name = ctx.ID().getText()
        if var_name not in self.variables:
               raise ValueError(f"Variable {var_name} not defined")
        return self.variables[var_name]

    def visitNumberCastExpr(self, ctx:IIMLParser.NumberCastExprContext):
        value = self.visit(ctx.expression()) if ctx.expression() else self.visit(ctx.readStmt())
        return Number(value)

    def visitArithOpMulDiv(self, ctx:IIMLParser.ArithOpMulDivContext):
        left = self.visit(ctx.expression(0))
        right = self.visit(ctx.expression(1))
        op = ctx.op.text
        if not isinstance(left, (int, float,Percentage,Number)) and not isinstance(right, (int, float,Percentage,Number)):
               raise TypeError("Unsupported type for addition/subtraction operation.")
        try:
            if op == '*':
               return left * right
            elif op == '/':
               if right == 0:
                  raise ZeroDivisionError("Division by zero")
               return left / right
            return None
        except TypeError as e:
                  raise TypeError(f"Error in multiplication/division operation: {e}")

    def visitListExpr(self, ctx:IIMLParser.ListExprContext):
        elements = []
        for expr in ctx.expression():
            value = self.visit(expr)
            if isinstance(value, (int,str, float, Percentage, Number, String, ImagePGM,list)):
                if len(elements) == 0:
                    typeElements = type(value)
                else:
                    if type(value) != typeElements:
                        raise TypeError(f"All elements in the list must be of the same type, found {type(value)}")
                elements.append(value)
            else:
                raise TypeError(f"Unsupported type in list: {type(value)}")
        return elements

    def visitUnaryMinusExpr(self, ctx:IIMLParser.UnaryMinusExprContext):
         value = self.visit(ctx.expression())
         if isinstance(value, ImagePGM):
               return value.flip_vertical()
         elif isinstance(value, (int, float, Percentage)):
               return -value if not isinstance(value, Percentage) else Percentage(0.1 - value.to_float())
         elif isinstance(value, Number):
               return Number(-value.value)
         raise TypeError("Unsupported type for unary minus operation.")

    def visitArithOpAddSub(self, ctx:IIMLParser.ArithOpAddSubContext):
        left = self.visit(ctx.expression(0))
        right = self.visit(ctx.expression(1))
        op = ctx.op.text
        if not isinstance(left, (int, float,str,Percentage,Number,String)) and not isinstance(right, (int, float,str, Percentage,Number,String)):
               raise TypeError("Unsupported type for addition/subtraction operation.")
        try:
            if op == '+':
                  return left + right
            elif op == '-':
                  if not isinstance(left,(int, float, Percentage,Number)) and not isinstance(right,(int, float, Percentage,Number)):
                     raise TypeError("Unsupported type for addition/subtraction operation.")
                  return left - right
            return None
        except TypeError as e:
                  raise TypeError(f"Error in addition/subtraction operation: {e}")

    def visitNumberLiteral(self, ctx:IIMLParser.NumberLiteralContext):
        return Number(ctx.getText())

    def visitPercentageLiteral(self, ctx:IIMLParser.PercentageLiteralContext):
        value = "\"" + ctx.getText().strip() + "\""
        return Percentage(value)

    def visitStringLiteral(self, ctx:IIMLParser.StringLiteralContext):
        return ctx.getText().strip()
