#!/bin/bash
# run.sh

# Cores
GREEN="\033[0;32m"
RED="\033[0;31m"
NC="\033[0m"

if [ "$#" -lt 1 ]; then
  echo -e "${RED}Uso: ./run.sh <ficheiro.py> [ficheiro2.py ...]${NC}"
  exit 1
fi

for script in "$@"
do
  if [ ! -f "$script" ]; then
    echo -e "${RED}[✖] Ficheiro não encontrado: $script${NC}"
    continue
  fi

  abs_script_path=$(realpath "$script")
  script_name=$(basename "$script")

  # Diretórios
  PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
  IMG_DIR="${PROJECT_ROOT}/examples/images"
  GEN_DIR="${IMG_DIR}/generated"
  OUTDIR="../../examples/images/generated"

  mkdir -p "$GEN_DIR"

  # Guardar estado inicial
  BEFORE_IMAGES=$(find "$IMG_DIR" -maxdepth 1 -type f -name "*.pgm" -printf "%f %T@\n" | sort)

  echo -e "▶️  A executar ${script_name}...\n"
  (
    cd "$PROJECT_ROOT/examples" || exit 1
    PYTHONPATH="$PROJECT_ROOT/src" PYTHONWARNINGS="ignore" python3 "$abs_script_path"
  )

  # Guardar estado final
  AFTER_IMAGES=$(find "$IMG_DIR" -maxdepth 1 -type f -name "*.pgm" -printf "%f %T@\n" | sort)

  MODIFIED_IMAGES=""
  while read -r fname mtime_after; do
    mtime_before=$(echo "$BEFORE_IMAGES" | awk -v f="$fname" '$1==f{print $2}')
    if [ -z "$mtime_before" ]; then
      MODIFIED_IMAGES="${MODIFIED_IMAGES}${fname} (nova)\n"
      mv "$IMG_DIR/$fname" "$GEN_DIR/$fname"
    elif (( $(echo "$mtime_after > $mtime_before" | bc -l) )); then
      MODIFIED_IMAGES="${MODIFIED_IMAGES}${fname} (modificada)\n"
      mv "$IMG_DIR/$fname" "$GEN_DIR/$fname"
    fi
  done <<< "$(echo "$AFTER_IMAGES" | awk '{print $1, $2}')"

  if [ -n "$MODIFIED_IMAGES" ]; then
    echo -e "\n🖼️  Imagens geradas/modificadas (agora em images/generated):"
    echo -e "$MODIFIED_IMAGES"
  else
    echo -e "\n📭 Nenhuma imagem nova ou modificada."
  fi

  echo -e "${GREEN}[✔] Execução concluída para $script_name${NC}"
  echo -e "${GREEN}[✔] Caminho Output: $OUTDIR"
done
