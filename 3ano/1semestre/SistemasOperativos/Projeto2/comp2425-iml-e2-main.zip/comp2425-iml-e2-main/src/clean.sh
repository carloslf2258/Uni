#!/bin/bash
# clean.sh

#Resumo:
#Entra em IML, faz clean de Java
#Entra em IIML, faz clean de python
cd IML
echo -e "🧹 Cleaning IML build files..."
if antlr4-clean; then
  echo "[✔] IML Java files cleaned"
else
  echo "[⚠] IML Java cleanup reported error"
fi

cd ../IIML

echo -e "🧹 Cleaning IIML build files..."
if antlr4-clean -python; then
  echo "[✔] IIML Python files cleaned"\
else
  echo [⚠] "antlr4-clean -python IIML Python cleanup reported error"
fi

cd ..

echo -e "✅ Cleaning finished successfully"
