#!/usr/bin/env python3
#USO: python grammar_test.py IMLGrammar2 ../examples/des-03.iml --tokens --tree
import sys
import argparse
import importlib
from antlr4 import FileStream, CommonTokenStream
from antlr4.error.ErrorListener import ConsoleErrorListener

def main():
    p = argparse.ArgumentParser(
        description="Testa uma gramática ANTLR4 gerada em Python",
        usage="%(prog)s <GrammarName> [-tokens] [-tree] [-trace] [-diagnostic] [file]"
    )
    p.add_argument('grammar',
                   help='nome da gramática (ex: IMLGrammar2)')
    p.add_argument('file', nargs='?', default='-',
                   help='ficheiro de entrada (.iml), ou "-" para stdin')
    p.add_argument('-t','--tokens',    action='store_true', help='mostra lista de tokens')
    p.add_argument('-p','--tree',      action='store_true', help='mostra parse tree')
    p.add_argument('-d','--diagnostic',action='store_true', help='ativa ConsoleErrorListener')
    p.add_argument('--trace',     action='store_true', help='ativa trace de regras (se suportado)')
    args = p.parse_args()

    # importa dinamicamente os módulos gerados
    try:
        lexer_mod  = importlib.import_module(f"{args.grammar}Lexer")
        parser_mod = importlib.import_module(f"{args.grammar}Parser")
    except ImportError as e:
        print(f"Erro ao importar gramática {args.grammar}: {e}", file=sys.stderr)
        sys.exit(1)

    LexerClass  = getattr(lexer_mod,  args.grammar + "Lexer")
    ParserClass = getattr(parser_mod, args.grammar + "Parser")

    # carrega input
    if args.file == '-':
        input_stream = FileStream(sys.stdin)
    else:
        input_stream = FileStream(args.file)

    # lex + parse
    lexer = LexerClass(input_stream)
    stream = CommonTokenStream(lexer)
    parser = ParserClass(stream)

    # diagnóstico de erros
    if args.diagnostic:
        parser.addErrorListener(ConsoleErrorListener.INSTANCE)

    # trace de regras
    if args.trace and hasattr(parser, 'setTrace'):
        parser.setTrace(True)

    # tokens
    if args.tokens:
        stream.fill()
        for tok in stream.tokens:
            print(tok)

    # invoca a primeira regra do parser (ruleNames[0])
    start_rule = parser.ruleNames[0]
    tree = getattr(parser, start_rule)()

    # arvore
    if args.tree:
        print(tree.toStringTree(recog=parser))

if __name__ == '__main__':
    main()
