# iml_types.py

class Type:
    """Superclasse para todos os tipos da IML."""
    pass

class ImageType(Type):
    def __repr__(self):
        return "Image"

class NumberType(Type):
    def __repr__(self):
        return "Number"

class StringType(Type):
    def __repr__(self):
        return "String"

class PercentageType(Type):
    def __repr__(self):
        return "Percentage"

class ListType(Type):
    def __init__(self, elem_type: Type):
        self.elem_type = elem_type

    def __repr__(self):
        return f"List[{self.elem_type!r}]"
