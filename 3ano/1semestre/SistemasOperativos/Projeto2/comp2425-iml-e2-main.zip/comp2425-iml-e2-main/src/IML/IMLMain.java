import java.io.IOException;
import org.antlr.v4.runtime.*;
import java.io.FileWriter;
import org.antlr.v4.runtime.tree.*;
import org.stringtemplate.v4.*;

import error.*;
public class IMLMain {
   public static void main(String[] args) {
      try {
         CharStream input;
         String outputFile = args.length > 0 ? args[1] : null;
         if (args.length > 1) {
                input = CharStreams.fromFileName(args[0]);
         } else {
                input = CharStreams.fromStream(System.in);
         }
         // create a lexer that feeds off of input CharStream:
         IMLLexer lexer = new IMLLexer(input);
         // create a buffer of tokens pulled from the lexer:
         CommonTokenStream tokens = new CommonTokenStream(lexer);
         // create a parser that feeds off the tokens buffer:
         IMLParser parser = new IMLParser(tokens);
         // replace error listener:
         //parser.removeErrorListeners(); // remove ConsoleErrorListener
         //parser.addErrorListener(new ErrorHandlingListener());
         // begin parsing at program rule:
         ParseTree tree = parser.program();
         if (parser.getNumberOfSyntaxErrors() == 0) {
            // print LISP-style tree:
            // System.out.println(tree.toStringTree(parser));
            SemanticAnalyser semanticAnalyser = new SemanticAnalyser();
            Compiler compiler = new Compiler();
            semanticAnalyser.visit(tree);
            System.out.println("Semantic analysis completed successfully.");
            if (!ErrorHandling.error()) {
              ST pythonCode = compiler.visit(tree);
              String code = pythonCode.render();
    
              if (outputFile != null) {
                try (FileWriter writer = new FileWriter(outputFile)) {
                  writer.write(code);
                  System.out.println("Python code saved to " + outputFile);
                }
              }
            }
          }
      }
      catch(IOException e) {
         e.printStackTrace();
         System.exit(1);
      }
      catch(RecognitionException e) {
         e.printStackTrace();
         System.exit(1);
      }
   }
}
