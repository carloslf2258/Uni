import org.stringtemplate.v4.*;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;
import java.util.stream.Collectors;




@SuppressWarnings("CheckReturnValue")
public class Compiler extends IMLBaseVisitor<ST> {

   private STGroup templates = new STGroupFile("python.stg");
   private HashMap<String, String> typeMap = new HashMap<>();
    {
        typeMap.put("image", "Image");
        typeMap.put("number", "Number");
        typeMap.put("string", "String");
        typeMap.put("percentage", "Percentage");
        typeMap.put("list of", "ListType");
    }
   private HashMap<String, String> IdMap = new HashMap<>();

   private String getType(String id) {
        if (typeMap.containsKey(id)) {
            return typeMap.get(id);
        }
        return "";
    }


   @Override public ST visitProgram(IMLParser.ProgramContext ctx) {
         List<String> stmts = ctx.statement().stream().map((IMLParser.StatementContext stmt) -> visit(stmt).render()).collect(Collectors.toList());
         ST res = templates.getInstanceOf("program");
         
         List<String> header = List.of(
               "import numpy as np",
               "from skimage import morphology",
               "from PIL import Image as PILImage",
               "import sys",
               "import os",
               "if (sys.path[0].split('/')[0] != 'src'):",
               "    sys.path.insert(0, os.path.abspath(os.path.join('..', '')))",
               "from IIML.Types import ImagePGM, Number, String, Percentage, ListType",
               "import IIML.IIMLMain as IIMLMain ",
               ""
         );
         
         List<String> allStmts = Stream.concat(header.stream(), stmts.stream()).collect(Collectors.toList());
         res.add("stmts", allStmts);
         return res;
   }

   @Override public ST visitStatement(IMLParser.StatementContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitAssignment(IMLParser.AssignmentContext ctx) {
         String id = ctx.ID().getText();
         String type = ctx.type() != null ? visit(ctx.type()).render() : "";
         String expr = visit(ctx.expression() != null ? ctx.expression() :
            ctx.loadImg() != null ? ctx.loadImg() : ctx.lingSEC()).render().trim();
      
         String templateName;
         String resolvedType = getType(type);
         if (type.contains("ListType")) {
            templateName = "assign_ListType";
         } else if (resolvedType.equals("Image")) {
            templateName = "assign_Image";
         } else if (resolvedType.equals("Number")) {
            templateName = "assign_Number";
         } else if (resolvedType.equals("String")) {
            templateName = "assign_String";
         } else if (resolvedType.equals("Percentage")) {
            templateName = "assign_Percentage";
         } else {
            templateName = "assign_default";
         }
         if(!IdMap.containsKey(id)) {
            if (type.contains("ListType")) {
                  IdMap.put(id, "ListType");
               } else {
                  IdMap.put(id, resolvedType);
               }
         }
         ST res = templates.getInstanceOf(templateName);
         res.add("id", id);
         res.add("expr", expr);
         return res;
   }

   @Override public ST visitIndexExpr(IMLParser.IndexExprContext ctx) {
          String base = visit(ctx.expression(0)).render().trim();
          String index = visit(ctx.expression(1)).render().trim();
          ST res = templates.getInstanceOf("indexExpr");
          res.add("base", base);
          res.add("index", index);
          return res;
          }

   @Override public ST visitType(IMLParser.TypeContext ctx) {
       ST res = templates.getInstanceOf("typeExpr");
        if (ctx.getText().equals("image") || ctx.getText().equals("number") || ctx.getText().equals("string") || ctx.getText().equals("percentage")) {
            res.add("value", ctx.getText());
        } else {
            String nestedType = visit(ctx.type()).render();
            res.add("value", "ListType(" + nestedType + ")");
        }
        return res;
   }

   @Override public ST visitLoadImg(IMLParser.LoadImgContext ctx) {
        String file;
        if (ctx.STRING() != null) {
            file = ctx.STRING().getText().trim();
        } else {
            file = visit(ctx.readStmt()).render().trim();
        }
        ST res = templates.getInstanceOf("loadImg");
        res.add("file", file);
        return res;
   }

   @Override public ST visitReadStmt(IMLParser.ReadStmtContext ctx) {
        String prompt = ctx.STRING() != null ? ctx.STRING().getText() : "\"\"";
        ST res = templates.getInstanceOf("readStmt");
        res.add("prompt", prompt);
        return res;
   }

   @Override public ST visitOutputStmt(IMLParser.OutputStmtContext ctx) {
        String expr = visit(ctx.expression()).render().trim();
        ST res = templates.getInstanceOf("outputStmt");
        res.add("expr", expr);
        return res;
   }

   @Override public ST visitLingSEC(IMLParser.LingSECContext ctx) {
        String file;
        if (ctx.STRING() != null) {
            file = ctx.STRING().getText().trim();
        } else {
            file = visit(ctx.readStmt()).render().trim();
        }
        ST res = templates.getInstanceOf("lingSEC");
        res.add("file", file);
        return res;
   }

   @Override public ST visitDrawStmt(IMLParser.DrawStmtContext ctx) {
        String id = ctx.ID().getText().trim();
        ST res = templates.getInstanceOf("drawStmt");
        res.add("id", id);
        return res;
   }

   @Override public ST visitStoreStmt(IMLParser.StoreStmtContext ctx) {
       String id = ctx.ID().getText().trim();
       String file = ctx.STRING().getText().trim();
       String type = IdMap.get(id);
       if (type == null) { type = ""; }
       String templateName = type.equals("ListType") ? "storeListTypeStmt" : "storeDefaultStmt";
       ST res = templates.getInstanceOf(templateName);
       res.add("id", id);
       res.add("file", file);
       return res;
   }

   @Override public ST visitIfStmt(IMLParser.IfStmtContext ctx) {
           String cond = visit(ctx.expression()).render().trim();

           List<IMLParser.StatementContext> thenBlock;
           List<IMLParser.StatementContext> elseBlock;
        
           if (ctx.elseBlock != null && !ctx.elseBlock.isEmpty()) {
                int thenCount = ctx.statement().size() - ctx.elseBlock.size();
                thenBlock = ctx.statement().subList(0, thenCount);
                elseBlock = ctx.elseBlock;
            } else {
                thenBlock = ctx.statement();
                elseBlock = List.of();
            }
        
            List<String> thenBlockStr = thenBlock.stream()
                .map(stmt -> visit(stmt).render())
                .collect(Collectors.toList());
        
            List<String> elseBlockStr = elseBlock.stream()
                .map(stmt -> visit(stmt).render())
                .collect(Collectors.toList());
        
            ST res = templates.getInstanceOf("ifStmt");
            res.add("cond", cond);
            res.add("thenBlock", thenBlockStr);
            res.add("elseBlock", elseBlockStr);
            return res;
   }

   @Override public ST visitForStmt(IMLParser.ForStmtContext ctx) {
        String id = ctx.ID().getText().trim();
        String range_expr = visit(ctx.expression()).render();
        List<String> stmts = ctx.statement().stream()
                .map(stmt -> visit(stmt).render())
                .collect(Collectors.toList());
        ST res = templates.getInstanceOf("forStmt");
        res.add("id", id);
        res.add("range_expr", range_expr);
        res.add("stmts", stmts);
        return res;
   }

   @Override public ST visitUntilStmt(IMLParser.UntilStmtContext ctx) {
        String cond = visit(ctx.expression()).render().trim();
        List<String> stmts = ctx.statement().stream()
                .map(stmt -> visit(stmt).render())
                .collect(Collectors.toList());
        ST res = templates.getInstanceOf("untilStmt");
        res.add("cond", cond);
        res.add("stmts", stmts);
        return res;
   }

   @Override public ST visitOpList(IMLParser.OpListContext ctx) {
      String op = ctx.getChild(1).getText().trim().toLowerCase();
      String id = ctx.ID().getText().trim();
      String expr = visit(ctx.expression()).render().trim();
      String templateName = op.equals("append") ? "opListAppend" : "opListPop";
      ST res = templates.getInstanceOf(templateName);
      res.add("id", id);
      res.add("expr", expr);
      return res;
   }

   @Override public ST visitRowColStm(IMLParser.RowColStmContext ctx) {
       String op = ctx.getChild(0).getText().trim().toLowerCase();
       String id = ctx.ID().getText();
       String templateName = op.equals("rows") ? "rowStm" : "colStm";
       ST res = templates.getInstanceOf(templateName);
       res.add("id", id);
       return res;
   }

   @Override public ST visitCountPixelExpr(IMLParser.CountPixelExprContext ctx) {
        String intensity = visit(ctx.expression(0)).render().trim();
        String image = visit(ctx.expression(1)).render().trim();
        ST res = templates.getInstanceOf("countPixelExpr");
        res.add("intensity", intensity);
        res.add("image", image);
        return res;
   }

   @Override public ST visitBoolFalseExpr(IMLParser.BoolFalseExprContext ctx) {
      return templates.getInstanceOf("boolFalseExpr");

   }

   @Override public ST visitComparisonExpr(IMLParser.ComparisonExprContext ctx) {
        String e1 = visit(ctx.expression(0)).render().trim();
        String op = ctx.op.getText().trim();
        String e2 = visit(ctx.expression(1)).render().trim();
        ST res = templates.getInstanceOf("comparisonExpr");
        res.add("e1", e1);
        res.add("op", op);
        res.add("e2", e2);
        return res;
   }

   @Override public ST visitPixelOpAddSub(IMLParser.PixelOpAddSubContext ctx) {
        String e1 = visit(ctx.expression(0)).render().trim();
        String op = ctx.op.getText();
        String e2 = visit(ctx.expression(1)).render().trim();
        ST res = templates.getInstanceOf("pixelOpAddSub");
        res.add("e1", e1);
        res.add("op", op);
        res.add("e2", e2);
        return res;
   }

   @Override public ST visitUnaryMinusPixelExpr(IMLParser.UnaryMinusPixelExprContext ctx) {
        String e = visit(ctx.expression()).render().trim();
        ST res = templates.getInstanceOf("unaryMinusPixelExpr");
        res.add("e", e);
        return res;
   }

   @Override public ST visitStringCastExpr(IMLParser.StringCastExprContext ctx) {
        String e = visit(ctx.expression() != null ? ctx.expression() : ctx.readStmt()).render().trim();
        ST res = templates.getInstanceOf("stringCastExpr");
        res.add("e", e);
        return res;
   }

   @Override public ST visitLiteralExpr(IMLParser.LiteralExprContext ctx) {
      String value = visit(ctx.literal()).render().trim();
        ST res = templates.getInstanceOf("literalExpr");
        res.add("value", value);
        return res;
   }

   @Override public ST visitNumberCastExpr(IMLParser.NumberCastExprContext ctx) {
      String e = visit(ctx.expression() != null ? ctx.expression() : ctx.readStmt()).render().trim();
      ST res = templates.getInstanceOf("numberCastExpr");
      res.add("e", e);
      return res;
   }

   @Override public ST visitVarExpr(IMLParser.VarExprContext ctx) {
        String id = ctx.ID().getText().trim();
        ST res = templates.getInstanceOf("varExpr");
        res.add("id", id);
        return res;
   }

   @Override public ST visitListExpr(IMLParser.ListExprContext ctx) {
      List<String> elements = ctx.expression().stream()
                .map(expr -> visit(expr).render())
                .collect(Collectors.toList());
        ST res = templates.getInstanceOf("listExpr");
        res.add("elements", elements);
        return res;
   }

   @Override public ST visitPixelBoolAndOrExpr(IMLParser.PixelBoolAndOrExprContext ctx) {
       String op = ctx.getChild(1).getText().trim().toLowerCase();
       String e1 = visit(ctx.expression(0)).render().trim();
       String e2 = visit(ctx.expression(1)).render().trim();
       String templateName = op.equals("and") ? "pixelBoolAndExpr" : "pixelBoolOrExpr";
       ST res = templates.getInstanceOf(templateName);
       res.add("e1", e1);
       res.add("e2", e2);
       return res;
   }

   @Override public ST visitPixelBoolNotExpr(IMLParser.PixelBoolNotExprContext ctx) {
      String e = visit(ctx.expression()).render();
      ST res = templates.getInstanceOf("pixelBoolNotExpr");
      res.add("e", e);
      return res;
   }

   @Override public ST visitMorphExp(IMLParser.MorphExpContext ctx) {
      String e1 = visit(ctx.expression(0)).render().trim();
      String op = ctx.op.getText().trim();
      String e2 = visit(ctx.expression(1)).render().trim();

      String templateName;
      switch (op) {
         case "erode": templateName = "morphErode"; break;
         case "dilate": templateName = "morphDilate"; break;
         case "open": templateName = "morphOpen"; break;
         case "close": templateName = "morphClose"; break;
         case "top hat": templateName = "morphTopHat"; break;
         case "black hat": templateName = "morphBlackHat"; break;
         default: throw new IllegalArgumentException("Operação morfológica desconhecida: " + op);
      }

      ST res = templates.getInstanceOf(templateName);
      res.add("e1", e1);
      res.add("e2", e2);
      return res;
   }

   @Override public ST visitScaleOpExpr(IMLParser.ScaleOpExprContext ctx) {
      String e1 = visit(ctx.expression(0)).render().trim();
       String op = ctx.getChild(1).getText().trim();
       String e2 = visit(ctx.expression(1)).render().trim();
       String templateName;
       if (op.equals("-*")) {
           templateName = "scaleOpHorizontal";
       } else if (op.equals("|*")) {
           templateName = "scaleOpVertical";
       } else {
           templateName = "scaleOpBoth";
       }
       ST res = templates.getInstanceOf(templateName);
       res.add("e1", e1);
       res.add("e2", e2);
       return res;
   }

   @Override public ST visitPixelComparisonExpr(IMLParser.PixelComparisonExprContext ctx) {
        String e1 = visit(ctx.expression(0)).render().trim();
        String op = ctx.op.getText().trim();
        String e2 = visit(ctx.expression(1)).render().trim();
        ST res = templates.getInstanceOf("pixelComparisonExpr");
        res.add("e1", e1);
        res.add("op", op);
        res.add("e2", e2);
        return res;
   }

   @Override public ST visitUnaryExpr(IMLParser.UnaryExprContext ctx) {
       String op = ctx.getChild(0).getText().trim();
       String e = visit(ctx.expression()).render().trim();
       String templateName = op.equals("+") ? "unaryFlipBothExpr" : "unaryFlipHorizontalExpr";
       ST res = templates.getInstanceOf(templateName);
       res.add("e", e);
       return res;
   }

   @Override public ST visitPixelOpMulDiv(IMLParser.PixelOpMulDivContext ctx) {
        String e1 = visit(ctx.expression(0)).render().trim();
        String op = ctx.op.getText().trim();
        String e2 = visit(ctx.expression(1)).render().trim();
        ST res = templates.getInstanceOf("pixelOpMulDiv");
        res.add("e1", e1);
        res.add("op", op);
        res.add("e2", e2);
        return res;
   }

   @Override public ST visitBoolNotExpr(IMLParser.BoolNotExprContext ctx) {
        String e = visit(ctx.expression()).render().trim();
        ST res = templates.getInstanceOf("BooleanFalse");
        res.add("value", e);
        return res;
   }

   @Override public ST visitBoolTrueEsxpr(IMLParser.BoolTrueEsxprContext ctx) {
        ST res = templates.getInstanceOf("BooleanTrue");
        return res;
   }

   @Override public ST visitPercentageCastExpr(IMLParser.PercentageCastExprContext ctx) {
        String e = visit(ctx.expression() != null ? ctx.expression() : ctx.readStmt()).render().trim();
        ST res = templates.getInstanceOf("percentageCastExpr");
        res.add("e", e);
        return res;
   }

   @Override public ST visitArithOpMulDiv(IMLParser.ArithOpMulDivContext ctx) {
        String e1 = visit(ctx.expression(0)).render().trim();
        String op = ctx.op.getText().trim();
        String e2 = visit(ctx.expression(1)).render().trim();
        ST res = templates.getInstanceOf("arithOpMulDiv");
        res.add("e1", e1);
        res.add("op", op);
        res.add("e2", e2);
        return res;
   }

   @Override public ST visitParenExpr(IMLParser.ParenExprContext ctx) {
         String e = visit(ctx.expression()).render().trim();
         ST res = templates.getInstanceOf("parenExpr");
         res.add("e", e);
         return res;
   }

   @Override public ST visitUnaryMinusExpr(IMLParser.UnaryMinusExprContext ctx) {
        String e = visit(ctx.expression()).render().trim();
        ST res = templates.getInstanceOf("unaryMinusExpr");
        res.add("e", e);
        return res;
   }

   @Override public ST visitAnyAllPixelExpr(IMLParser.AnyAllPixelExprContext ctx) {
         String op = ctx.getChild(0).getText().trim().toLowerCase();
         String e = visit(ctx.expression()).render().trim();
         String templateName = op.equals("any") ? "anyPixelExpr" : "allPixelExpr";
         ST res = templates.getInstanceOf(templateName);
         res.add("e", e);
         return res;
   }

   @Override public ST visitArithOpAddSub(IMLParser.ArithOpAddSubContext ctx) {
        String e1 = visit(ctx.expression(0)).render().trim();
        String op = ctx.op.getText().trim();
        String e2 = visit(ctx.expression(1)).render().trim();
        ST res = templates.getInstanceOf("arithOpAddSub");
        res.add("e1", e1);
        res.add("op", op);
        res.add("e2", e2);
        return res;
   }

   @Override public ST visitBoolAndOrExpr(IMLParser.BoolAndOrExprContext ctx) {
         String e1 = visit(ctx.expression(0)).render().trim();
         String op = ctx.op.getText().trim();
         String e2 = visit(ctx.expression(1)).render().trim();
         ST res = templates.getInstanceOf("boolAndOrExpr");
         res.add("e1", e1);
         res.add("op", op);
         res.add("e2", e2);
         return res;
   }

   @Override public ST visitNumberLiteral(IMLParser.NumberLiteralContext ctx) {
        String value = ctx.NUMBER().getText().trim();
        ST res = templates.getInstanceOf("numberLiteral");
        res.add("value", value);
        return res;
   }

   @Override public ST visitPercentageLiteral(IMLParser.PercentageLiteralContext ctx) {
         String value = ctx.PERCENTAGE().getText().trim();
         value = "\"" + value + "\"";
         ST res = templates.getInstanceOf("percentageLiteral");
         res.add("value", value);
         return res;
   }

   @Override public ST visitStringLiteral(IMLParser.StringLiteralContext ctx) {
         String value = ctx.STRING().getText().trim();
         ST res = templates.getInstanceOf("stringLiteral");
         res.add("value", value);
         return res;
   }
}
