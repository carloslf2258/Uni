//import java.util.Objects;

public class TypeNumber extends Type {

  public TypeNumber() {
    super("Number");
  }

  @Override
  public boolean isNumeric() {
    return true;
  }

  @Override
  public Type unify(Type other) {
    //REVIEW se Number + Percentage = Number ou Percentage (mesma duvida em TypePercentage)
    // Number + Percentage = Number
    if (other instanceof TypePercentage) {
      return new TypeNumber();
    }
    // Number + Number = Number
    if (other instanceof TypeNumber) {
      return this;
    }
    return super.unify(other); // para ir para o erro default
  }

  /* @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (!(obj instanceof TypeNumber)) return false;
    return true;
  } */

  /* @Override
  public int hashCode() {
    return Objects.hash(getClass());
  } */
}
