import static java.lang.System.*;

import error.*;
import java.util.ArrayList;
import java.util.List;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.TerminalNode;

@SuppressWarnings("CheckReturnValue")
public class SemanticAnalyser extends IMLBaseVisitor<Type> {

  private SymbolTable symbolTable;

  public SemanticAnalyser() {
    this.symbolTable = new SymbolTable();
  }

  //NOTE - Como os stts não se relacionam não é preciso verificar nada semanticamente aqui
  @Override
  public Type visitProgram(IMLParser.ProgramContext ctx) {
    return visitChildren(ctx);
  }

  // NOTE - Não se aplica regra semantica porque os varios tipos de statement não se relacionam
  // Nao interessa se um tipo de stt retornou null porque ele não se vai relacionar com outro tipo
  @Override
  public Type visitStatement(IMLParser.StatementContext ctx) {
    return visitChildren(ctx);
  }

  @Override
  public Type visitAssignment(IMLParser.AssignmentContext ctx) {
    String varName = ctx.ID().getText();
    Type declaredType = null;

    // Verifica se existe declaração de tipo
    if (ctx.type() != null) {
      declaredType = visit(ctx.type());
    }

    // Visita o lado direito da atribuição: expression | loadImg | lingSEC
    Type valueType = null;
    if (ctx.expression() != null) valueType = visit(ctx.expression()); else if (
      ctx.loadImg() != null
    ) valueType = visit(ctx.loadImg()); else if (
      ctx.lingSEC() != null
    ) valueType = visit(ctx.lingSEC());

    // Se houve erro já foi detetado ao visitar o que esta no lado direito
    // e por isso a atribuição é cancelada (resulta da propagação do erro por parte das funcoes)
    if (valueType == null) return null;

    // Com declaração de tipo
    if (declaredType != null) {
      // Verifica se o tipo declarado aceita o tipo atribuído
      if (!declaredType.isAssignableFrom(valueType)) {
        ErrorHandling.printError(
          ctx,
          "O tipo atribuído (" +
          valueType +
          ") não é compatível com o tipo declarado (" +
          declaredType +
          ")."
        );
        return null;
      }

      // Tenta definir a variável na tabela
      try {
        symbolTable.define(new SymbolVariable(varName, declaredType));
      } catch (SymbolTable.RedefinitionException e) {
        ErrorHandling.printError(
          ctx,
          "Variável \"" + varName + "\" já foi declarada neste escopo."
        );
        return null;
      }
    }
    // Sem declaração de tipo: verificar se variável já existe
    else {
      Symbol existing = symbolTable.lookup(varName);
      if (existing == null) {
        ErrorHandling.printError(
          ctx,
          "A variável \"" + varName + "\" não foi previamente declarada."
        );
        return null;
      }

      // Ver se valor atribuido corresponde ao tipo na tabela
      Type existingType = existing.getType();
      if (!existingType.isAssignableFrom(valueType)) {
        ErrorHandling.printError(
          ctx,
          "Atribuição inválida: valor de tipo " +
          valueType +
          " não é compatível com a variável \"" +
          varName +
          "\" de tipo " +
          existingType +
          "."
        );
        return null;
      }
    }

    return null;
  }

  // NOTE - Regras semanticas:
  //      - Parser trata de tudo -> nao faz sentido criar testes de erro
  //      - So tem de retornar o type
  @Override
  public Type visitType(IMLParser.TypeContext ctx) {
    // print apenas para testes -> ver se realmente foi visitado
    //System.out.println("visitType visitado com: " + ctx.getText());
    if (ctx.getChildCount() == 1) {
          return switch (ctx.getText()) {
              case "image" -> new TypeImage();
              case "number" -> new TypeNumber();
              case "string" -> new TypeString();
              case "percentage" -> new TypePercentage();
              default -> null; // nunca deve acontecer -> se passou pelo parser é um tipo valido
          };
      }

      // Caso recursivo: list of <type>
      Type innerType = visit(ctx.type());
      return innerType == null ? null : new TypeList(innerType);
  }

  // NOTE - aqui o parser trata de verificar tudo.
  //      - apenas temos de retornar img porque se esta funcao chegar a ser visitada é porque esta semanticamente correta
  //      - o resto para alem dos returns é apenas programação defensiva
  //      - Podemos fazer testes de erro para verificar se o parser cobre todos os erros semanticos
  @Override
  public Type visitLoadImg(IMLParser.LoadImgContext ctx) {
    //System.out.println("visitLoadImg visitado com: " + ctx.getText());
    
    // Caso direto: STRING (ex: load from "img.pgm")
    if (ctx.STRING() != null) {

      /* 
       //NOTE Nao implementado, mas caso seja preciso isto faz algumas restrincoes ao tipo de ficheiro que pode ser carregado
      String rawFilename = ctx.STRING().getText(); // inclui aspas
       String filename = rawFilename.substring(1, rawFilename.length() - 1); // remove aspas
         if (!filename.endsWith(".pgm")) {
               ErrorHandling.printError(ctx, "Apenas ficheiros com extensão .pgm são permitidos.");
               return null;
         } 
         */

      return new TypeImage();
    }

    // readStmt retorna sempre uma string pois é:
    // input do utilizador
    Type readType = visit(ctx.readStmt());

    if (readType == null) return null;

    // Apenas boa prática - programacao defensiva
    // Porque sempre que o readStmt é visitado tem de retornar uma string
    if (!readType.isString()) {
      ErrorHandling.printError(
        ctx,
        "A expressão 'read' em 'load from read' deve retornar uma string."
      );
      return null;
    }

    return new TypeImage();
  }
  
  // NOTE - Neste caso parser trata de tudo
  // Se ele chegar ao visitor é porque é uma string(tipo valido - já verificado pelo parser)
  //  e por isso pode fazer return new TypeString sem problemas.
  @Override
  public Type visitReadStmt(IMLParser.ReadStmtContext ctx) {
    //System.out.println("visitReadStmt visitado com: " + ctx.getText());

    if (ctx.getChildCount() == 1 || (ctx.getChildCount() == 2 && ctx.STRING() != null)) {
      // read sem string explícita, mas válido
      return new TypeString();
    }

    ErrorHandling.printError(
        ctx,
        "'read' tem de ser seguido de string ou vazio.");

      return null;
    }

  // REVIEW - decidir os tipos que se pode fazer output
  // NOTE - permitir fazer output de: String, Imagem?, Number e Percentage
  @Override
  public Type visitOutputStmt(IMLParser.OutputStmtContext ctx) {
    //System.out.println("visitOutput visitado com: " + ctx.getText());
    Type exprType = visit(ctx.expression());
    if (exprType == null) return null; // erro já reportado

    // Verifica se é um tipo permitido
    if (
      !(
        exprType instanceof TypeString ||
        exprType instanceof TypeNumber ||
        exprType instanceof TypeImage ||
        exprType instanceof TypePercentage
      )
    ) {
      ErrorHandling.printError(
        ctx,
        "Só é possível fazer output de strings, números, imagens ou percentagens. Tipo recebido: " +
        exprType
      );
      return null;
    }

    // Output não produz valor útil -> pode retornar sempre null
    return null;
  }

  // Como é uma ling que permite criar imagens etc penso que
  // é run x.iiml que depois retorna typeImage
  // mas posso esta completamente errado
  @Override
  public Type visitLingSEC(IMLParser.LingSECContext ctx) {
    //System.out.println("visitLingSEC visitado com: " + ctx.getText());
    if (ctx.STRING() != null) {

      /* 
       String raw = ctx.STRING().getText(); // inclui aspas
      String filename = raw.substring(1, raw.length() - 1); // remove aspas
      if (!filename.endsWith(".iiml")) {
        ErrorHandling.printError(
          ctx,
          "Apenas ficheiros com extensão .iiml são suportados para 'run from'."
        );
        return null;
      } */

      return new TypeImage();
    }

    if (ctx.readStmt() != null) {
      Type readType = visit(ctx.readStmt());
      if (readType == null) return null;

      // defensivo
      if (!readType.isString()) {
        ErrorHandling.printError(
          ctx,
          "O valor lido por 'read' em 'run from' deve ser uma string."
        );
        return null;
      }

      return new TypeImage();
    }

    // Programação defensiva (não devia passar no parser)
    ErrorHandling.printError(ctx, "Fonte inválida para 'run from'.");
    return null;
  }

  // NOTE  - Ver se ID esta declarado
  //       - Ver se esta associado a um tipo valido para desenhar -> Image
  @Override
  public Type visitDrawStmt(IMLParser.DrawStmtContext ctx) {
    //System.out.println("visitDrawStmt visitado com: " + ctx.getText());
    String varName = ctx.ID().getText();
    Symbol var = symbolTable.lookup(varName);

    if (var == null) {
      ErrorHandling.printError(
        ctx,
        "A variável \"" + varName + "\" não foi declarada."
      );
      return null;
    }

    Type varType = var.getType();

    if (!varType.isImage()) {
      ErrorHandling.printError(
        ctx,
        "Só é possível desenhar imagens. A variável \"" +
        varName +
        "\" é do tipo " +
        varType +
        "."
      );
      return null;
    }

    return null; // Não produz valor útil
  }

  // NOTE  - Verificar se variavel (ID) esta declarada na tabela
  //       - Obter e validar tipo da variavel -> Imagem ou Lista de Imgs
  //       - Verificar extensão do ficheiro:
  //    - Se imagem         -> .pgm
  //    - Se lista de imgs  -> .gif
  @Override
  public Type visitStoreStmt(IMLParser.StoreStmtContext ctx) {
    //System.out.println("visitStoreStmt visitado com: " + ctx.getText());

    String varName = ctx.ID().getText();

    // Verifica se a variável está declarada
    Symbol varSymbol = symbolTable.lookup(varName);
    if (varSymbol == null) {
      ErrorHandling.printError(
        ctx,
        "Variável \"" + varName + "\" não foi declarada."
      );
      return null;
    }

    Type varType = varSymbol.getType();

    // Aceita imagens únicas
    if (varType.isImage()) {
      return null; // válido
    }

    // Aceita listas de imagens
    if (varType.isList()) {
      Type innerType = ((TypeList) varType).elemType();
      if (innerType.isImage()) {
        return null; // válido
      }
    }

    // Qualquer outro tipo é inválido
    ErrorHandling.printError(
      ctx,
      "A instrução 'store' só pode ser usada com imagens ou listas de imagens. Tipo recebido: " + varType
    );
    return null;
  }
 
 
  @Override
  public Type visitIfStmt(IMLParser.IfStmtContext ctx) {
    //System.out.println("visitIfStmt visitado com: " + ctx.getText());

    Type condType = visit(ctx.expression());

    if (condType == null) {
      return null; // erro já reportado anteriormente
    }

    // Ver se condicao é boleana

    if (!condType.isBoolean()) {
      ErrorHandling.printError(
        ctx,
        "A condição do 'if' deve ser uma expressão booleana."
      );
      return null;
    }

    // visitar bloco then em novo escopo
    symbolTable.push();
    int thenSize = ctx.statement().size() - ctx.elseBlock.size();
    for (int i = 0; i < thenSize; i++) {
      visit(ctx.statement(i));
    }
    symbolTable.pop();

    // visitar bloco else (se existir) num novo escopo
    if (!ctx.elseBlock.isEmpty()) {
      symbolTable.push();
      for (IMLParser.StatementContext stmt : ctx.elseBlock) {
        visit(stmt);
      }
      symbolTable.pop();
    }

    return null;
  }

  @Override
  public Type visitForStmt(IMLParser.ForStmtContext ctx) {
    //System.out.println("visitForStmt visitado com: " + ctx.getText());
    
    // expressão depois de within
    Type exprType = visit(ctx.expression());
    if (exprType == null) return null;

    // ver se é lista
    if (!exprType.isList()) {
      ErrorHandling.printError(
        ctx,
        "'for' espera uma lista após 'within', mas recebeu: " + exprType
      );
      return null;
    }

    // Obter innerType
    Type innerType = ((TypeList) exprType).elemType();

    // se foi declarado um tipo ao ID -> verificar compatibilidade
    if (ctx.type() != null) {
      Type declaredType = visit(ctx.type()); // Type declarado no 'for'
      if (declaredType == null) return null;

      if (!declaredType.isAssignableFrom(innerType)) {
        ErrorHandling.printError(
          ctx,
          "Tipo da variável de iteração (" +
          declaredType +
          ") não é compatível com os elementos da lista (" +
          innerType +
          ")"
        );
        return null;
      }
      // se compativel:
      innerType = declaredType;
    }

    symbolTable.push();

    // declarar variável de iteração no escopo
    String varName = ctx.ID().getText();
    symbolTable.define(new SymbolVariable(varName, innerType));

    for (IMLParser.StatementContext stmt : ctx.statement()) {
      visit(stmt);
    }

    symbolTable.pop();

    return null;
  }

  @Override
  public Type visitUntilStmt(IMLParser.UntilStmtContext ctx) {
    // condicao tem de ser boleana
    Type condType = visit(ctx.expression());
    if (condType == null) return null;

    if (!condType.isBoolean()) {
      ErrorHandling.printError(
        ctx,
        "A condição do 'until' deve ser uma expressão booleana."
      );
      return null;
    }

    symbolTable.push();
    try {
      for (IMLParser.StatementContext stmt : ctx.statement()) {
        visit(stmt);
      }
    } finally {
      symbolTable.pop();
    }
    // REVIEW try finaly garante que o pop é chamado -> posso aplicar tambem nos metodos acima
    return null;
  }

  @Override
  public Type visitOpList(IMLParser.OpListContext ctx) {
    //System.out.println("visitOpList visitado com: " + ctx.getText());
    // verificar se var está na tabela de simbolos
    String varName = ctx.ID().getText();
    Symbol sym = symbolTable.lookup(varName);
    if (sym == null) {
      ErrorHandling.printError(ctx, "Variável '" + varName + "' não definida.");
      return null;
    }

    Type listType = sym.getType();

    // ver se é tipo list
    if (!listType.isList()) {
      ErrorHandling.printError(
        ctx,
        "A variável '" +
        varName +
        "' deve ser uma lista para aplicar '" +
        ctx.op.getText() +
        "'."
      );
      return null;
    }

    // obter tipo do elemento da lista
    Type elemType = ((TypeList) listType).elemType();

    // visitar expr
    Type exprType = visit(ctx.expression());
    if (exprType == null) return null;

    // ver compatibilidade
    if (!elemType.isAssignableFrom(exprType)) {
      ErrorHandling.printError(
        ctx,
        "Não é possível " +
        ctx.op.getText() +
        " um elemento do tipo " +
        exprType +
        " a uma lista de " +
        elemType +
        "."
      );
      return null;
    }

    return null;
  }

  @Override
  public Type visitRowColStm(IMLParser.RowColStmContext ctx) {
    //System.out.println("visitRowColStm visitado com: " + ctx.getText());
    String varName = ctx.ID().getText();

    Symbol sym = symbolTable.lookup(varName);
    if (sym == null) {
      ErrorHandling.printError(ctx, "Variável não definida: " + varName);
      return null;
    }

    Type varType = sym.getType();
    if (!varType.isImage()) {
      ErrorHandling.printError(
        ctx,
        "A operação '" + ctx.op.getText() + "' só pode ser aplicada a imagens."
      );
      return null;
    }

    // op rows/columns devolve nº
    return new TypeNumber();
  }

  // NOTE - aceita apenas intensidades do tipo number (rejeitei percentage porque acho que percentagem é relativa a algo e aqui
  // procura-se um valor absoluto de intensidade -> entre 0 e 1)
  //       - a expr do lado direito tem de ser do tipo image
  //       - retorna um numero
  @Override
  public Type visitCountPixelExpr(IMLParser.CountPixelExprContext ctx) {
    Type pixelValueType = visit(ctx.expression(0));
    Type imageExprType = visit(ctx.expression(1));

    if (pixelValueType == null || imageExprType == null) return null;

    //REVIEW talvez permitir tanto percentage como number (para isso usar isNumeric())
    if (!(pixelValueType instanceof TypeNumber)) {
      ErrorHandling.printError(
        ctx.expression(0),
        "O valor do pixel a contar deve ser do tipo number."
      );
      return null;
    }

    if (!imageExprType.isImage()) {
      ErrorHandling.printError(
        ctx.expression(1),
        "A expressão após 'in' deve ser uma imagem."
      );
      return null;
    }

    return new TypeNumber();
  }

  // NOTE - não ha erro semantico possivel
  //      - visita apenas tem de retornar tipo boleano

  @Override
  public Type visitBoolFalseExpr(IMLParser.BoolFalseExprContext ctx) {
    return new TypeBoolean();
  }

  // REVIEW - numero com numero; percentagem c percentagem -> permitido
  //        - Se for string ou boolean permitir permitir == e !=
  // Penso que img e list nao se compara aqui -> tem mais haver com #PixelComparisonExpr

  @Override
  public Type visitComparisonExpr(IMLParser.ComparisonExprContext ctx) {
    Type left = visit(ctx.expression(0));
    Type right = visit(ctx.expression(1));

    if (left == null || right == null) return null;

    String op = ctx.op.getText();

    if (left.isNumeric() && right.isNumeric()) {
      return new TypeBoolean();
    }

    if (
      (op.equals("==") || op.equals("!=")) &&
      left.getClass().equals(right.getClass()) && // podesse retirar o && de baixo para dar para comparar qualquer tipo
      (left.isString() || left.isBoolean())
    ) {
      return new TypeBoolean();
    }

    ErrorHandling.printError(
      ctx,
      "Comparação inválida entre tipos: " + left + " " + op + " " + right
    );
    return null;
  }


  @Override
  public Type visitPixelOpAddSub(IMLParser.PixelOpAddSubContext ctx) {
    Type left = visit(ctx.expression(0));
    Type right = visit(ctx.expression(1));

    if (left == null || right == null) return null;

    // ambos os ops devem ser imgs
    if (!left.isImage() || !right.isImage()) {
      ErrorHandling.printError(
        ctx,
        "A operação pixel a pixel '" +
        ctx.op.getText() +
        "' requer dois operandos do tipo imagem."
      );
      return null;
    }

    return new TypeImage();
  }

  // NOTE - Unica cond semantica é ver se expr é do tipo img
  //      - retorna type image (inverso da imagem inicial)
  @Override
  public Type visitUnaryMinusPixelExpr(
    IMLParser.UnaryMinusPixelExprContext ctx
  ) {
    Type exprType = visit(ctx.expression());

    if (exprType == null) return null;

    if (!exprType.isImage()) {
      ErrorHandling.printError(ctx, "Operador unário .- requer uma imagem.");
      return null;
    }

    return new TypeImage(); // o resultado continua a ser uma imagem
  }

  //        - retorna string
  @Override
  public Type visitStringCastExpr(IMLParser.StringCastExprContext ctx) {
    Type innerType = visit(ctx.expression());

    if (innerType == null) return null;

    // REVIEW - recebe tudo menos img e lista(?)
    /* if ( innerType instanceof TypeList ){
         //nao pode aceitar se o ultimo type da recursao da lista for uma imagem
    } */
    if (
      !(innerType instanceof TypeNumber) &&
      !(innerType instanceof TypePercentage) &&
      !(innerType instanceof TypeString) &&
      !(innerType instanceof TypeBoolean)
    ) {
      ErrorHandling.printError(
        ctx,
        "Conversão para string requer um tipo string, number, percentage ou boolean."
      );
      return null;
    }

    return new TypeString();
  }

  @Override
  public Type visitLiteralExpr(IMLParser.LiteralExprContext ctx) {
    //System.out.println("visitLiteralExpr visitado com: " + ctx.getText());
    return visitChildren(ctx);
  }

  // NOTE  - Penso que não faria sentido dar erro se alguem fizesse number n is number(5)
  //       - Permite strings e number types para fazer cast para number
  //       - Retorna type number obviamente
  //REVIEW - Penso que percentagem pode ser aceite, ex: 20% -> 0.2 -> converter para numeros entre 0 e 1 -> Coloquei
  //       - Boolean penso que poderia ser mas nao tenho a certeza number(True) -> 1?? -> Não coloquei
  @Override
  public Type visitNumberCastExpr(IMLParser.NumberCastExprContext ctx) {
    //System.out.println("visitNumberCastExpr visitado com: " + ctx.getText());
    
    Type innerType = null;

    if (ctx.expression() != null) {
      innerType = visit(ctx.expression());
    } else if (ctx.readStmt() != null) {
      innerType = visit(ctx.readStmt());
    }

    if (innerType == null) return null;

    if (!innerType.isNumeric() && !innerType.isString()) {
      ErrorHandling.printError(
        ctx,
        "Conversão para número requer um tipo string, number ou percentage."
      );
      return null;
    }

    return new TypeNumber();
  }

  // NOTE - verifica se var foi declarada
  //      - retorna o tipo da variavel declarada na tabela de symb
  @Override
  public Type visitVarExpr(IMLParser.VarExprContext ctx) {
    //System.out.println("visitVarExpr visitado com: " + ctx.getText());
    String varName = ctx.ID().getText();

    Symbol symbol = symbolTable.lookup(varName);

    if (symbol == null) {
      ErrorHandling.printError(
        ctx,
        "Variável '" + varName + "' não foi declarada."
      );
      return null;
    }

    return symbol.getType();
  }

  // NOTE - isto e usado tanto para declaracao de variaveis como para atribuicoes
  /*
    lida com casos em que é declarada uma variavel e casos onde um valor é atribuido a uma variavel, sendo que a variavel é uma lista caso contrario visitListExpr
    nao seria chamado. A diferenciacao de se esta a ser usada para uma declaracao ou atribuição só é necessaria quando a lista está vazia, e esta diferenciacao é 
    feita apartir da verificacao se no contexto do parent existe um type(). No caso da lista estar vazia, se for uma declaracao, irá retornar exatamente o mesmo 
    type que recebe no contexto do parent sendo que os types que recebe do parent so podem ser list number, list string, list percentage, list image ou uma recursao 
    de list com um outro type na ultima lista. No caso da lista estar vazia e for uma atribuição dá erro, e este em principio é um caso que nunca acontecerá pois para 
    existir uma variavel é preciso haver a sua declaracao previa. No caso da lista nao estar vazia simplesmente faz a analise se todos os elementos sao do mesmo tipo e 
    devolve a list desse type, e isto funciona tanto para o caso de declaracao de variaveis como de atribuicoes de variaveis. 
    */
  @Override
  public Type visitListExpr(IMLParser.ListExprContext ctx) {
    //System.out.println("visitListExpr visitado com: " + ctx.getText());
    Type res = null;
    List<Type> elementsTypes = new ArrayList<>(); // para depois fazer a analise se todos os elementos sao do mesmo tipo
    for (IMLParser.ExpressionContext elemCtx : ctx.expression()) {
      Type t = visit(elemCtx); // visitar subexpressao
      if (t == null) { //em caso de erro (reportado na visita)
        return null;
      }
      elementsTypes.add(t);
    }

    if (elementsTypes.isEmpty()) {
      //REVIEW isto parece estanho, mas nao sei como dar a volta sem ter que visitar o parent
      ParserRuleContext parent = ctx.getParent(); //para ir ao parent (em principio visitAssignment) obter o tipo
      if (parent instanceof IMLParser.AssignmentContext) {
        IMLParser.AssignmentContext assignCtx = (IMLParser.AssignmentContext) parent;
        // Se houver declaração “list of T” antes do ID:
        if (assignCtx.type() != null) { //?: so ocorre a verificacao se houver algo do tipo "list of T x is []", contra exemplo seria "x is []"
          Type declaredType = visit(assignCtx.type());
          if (declaredType == null) return null; // erro já reportado pelo visit
          if (!declaredType.isList()) {
            ErrorHandling.printError(
              ctx,
              "Declaração de tipo não é lista, mas literal [] foi usado."
            );
            return null;
          }
          // Retorna exatamente esse TypeList(T) declarado, sem outra checagem
          return declaredType;
        }
      }
      ErrorHandling.printError(
        ctx,
        "Lista vazia sem contexto de tipo explícito."
      );
      return null;
    }

    //+:Verificacao de que todos os elementos sao do mesmo tipo
    /* 
    //REVIEW Usar este caso se queira listas de tipos unificaveis
    //       Por exemplo permite fazer uma lista com elementos do tipo number e percentage
    Type unifiedType = elementsTypes.get(0);
    for (int i = 1; i < elementsTypes.size(); i++) {
      Type other = elementsTypes.get(i);
      Type newUnified = unifiedType.unify(other); //tenta fazer a uniao, se a uniao for possivel e porque sao do mesmo tipo
      if (newUnified == null) {
        ErrorHandling.printError(
          ctx,
          "Elementos da lista incompativeis: " + unifiedType + " vs " + other
        );
        return null;
      }
      unifiedType = newUnified;
    }
*/
    //NOTE aqui contrariamente a caso a lista esteja vazia, nao faz verificacao com o tipo declarado em Assigment porque isso e responsabilidade de visitAssignment
    Type baseType = elementsTypes.get(0);
    for (int i = 1; i < elementsTypes.size(); i++) {
      Type other = elementsTypes.get(i);
      if (!baseType.getClass().equals(other.getClass())) {
        ErrorHandling.printError(
          ctx,
          "Elementos da lista têm tipos diferentes: " +
          baseType +
          " vs " +
          other
        );
        return null;
      }
    }
    return new TypeList(baseType);
  }



  // REVIEW   - So aceita and/or entre tipos img
  //          - retorna tipo img
  @Override
  public Type visitPixelBoolAndOrExpr(IMLParser.PixelBoolAndOrExprContext ctx) {
    //System.out.println("visitPixelBoolAndOrExpr visitado com: " + ctx.getText());
    Type left = visit(ctx.expression(0));
    Type right = visit(ctx.expression(1));

    if (left == null || right == null) return null;

    if (!left.isImage() || !right.isImage()) {
      ErrorHandling.printError(
        ctx,
        "Operação booleana pixel a pixel requer duas imagens."
      );
      return null;
    }

    return new TypeImage();
  }

  // REVIEW - Parece me ter exatamente o mesmo proposito que .- mas posso estar enganado
  //        - De qualquer forma a analise semantica será sempre esta
  // Parece me que isto pode representar uma operação boll pixel a pixel tratando o valor absoluto do pixel como boleano (truncando)
  //NOTE - Operação pixel a pixel tem de operar sobre o tipo image
  //     - Retorno é do tipo Image
  @Override
  public Type visitPixelBoolNotExpr(IMLParser.PixelBoolNotExprContext ctx) {
    //System.out.println("visitPixelBoolNotExpr visitado com: " + ctx.getText());
    Type inner = visit(ctx.expression());

    if (inner == null) return null;

    if (!inner.isImage()) {
      ErrorHandling.printError(
        ctx,
        "O operador '.not' requer uma expressão do tipo imagem."
      );
      return null;
    }

    return new TypeImage();
  }

  // REVIEW - op da esquerda tem de ser imagem
  //        - op da direita tem de ser lista de lista de numeros
  //        - retorna tipo image
  @Override
  public Type visitMorphExp(IMLParser.MorphExpContext ctx) {
    
    //System.out.println("visitMorphExp visitado com: " + ctx.getText());
    
    Type left = visit(ctx.expression(0));
    Type right = visit(ctx.expression(1));

    if (left == null || right == null) return null;

    if (!left.isImage()) {
      ErrorHandling.printError(
        ctx,
        "O operando à esquerda numa operação morfológica deve ser uma imagem."
      );
      return null;
    }

    boolean isValidKernel =
      right.isImage() ||
      (
        right instanceof TypeList &&
        ((TypeList) right).elemType() instanceof TypeList &&
        ((TypeList) ((TypeList) right).elemType()).elemType() instanceof TypeNumber
      );

    if (!isValidKernel) {
      ErrorHandling.printError(
        ctx,
        "O operando à direita numa operação morfológica deve ser uma imagem ou uma lista de listas de números (kernel)."
      );
      return null;
    }

    return new TypeImage();
  }

  // REVIEW - Mais uma vez segui os exemplos e não permiti escalar com percentagem
  //        - Pode fazer sentido faze-lo e por isso tem de ser revisto
  @Override
  public Type visitScaleOpExpr(IMLParser.ScaleOpExprContext ctx) {
    
    //System.out.println("visitScaleOpExpr visitado com: " + ctx.getText());
    
    Type left = visit(ctx.expression(0));
    Type right = visit(ctx.expression(1));

    if (left == null || right == null) return null;

    if (!left.isImage()) {
      ErrorHandling.printError(
        ctx,
        "O operando à esquerda de '" +
        ctx.op.getText() +
        "' deve ser uma imagem."
      );
      return null;
    }

    //REVIEW Caso se queira usar tambem percentagens usar isNumeric()
    if (!(right instanceof TypeNumber)) {
      ErrorHandling.printError(
        ctx,
        "O operando à direita de '" +
        ctx.op.getText() +
        "' deve ser do tipo número."
      );
      return null;
    }

    return new TypeImage();
  }

  // REVIEW - faz sentido comparar uma imagem pixel a pixel com outra do ponto de vista semantico
  // ou seja nao sabendo se elas irao ter as mesmas dimensoes ou nao
  // Por enquanto permiti comparações entre imagens porque acho que seria valido na linguagem(retornaria img com 0 e 1s -> preto e branco)
  @Override
  public Type visitPixelComparisonExpr(
    IMLParser.PixelComparisonExprContext ctx
  ) {
    
    //System.out.println("visitPixelComparisonExpr visitado com: " + ctx.getText());

    Type left = visit(ctx.expression(0));
    Type right = visit(ctx.expression(1));

    if (left == null || right == null) return null;

    if (!left.isImage()) {
      ErrorHandling.printError(
        ctx,
        "O operando à esquerda de uma comparação pixel a pixel deve ser uma imagem."
      );
      return null;
    }

    if (!right.isNumeric() && !right.isImage()) {
      ErrorHandling.printError(
        ctx,
        "O operando à direita de uma comparação pixel a pixel deve ser um número ou uma imagem."
      );
      return null;
    }

    return new TypeImage();
  }

  // REVIEW - confirmar que esta regra corresponde a flips
  // Se sim, perceber porque o - é  tratado numa regra à parte
  @Override
  public Type visitUnaryExpr(IMLParser.UnaryExprContext ctx) {
    
    //System.out.println("visitUnaryExpr visitado com: " + ctx.getText());
    
    Type exprType = visit(ctx.expression());

    if (exprType == null) {
      return null;
    }

    // flip so pode ser aplicado a img
    if (!exprType.isImage()) {
      ErrorHandling.printError(
        ctx,
        "Operador '" + ctx.op.getText() + "' só pode ser aplicado a imagens."
      );
      return null;
    }

    // retorna img
    return exprType;
  }

  //REVIEW ->
  //       - Não pode haver mul e div de duas imgs pix a pix penso eu (não aparece em nenhum dos exemplos por isso por enquanto n coloquei)
  //       - Os unicos tipos permitidos em expr são percentage e img -> sendo img obrigatoriamente um deles e % o outro
  //       - Poderiamos permitir multiplicar por numeros entre 0 e 1? (vai dar ao mesmo que %)
  //       - Teria de ser entre 0 e 1? "pixeis permanecem dentro do intervalo [0, 1], mesmo após operações que excedam esses limites"
  // Para já respeitei apenas o que esta nos exemplos e acitei apenas img e %
  @Override
  public Type visitPixelOpMulDiv(IMLParser.PixelOpMulDivContext ctx) {
    
    //System.out.println("visitPixelOpMulDiv visitado com: " + ctx.getText());
    
    Type left = visit(ctx.expression(0));
    Type right = visit(ctx.expression(1));

    if (left == null || right == null) return null;

    // Apenas se um for imagem e o outro percentagem (em qualquer ordem)
    if (
      (left.isImage() && right instanceof TypePercentage) ||
      (left instanceof TypePercentage && right.isImage())
    ) {
      return new TypeImage();
    }

    // Caso contrário, erro
    ErrorHandling.printError(
      ctx,
      "Operação pixel a pixel '*' ou '/' requer um operando imagem e outro percentagem."
    );
    return null;
  }

  // NOTE - So permite expr do tipo boolean
  //      - Retorna boolean

  @Override
  public Type visitBoolNotExpr(IMLParser.BoolNotExprContext ctx) {
    
    //System.out.println("visitBoolNotExpr visitado com: " + ctx.getText());

    Type exprType = visit(ctx.expression());

    if (exprType == null) return null;

    if (!exprType.isBoolean()) {
      ErrorHandling.printError(
        ctx,
        "Operador 'not' requer uma expressão booleana."
      );
      return null;
    }

    return new TypeBoolean();
  }

  // NOTE - parser trata de tudo
  //      - apenas retorna type boolean

  @Override
  public Type visitBoolTrueEsxpr(IMLParser.BoolTrueEsxprContext ctx) {
    //System.out.println("visitBoolTrueEsxpr visitado com: " + ctx.getText());
    return new TypeBoolean();
  }

  // NOTE - pode receber tipo percentage, number ou string
  //      - retorna percentage
  @Override
  public Type visitPercentageCastExpr(IMLParser.PercentageCastExprContext ctx) {
    
    //System.out.println("visitPercentageCastExpr visitado com: " + ctx.getText());
    
    Type innerType = visit(ctx.expression());

    if (innerType == null) return null;

    if (!innerType.isNumeric() && !innerType.isString()) {
      ErrorHandling.printError(
        ctx,
        "Conversão para percentage requer um tipo string, number ou percentage."
      );
      return null;
    }

    return new TypePercentage();
  }

  // NOTE - apenas verifica se ambos os operandos são numericos
  @Override
  public Type visitArithOpMulDiv(IMLParser.ArithOpMulDivContext ctx) {
    
    //System.out.println("visitArithOpMulDiv visitado com: " + ctx.getText());
    
    Type left = visit(ctx.expression(0));
    Type right = visit(ctx.expression(1));

    if (left == null || right == null) {
      return null; // erro numa das expr -> cancela operação
      // e propaga operação cancelada ate ao cimo da arvore
      // o erro já foi lançado no filho atraves do ErrorHandling
    }

    if (!left.isNumeric() || !right.isNumeric()) {
      ErrorHandling.printError(
        ctx,
        "Multiplicação/Divisão requer operandos numéricos."
      );
      return null;
    }

    return left.unify(right);
  }

  @Override
  public Type visitParenExpr(IMLParser.ParenExprContext ctx) {
    
    //System.out.println("visitParenExpr visitado com: " + ctx.getText());
    
    return visit(ctx.expression()); // apenas propaga o tipo da expressão entre parêntesis
  }

  // NOTE  - aceita tipo number e percentage
  //       - retorna o proprio tipo
  @Override
  public Type visitUnaryMinusExpr(IMLParser.UnaryMinusExprContext ctx) {
    
    //System.out.println("visitUnaryMinusExpr visitado com: " + ctx.getText());
    
    Type inner = visit(ctx.expression());

    if (inner == null) return null;

    if (!inner.isNumeric()) {
      ErrorHandling.printError(
        ctx,
        "O operador unário '-' requer um operando numérico (number ou percentage)."
      );
      return null;
    }

    return inner;
  }

  // NOTE - a expr tem de ser do tipo image ou lista de boleanos
  //      - retorna tipo boleano

  @Override
  public Type visitAnyAllPixelExpr(IMLParser.AnyAllPixelExprContext ctx) {
    
    //System.out.println("visitAnyAllPixelExpr visitado com: " + ctx.getText());

    Type exprType = visit(ctx.expression());
    if (exprType == null) return null;

    boolean isImage = exprType.isImage();
    boolean isBoolList =
      exprType instanceof TypeList &&
      ((TypeList) exprType).elemType().isBoolean();

    if (!isImage && !isBoolList) {
      ErrorHandling.printError(
        ctx,
        "'any pixel' ou 'all pixel' requerem uma imagem ou uma lista de booleanos."
      );
      return null;
    }

    return new TypeBoolean();
  }

  @Override
  public Type visitArithOpAddSub(IMLParser.ArithOpAddSubContext ctx) {
    
    //System.out.println("visitArithOpAddSub visitado com: " + ctx.getText());
    
    Type left = visit(ctx.expression(0));
    Type right = visit(ctx.expression(1));

    if (left == null || right == null) return null; // cancela op e propaga

    String op = ctx.op.getText();

    if (op.equals("+")) {
      //REVIEW concatenação -> so strings -> baseado no exemplo
      if (left.isString() && right.isString()) {
        return new TypeString();
      }

      // soma -> tem de ser numericos
      if (left.isNumeric() && right.isNumeric()) {
        return left.unify(right); // number ou percentage
      }

      ErrorHandling.printError(
        ctx,
        "Adição inválida entre tipos: " + left + " + " + right
      );
      return null;
    }

    if (op.equals("-")) {
      if (left.isNumeric() && right.isNumeric()) {
        return left.unify(right);
      }

      ErrorHandling.printError(
        ctx,
        "Subtração inválida entre tipos: " + left + " - " + right
      );
      return null;
    }

    // Defensivo - parser garante
    ErrorHandling.printError(ctx, "Operador desconhecido: " + op);
    return null;
  }

  // NOTE - exprs so aceitam tipo boleano
  //      - retorna tipo boleano

  @Override
  public Type visitBoolAndOrExpr(IMLParser.BoolAndOrExprContext ctx) {
    
    //System.out.println("visitBoolAndOrExpr visitado com: " + ctx.getText());
    
    Type left = visit(ctx.expression(0));
    Type right = visit(ctx.expression(1));

    if (left == null || right == null) return null;

    if (!left.isBoolean() || !right.isBoolean()) {
      ErrorHandling.printError(
        ctx,
        "Operadores 'and' e 'or' requerem operandos booleanos."
      );
      return null;
    }

    return new TypeBoolean();
  }

  @Override
  public Type visitNumberLiteral(IMLParser.NumberLiteralContext ctx) {
    System.out.println("NumberLiteral Visitado");
    return new TypeNumber();
  }

  @Override
  public Type visitPercentageLiteral(IMLParser.PercentageLiteralContext ctx) {
    System.out.println("PercentageLiteral Visitado");
    return new TypePercentage();
  }

  @Override
  public Type visitStringLiteral(IMLParser.StringLiteralContext ctx) {
    System.out.println("StringLiteral Visitado");
    return new TypeString();
  }
}
