//import java.util.Objects;

public class TypePercentage extends Type {

  public TypePercentage() {
    super("Percentage");
  }

  @Override
  public boolean isNumeric() {
    return true;
  }

  @Override
  public Type unify(Type other) {
    //REVIEW se Percentage + Number = Number ou Percentage (mesma duvida em TypeNumber)
    // Percentage + Number = Number
    if (other instanceof TypeNumber) {
      return new TypeNumber();
    }
    // Percentage + Percentage = Percentage
    if (other instanceof TypePercentage) {
      return this;
    }
    return super.unify(other);
  }
  /* @Override
  public boolean equals(Object obj) {
    return obj instanceof TypePercentage;
  } */

  /* @Override
  public int hashCode() {
    return Objects.hash(getClass());
  } */
}
