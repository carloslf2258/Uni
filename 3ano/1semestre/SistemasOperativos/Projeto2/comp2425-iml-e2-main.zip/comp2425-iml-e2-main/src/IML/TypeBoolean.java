public class TypeBoolean extends Type {

  public TypeBoolean() {
    super("Boolean");
  }

  @Override
  public boolean isBoolean() {
    return true;
  }
}
