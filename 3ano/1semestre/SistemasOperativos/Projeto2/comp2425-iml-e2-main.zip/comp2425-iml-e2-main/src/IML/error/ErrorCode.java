package error;

public enum ErrorCode {
  SUCCESS(0, "Execution successful"),
  INVALID_ARGUMENT(1, "Invalid argument"),
  FILE_NOT_FOUND(2, "File not found"),
  NOT_IMPLEMENTED(3, "Functionality not implemented"),
  SYNTAX_ERROR(4, "Syntax error"),
  SEMANTIC_ERROR(5, "Semantic error"),
  //REVIEW (deixar para o fim) talvez adicionar erros mais especificos da analise semântica
  UNKNOWN_ERROR(99, "Unknown error");

  public final int code;
  public final String description;

  ErrorCode(int code, String description) {
    this.code = code;
    this.description = description;
  }

  public static String getDescription(int code) {
    for (ErrorCode ec : values()) {
      if (ec.code == code) return ec.description;
    }
    return "Código de erro desconhecido";
  }
}
