import java.util.HashMap;
import java.util.Map;

public class SymbolTable {

  //REVIEW talvez estas excecoes no package error
  public static class SymbolException extends RuntimeException {

    public SymbolException(String msg) {
      super(msg);
    }
  }

  public static class RedefinitionException extends SymbolException {

    public RedefinitionException(String msg) {
      super(msg);
    }
  }

  public static class UndefinedVariableException extends SymbolException {

    public UndefinedVariableException(String msg) {
      super(msg);
    }
  }

  /**
   * - Scope representa os simbolos dentro de um bloco
   * - Assim variaveis declaradas dentro de um bloco sao visiveis apenas dentro desse bloco
   */
  private static class Scope {

    final Scope parent;
    final Map<String, Symbol> symbols = new HashMap<>();

    Scope(Scope parent) {
      this.parent = parent;
    }

    void define(Symbol sym) {
      if (symbols.containsKey(sym.getName())) {
        throw new RedefinitionException(
          "Symbol already declared in this scope: " + sym.getName()
        );
      }
      symbols.put(sym.getName(), sym);
    }

    Symbol resolve(String name) {
      Symbol s = symbols.get(name);
      if (s != null) return s;
      return parent != null ? parent.resolve(name) : null;
    }
  }

  private Scope current = new Scope(null);

  public void push() {
    current = new Scope(current);
  }

  public void pop() {
    if (current.parent == null) {
      throw new SymbolException("Cannot exit global scope");
    }
    current = current.parent;
  }

  public void define(Symbol sym) {
    current.define(sym);
  }

  public Symbol lookup(String name) {
    return current.resolve(name);
  }
}
