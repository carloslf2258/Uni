//import java.util.Objects;

public class TypeString extends Type{
    public TypeString() {
    super("String");
  }

  @Override
  public boolean isString() {
    return true;
  }

  /* @Override
  public boolean equals(Object obj) {
    return obj instanceof TypeString;
  } */

  /* @Override
  public int hashCode() {
    return Objects.hash(getClass());
  } */
}
