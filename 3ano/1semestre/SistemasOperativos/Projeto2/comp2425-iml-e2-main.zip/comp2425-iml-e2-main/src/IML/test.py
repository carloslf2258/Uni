import numpy as np
from skimage import morphology
from PIL import Image as PILImage
import sys
import os
if (sys.path[0].split('/')[0] != 'src'):
    sys.path.insert(0, os.path.abspath(os.path.join('..', '')))
from IIML.Types import ImagePGM, Number, String, Percentage, ListType
import IIML.IIMLMain as IIMLMain 

valores = [[5 , 10 ], [5 , 20 ], [6 , 30 ], [40 , 8 ]] 
primeiro = valores[0][1] 
segundo = valores[1][0] 
print("Primeiro valor: " + primeiro) 
print("Segundo valor: " + segundo)  