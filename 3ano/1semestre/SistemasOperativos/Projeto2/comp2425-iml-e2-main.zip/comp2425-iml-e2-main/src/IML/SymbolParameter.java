//NOTE[id=SymbolParameter] Apenas para casos avançados - para suportar funções
public class SymbolParameter {
  
}
