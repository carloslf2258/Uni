//NOTE[id=SymbolConstant] Apenas para casos avançados - para suportar constantes nomeadas, ex: PI = 3.1415…, E = 2.718…, NEWLINE = "\n"
public class SymbolConstant {
  
}
