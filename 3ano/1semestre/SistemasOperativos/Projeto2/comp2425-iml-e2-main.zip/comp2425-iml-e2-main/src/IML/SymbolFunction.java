//NOTE[id=SymbolFunction] Apenas para casos avançados - para suportar funções, ex: function foo(x: number, y: number) returns number { … }
public class SymbolFunction {
  
}
