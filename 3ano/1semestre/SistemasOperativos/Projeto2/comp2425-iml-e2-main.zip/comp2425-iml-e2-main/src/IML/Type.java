import java.util.Objects;

public abstract class Type {

  private final String name;

  protected Type(String name) {
    this.name = Objects.requireNonNull(name, "Type name cannot be null");
  }

  public String name() {
    return name;
  }

  /**
   * - Para verificar a atribuicaio de valores a variaveis.
   * - Por defaul so aceita igualdade.
   * @param other o tipo a verificar.
   * @return true se este tipo pode receber um valor do tipo `other`.
   */
  public boolean isAssignableFrom(Type other) {
    return this.equals(other);
  }

  /**
   * - Verifica se o tipo é numérico.
   * - Por omissão, tipos não são numéricos.
   * - Util para nao ter que fazer a confirmacao
   *   (por exemplo em operacoes aritmeticas) se algo é
   *   TypeNumber ou TypePercentage, basta confirmar se é numérico.
   * @return true se o tipo e numerico.
   */
  public boolean isNumeric() {
    return false;
  }

  /**
   * - Mesma funcao que isNumeric
   * - Redundante, mas fica para manter uma convencao clara
   *   em vez de adivinhar quando e para usar 'instaceof SomeType'
   *   esta por convencao usar 'isSomeType'
   */
  public boolean isBoolean() {
    return false;
  }

  /**
   * - Mesma funcao que isNumeric
   * - Redundante, mas fica para manter uma convencao clara
   *   em vez de adivinhar quando e para usar 'instaceof SomeType'
   *   esta por convencao usar 'isSomeType'
   */
  public boolean isImage() {
    return false;
  }

  /**
   * - Mesma funcao que isNumeric
   * - Redundante, mas fica para manter uma convencao clara
   *   em vez de adivinhar quando e para usar 'instaceof SomeType'
   *   esta por convencao usar 'isSomeType'
   */
  public boolean isList() {
    return false;
  }

  /**
   * - Mesma funcao que isNumeric
   * - Redundante, mas fica para manter uma convencao clara
   *   em vez de adivinhar quando e para usar 'instaceof SomeType'
   *   esta por convencao usar 'isSomeType'
   */
  public boolean isString() {
    return false;
  }

  /**
   * - Least‐upper‐bound (join) de dois tipos, e.g. para ramos de um if.
   * - Por omissao so unifica tipos identicos.
   * @throws TypeException se não houver unificação possível.
   */
  public Type unify(Type other) {
    if (this.equals(other)) {
      return this;
    }
    throw new TypeException("Cannot unify " + this + " with " + other);
  }

  /**
   * - Verifica se os 2 obj sao da mesma class
   * - Subclasses paramétricas devem sobrepor _equals
   * @return true se.
   */
  @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null) return false;
    if (getClass() != obj.getClass()) return false;
    return _equals((Type) obj);
  }

  /**
   * - Sobrescrever se o tipo tiver parâmetros (e.g. ListType).
   */
  protected boolean _equals(Type other) {
    return true;
  }

  /**
   * - Garante que t1 == t2 ⇒ hash(t1) == hash(t2)
   * - Usa só a classe e em vez do nome, pois instancias
   *   de mesma classe devem ser iguais
   *   (ListType cuidará do elem_type em seu próprio hashCode).
   * - Util para usar no HashMap
   * @return
   */
  @Override
  public int hashCode() {
    return Objects.hash(getClass());
  }

  @Override
  public String toString() {
    return name;
  }

  /**
   * Exceção lançada em erros de tipagem.
   */
  public static class TypeException extends RuntimeException {

    public TypeException(String message) {
      super(message);
    }
  }
}
