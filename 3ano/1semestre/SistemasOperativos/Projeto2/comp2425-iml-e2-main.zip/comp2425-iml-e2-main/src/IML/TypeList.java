import java.util.Objects;

public class TypeList extends Type {

  private final Type elemType;

  public TypeList(Type elemType) {
    super("List");
    this.elemType = Objects.requireNonNull(elemType);
  }

  @Override
  public boolean isList() {
    return true;
  }

  public Type elemType() {
    return elemType;
  }

  /**
   * - Para garantir que List[self] e List[other] sejam unificaveis
   */
  @Override
  protected boolean _equals(Type other) {
    return elemType.equals(((TypeList) other).elemType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(getClass(), elemType);
  }

  /**
   * - Ambos tem que ser List e do mesmo tipo de elemento
   */
  @Override
  public boolean isAssignableFrom(Type other) {
    return (
      other instanceof TypeList &&
      elemType.isAssignableFrom(((TypeList) other).elemType)
    );
  }

  @Override
  public Type unify(Type other) {
    if (other instanceof TypeList) {
      Type inner = elemType.unify(((TypeList) other).elemType);
      return new TypeList(inner);
    }
    return super.unify(other);// para ir para o erro default
  }

  /**
   * - Da print no formato python
   */
  @Override
  public String toString() {
    return "List[" + elemType + "]";
  }
}
