public class SymbolVariable extends Symbol{
  public SymbolVariable(String name, Type type) {
    super(name, type);
}
}
