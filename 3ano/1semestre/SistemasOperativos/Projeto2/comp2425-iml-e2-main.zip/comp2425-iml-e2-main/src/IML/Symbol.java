import java.util.Objects;

public abstract class Symbol {
    private final String name;
    private final Type type;
    public Symbol(String name, Type type) {
        this.name = Objects.requireNonNull(name, "Symbol name cannot be null");
        this.type = Objects.requireNonNull(type, "Symbol type cannot be null");
    }
    public String getName() {
        return name;
    }

    public Type getType() {
        return type;
    }

    @Override
    public String toString() {
        return String.format("<Symbol name='%s' type=%s>", name, type);
    }
}
