public class TypeImage extends Type {

  public TypeImage() {
    super("Image");
  }

  @Override
  public boolean isImage() {
    return true;
  }
}
