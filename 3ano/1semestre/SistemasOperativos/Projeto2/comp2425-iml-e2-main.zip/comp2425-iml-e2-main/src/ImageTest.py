import numpy as np
from ImagePGM import ImagePGM
from Types import Percentage, Number, String
from ImagePGM import ImagePGM


# Funções auxiliares para conversão de tipos
def number(value):
    return Number(value)

def string(value):
    return String(value)


# min-01.iiml
#- Criação de imagens.
#- Colocação de formas (círculo, retângulo, cruz).
def example_min_01_iiml():

    l = int(input("Size: "))

    img = ImagePGM(np.zeros((int(l), int(l))))
    r = int(input("Radius: "))
    
    img.draw_circle(int(l / 2), int(l / 2), int(r), intensity=1)
    img.store("images/circle2.pgm")

    #img.draw_cross(int(l / 2), int(l / 2), int(r), intensity=1)
    #img.store("images/cross1.pgm")
    #img.draw_rect(int(l / 2), int(l / 2), int(r), int(r), intensity=1)
    #img.store("images/rect4.pgm")
    #return img

# Exemplo min-01.iml
def example_min_01(input_path, output_path):
    image = ImagePGM.load(input_path)

    print("Image metadata:")
    print(image.get_metadata())

    print("Image draw:")

    image.draw()

    image.store(output_path)

# Exemplo min-02.iml
def example_min_02():

    i0 = ImagePGM.load("images/sample00.pgm")
    i1 = ImagePGM.load("images/sample01.pgm")

    # Ajusta escala horizontal
    i0cols = i0.columns()
    i1cols = i1.columns()
    if i0cols != i1cols:
        i0 = i0.scale_horizontal(i1cols / i0cols)

    # Ajusta escala vertical
    i0rows = i0.rows()
    i1rows = i1.rows()
    if i0rows != i1rows:
        i0 = i0.scale_vertical(i1rows / i0rows)

    # Mistura imagens
    r =  i0 *  Percentage("30%") + i1 * Percentage("70%")

    r.store("images/blend2.pgm")

# Exemplo min-03.iml
def example_min_03():
    # Carrega a imagem principal
    i = ImagePGM.load("images/sample03.pgm")

    # kernel_path = input("Path: ")
    kernel = ImagePGM.load("images/kernel00.pgm")

    # abertura seguida de fechamento
    r = i.open(kernel).close(kernel)

    r.store("images/clean2.pgm")

# Exemplo des-01.iml
def des_01():

    i = ImagePGM.load("images/sample00.pgm")
    k = ImagePGM.load("images/kernel00.pgm")

    r = i.open(k).close(k)

    if r.any_pixel(r.data > 0):
        print("Image contains at least one object.")
    else:
        print("Image does not contain any object.")

    r.draw()
    r.store("images/resultDemo.pgm")


# Exemplos de operações de flip
# - Operações de flip (vertical, horizontal, ambos).
def example_flip_operations():

    i = ImagePGM.load("images/sample00.pgm")

    flipVertical = i.flip_vertical()
    flipVertical.store("images/flipVertical.pgm")

    flipHorizontal = i.flip_horizontal()
    flipHorizontal.store("images/flipHorizontal.pgm")

    flipBoth = i.flip_both()
    flipBoth.store("images/flipBoth.pgm")

# Exemplos de operações aritméticas
# Exception: Images must be the same size for arithmetic operations.
def arithmetic_operations():

    i0 = ImagePGM(np.zeros((10, 10)))
    i1 = ImagePGM(np.ones((10, 10)))
    result_add = i0 + i1
    assert np.all(result_add.data <= 1), "Error on addition operation."
    assert np.all(result_add.data >= 0), "Error on addition operation."

    result_sub = i1 - i0
    assert np.all(result_sub.data >= 0), "Error on subtraction operation."
    assert np.all(result_sub.data <= 1), "Error on subtraction operation."

    result_mul = i0 * 0.5
    assert np.all(result_mul.data <= 1), "Error on multiplication operation."
    assert np.all(result_mul.data >= 0), "Error on multiplication operation."

    result_div = i1 / 2
    assert np.all(result_div.data <= 1), "Error on division operation."
    assert np.all(result_div.data >= 0), "Error on division operation."

    # Teste de operações aritméticas com imagens e Number
    i2 = ImagePGM(np.ones((10, 10)))
    n = Number(0.5)
    n2 = Number(5)

    result_add = i2 + n
    result_add2 = i2 + n2

    assert np.all(result_add.data <= 1), "Error on addition operation with Number."
    assert np.all(result_add.data >= 0), "Error on addition operation with Number."
    assert np.all(result_add2.data <= 1), "Error on addition operation with Number."
    assert np.all(result_add2.data >= 0), "Error on addition operation with Number."
    
    result_sub = i2 - n
    result_sub2 = i2 - n2

    assert np.all(result_sub.data >= 0), "Error on subtraction operation with Number."
    assert np.all(result_sub.data <= 1), "Error on subtraction operation with Number."
    assert np.all(result_sub2.data >= 0), "Error on subtraction operation with Number."
    assert np.all(result_sub2.data <= 1), "Error on subtraction operation with Number."
    
    result_mul = i2 * n
    result_mul2 = i2 * n2

    assert np.all(result_mul.data <= 1), "Error on multiplication operation with Number."
    assert np.all(result_mul.data >= 0), "Error on multiplication operation with Number."
    assert np.all(result_mul2.data <= 1), "Error on multiplication operation with Number."
    assert np.all(result_mul2.data >= 0), "Error on multiplication operation with Number."
    
    result_div = i2 / n
    result_div2 = i2 / n2

    assert np.all(result_div.data <= 1), "Error on division operation with Number."
    assert np.all(result_div.data >= 0), "Error on division operation with Number."
    assert np.all(result_div2.data <= 1), "Error on division operation with Number."
    assert np.all(result_div2.data >= 0), "Error on division operation with Number."
    

    # Teste de operações aritméticas com imagens e Percentage
    p = Percentage("50%")
    result_add = i2 + p

    assert np.all(result_add.data <= 1), "Error on addition operation with Percentage."
    assert np.all(result_add.data >= 0), "Error on addition operation with Percentage."
    result_sub = i2 - p

    assert np.all(result_sub.data >= 0), "Error on subtraction operation with Percentage."
    assert np.all(result_sub.data <= 1), "Error on subtraction operation with Percentage."
    result_mul = i2 * p

    assert np.all(result_mul.data <= 1), "Error on multiplication operation with Percentage."
    assert np.all(result_mul.data >= 0), "Error on multiplication operation with Percentage."
    result_div = i2 / p

    assert np.all(result_div.data <= 1), "Error on division operation with Percentage."
    assert np.all(result_div.data >= 0), "Error on division operation with Percentage."

    # Teste operações unárias
    result_invert = i2.invert()
    assert np.all(result_invert.data <= 1), "Error on invert operation."
    assert np.all(result_invert.data >= 0), "Error on invert operation."
    result_invert.store("images/inverted.pgm")

# Exemplos de operações morfológicas
# - Erosão, dilatação, abertura e fechamento, top-hat e black-hat.
def morphological_operations():

    img = ImagePGM.load("images/sample00.pgm")
    kernel = ImagePGM.load("images/kernel00.pgm")

    # Erosão
    eroded = img.erode(kernel)
    assert eroded.data.shape == img.data.shape, "Error in erosion operation."
    eroded.store("images/eroded.pgm")

    # Dilatação
    dilated = img.dilate(kernel)
    assert dilated.data.shape == img.data.shape, "Error in dilation operation."
    dilated.store("images/dilated.pgm")

    # Abertura
    opened = img.open(kernel)
    assert opened.data.shape == img.data.shape, "Error in opening operation."
    opened.store("images/opened.pgm")

    # Fechamento
    closed = img.close(kernel)
    assert closed.data.shape == img.data.shape, "Error in closing operation."
    closed.store("images/closed.pgm")

    # Top-hat
    top_hat = img.top_hat(kernel)
    assert top_hat.data.shape == img.data.shape, "Error in top-hat operation."
    top_hat.store("images/top_hat.pgm")

    # Black-hat
    black_hat = img.black_hat(kernel)
    assert black_hat.data.shape == img.data.shape, "Error in black-hat operation."
    black_hat.store("images/black_hat.pgm")



if __name__ == "__main__":
    arithmetic_operations()