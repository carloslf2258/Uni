#!/bin/bash
# compile.sh

# Cores
GREEN="\033[0;32m"
RED="\033[0;31m"
NC="\033[0m" # No Color

if [ "$#" -lt 1 ]; then
  echo -e "${RED}Uso: ./compile.sh <ficheiro1.iml> [ficheiro2...]${NC}"
  exit 1
fi

# Verificar ficheiros e armazenar caminhos absolutos antes de mudar diretório
declare -a INPUT_FILES=()

for arg in "$@"; do
  # Usar caminho absoluto
  FILE_PATH=$(realpath "$arg" 2>/dev/null)
  if [ ! -f "$FILE_PATH" ]; then
    echo -e "${RED}[✖] Ficheiro não encontrado: $arg${NC}"
  else
    INPUT_FILES+=("$FILE_PATH")
  fi
done

if [ "${#INPUT_FILES[@]}" -eq 0 ]; then
  echo -e "${RED}[✖] Nenhum ficheiro válido para compilar${NC}"
  exit 1
fi

# Ir para diretório IML
pushd IML > /dev/null || { echo -e "${RED}[✖] Falha ao entrar em IML${NC}"; exit 1; }

for INPUT in "${INPUT_FILES[@]}"; do
  OUTNAME=$(basename "$INPUT" | cut -d. -f1)
  OUTDIR="../../examples/generated"
  OUTFILE="${OUTDIR}/${OUTNAME}.py"

  mkdir -p "$OUTDIR"

  echo -e "🛠️  A compilar $(basename "$INPUT") → ${OUTFILE}"
  java IMLMain "$INPUT" "$OUTFILE"

  if [ $? -eq 0 ]; then
    echo -e "${GREEN}[✔] Código gerado: $OUTFILE${NC}"
  else
    echo -e "${RED}[✖] Erro ao compilar: $(basename "$INPUT")${NC}"
    rm -f "$OUTFILE"
  fi
done

popd > /dev/null
