# Componentes do Projeto IML

---

## 1. Analisador Sintático (Parser)

**Função:**  
Lê o código-fonte IML (ou IIML), verifica se está sintaticamente correto e constrói uma árvore sintática abstrata (AST).

**Como funciona:**
- Usa gramáticas ANTLR (`IML.g4`, `IIML.g4`) para definir as regras da linguagem.
- O ANTLR gera código (Java ou Python) que reconhece a estrutura dos programas.
- O parser identifica erros de sintaxe e organiza o código em estruturas compreensíveis para as fases seguintes.

**Ficheiros:**
- `IML.g4`, `IIML.g4` (gramáticas)
- Ficheiros `.java` ou `.py` gerados pelo ANTLR

---

## 2. Compilador (Visitor de Geração de Código)

**Função:**  
Percorre a AST criada pelo parser e gera código Python equivalente ao programa IML original.

**Como funciona:**
- Implementa um visitor (ex: `Compiler.java`) que visita cada nó da AST.
- Para cada construção da linguagem (ex: atribuição, `if`, `for`), gera a instrução Python correspondente.
- Usa templates (ex: `python.stg`) para facilitar a geração de código.
- O resultado é um ficheiro `.py` pronto a executar.

**Ficheiros:**
- `Compiler.java` (visitor)
- `IMLMain.java` (main para compilar)
- `python.stg` (templates de código Python)

---

## 3. Interpretador para Linguagem Secundária (IIML)

**Função:**  
Executa diretamente programas escritos na linguagem IIML (um subconjunto mais simples da IML), sem gerar código intermediário.

**Como funciona:**
- Tem a sua própria gramática (`IIML.g4`) e parser.
- Implementa um visitor ou intérprete (em Python) que executa as ações à medida que percorre a AST.
- Permite testar rapidamente funcionalidades básicas (ex: criação e manipulação de imagens) sem passar pela geração de código Python.

**Ficheiros:**
- `IIML.g4` (gramática)
- Visitor/intérprete Python (ex: `Interpreter.py` ou similar)