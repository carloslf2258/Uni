#!/bin/bash
# build.sh

#Resumo:
#Entra em IML, faz build de Java
#Entra em IIML, faz build de python

#IML
echo -e "🚀 Build Primary Lang: IML"
pushd IML > /dev/null || { echo "[✖] Falha ao entrar no diretório IML"; exit 1; }

# Limpar ficheiros antigos
echo -e "🧹 A limpar ficheiros antigos de IML..."
rm -f *.class *.tokens *.interp

# Gerar código Java a partir da gramática IML.g4
echo -e "⚙️  A gerar código a partir de IML.g4..."
antlr4 IML.g4 -visitor -no-listener
echo -e "[✔] IML.g4 compilado com sucesso"

# Compilar Java
echo -e "🏗️  A compilar código Java..."
if antlr4-javac *.java; then
  echo -e "[✔] Código Java compilado com sucesso"
else
  echo -e "[✖] Erro ao compilar Java"; popd > /dev/null; exit 1
fi

popd > /dev/null || exit

#IIML
echo -e "🚀 Build Secondary Lang: IIML"
pushd IIML > /dev/null || { echo "[✖] Falha ao entrar no diretório IIML"; exit 1; }

# Limpar ficheiros antigos
echo -e "🧹 A limpar ficheiros antigos de IIML..."
rm -f *.tokens *.interp

# Compilar Python
echo -e "⚙️  A gerar código Python a partir de IIML.g4..."
if antlr4-build -python; then
  echo -e "[✔] IIML.g4 compilado com sucesso"
else
  echo -e "[✖] Erro ao compilar IIML.g4"; popd > /dev/null; exit 1
fi

popd > /dev/null || exit

echo -e "✅ Build concluído com sucesso!"
