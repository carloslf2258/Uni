from ImagePGM import ImagePGM
from Types import Percentage, Number, String

def testImagePGM():

    img1 = ImagePGM.load("images/sample00.pgm")
    img2 = ImagePGM.load("images/sample01.pgm")

    result_add = img1 + img2
    result_add.store("images/result_add2.pgm")

    # Subtração
    result_sub = img1 - img2
    result_sub.store("images/result_sub2.pgm")

    result_mul = img1 * img2
    result_mul.store("images/result_mul2.pgm")

    result_div = img1 / img2
    result_div.store("images/result_div2.pgm")

    # Teste de operações aritméticas com Percentages
    num = Percentage("50%")
    result_num_add = img1 + num
    result_num_add.store("images/result_num_add2.pgm")
    result_num_sub = img1 - num
    result_num_sub.store("images/result_num_sub2.pgm")
    result_num_mul = img1 * num
    result_num_mul.store("images/result_num_mul2.pgm")
    result_num_div = img1 / num
    result_num_div.store("images/result_num_div2.pgm")
    # Teste de operações aritméticas com números
    num1 = 10


# number (+|-|*|/) number = number
def testNumberNumber():
    num1 = Number(10)
    num2 = Number(20)
    result_num_add = num1 + num2
    result_num_sub = num1 - num2
    result_num_mul = num1 * num2
    result_num_div = num1 / num2

    print(f"Number addition: {result_num_add} and isinstance: {isinstance(result_num_add, Number)}")
    print(f"Number subtraction: {result_num_sub} and isinstance: {isinstance(result_num_sub, Number)}")
    print(f"Number multiplication: {result_num_mul} and isinstance: {isinstance(result_num_mul, Number)}")
    print(f"Number division: {result_num_div} and isinstance: {isinstance(result_num_div, Number)}")
# number (<|>|<=|>=|==|!=) number = boolean (TRUE|FALSE)
def testNumberComparison():
    num1 = Number(10)
    num2 = Number(20)
    result_num_eq = num1 == num2
    result_num_neq = num1 != num2
    result_num_lt = num1 < num2
    result_num_gt = num1 > num2
    result_num_lte = num1 <= num2
    result_num_gte = num1 >= num2

    print(f"Number equal: {result_num_eq} and isinstance: {isinstance(result_num_eq, bool)}")
    print(f"Number not equal: {result_num_neq} and isinstance: {isinstance(result_num_neq, bool)}")
    print(f"Number less than: {result_num_lt} and isinstance: {isinstance(result_num_lt, bool)}")
    print(f"Number greater than: {result_num_gt} and isinstance: {isinstance(result_num_gt, bool)}")
    print(f"Number less than or equal to: {result_num_lte} and isinstance: {isinstance(result_num_lte, bool)}")
    print(f"Number greater than or equal to: {result_num_gte} and isinstance: {isinstance(result_num_gte, bool)}")

# number (+|-|*|/) percentage = number
def testNumberPercentage():
    num1 = Number(7)
    num2 = Percentage("20%")
    result_num_add = num1 + num2
    result_num_sub = num1 - num2
    result_num_mul = num1 * num2
    result_num_div = num1 / num2
    print(f"Number addition: {result_num_add} and isinstance: {isinstance(result_num_add, Number)}")
    print(f"Number subtraction: {result_num_sub} and isinstance: {isinstance(result_num_sub, Number)}")
    print(f"Number multiplication: {result_num_mul} and isinstance: {isinstance(result_num_mul, Number)}")
    print(f"Number division: {result_num_div} and isinstance: {isinstance(result_num_div, Number)}")

# percentage (+|-|*|/) number = number
def testPercentageNumber():
    num1 = Percentage("20%")
    num2 = Number(7)
    result_num_add = num1 + num2
    result_num_sub = num1 - num2
    result_num_mul = num1 * num2
    result_num_div = num1 / num2
    print(f"Percentage addition: {result_num_add} and isinstance: {isinstance(result_num_add, Number)}")
    print(f"Percentage subtraction: {result_num_sub} and isinstance: {isinstance(result_num_sub, Number)}")
    print(f"Percentage multiplication: {result_num_mul} and isinstance: {isinstance(result_num_mul, Number)}")
    print(f"Percentage division: {result_num_div} and isinstance: {isinstance(result_num_div, Number)}")



# percentage (+|-|*|/) percentage = percentage
def testPercentagePercentage():
    num1 = Percentage("50%")
    num2 = Percentage("20%")
    result_num_add = num1 + num2
    result_num_sub = num1 - num2
    result_num_mul = num1 * num2
    result_num_div = num1 / num2
    print(f"Percentage addition: {result_num_add} and isinstance: {isinstance(result_num_add, Percentage)}")
    print(f"Percentage subtraction: {result_num_sub} and isinstance: {isinstance(result_num_sub, Percentage)}")
    print(f"Percentage multiplication: {result_num_mul} and isinstance: {isinstance(result_num_mul, Percentage)}")
    print(f"Percentage division: {result_num_div} and isinstance: {isinstance(result_num_div, Percentage)}")

# percentage (<|>|<=|>=|==|!=) percentage = boolean (TRUE|FALSE)
def testPercentageComparison():
    num1 = Percentage("50%")
    num2 = Percentage("20%")
    result_num_eq = num1 == num2
    result_num_neq = num1 != num2
    result_num_lt = num1 < num2
    result_num_gt = num1 > num2
    result_num_lte = num1 <= num2
    result_num_gte = num1 >= num2

    print(f"Percentage equal: {result_num_eq} and isinstance: {isinstance(result_num_eq, bool)}")
    print(f"Percentage not equal: {result_num_neq} and isinstance: {isinstance(result_num_neq, bool)}")
    print(f"Percentage less than: {result_num_lt} and isinstance: {isinstance(result_num_lt, bool)}")
    print(f"Percentage greater than: {result_num_gt} and isinstance: {isinstance(result_num_gt, bool)}")
    print(f"Percentage less than or equal to: {result_num_lte} and isinstance: {isinstance(result_num_lte, bool)}")
    print(f"Percentage greater than or equal to: {result_num_gte} and isinstance: {isinstance(result_num_gte, bool)}")


# String + String = String
def testString():
    str1 = String("string")
    str2 = String("string2")
    n = 2
    result_num_add = str1 + str2
    result_num_mul = str1 * n

    print(f"String addition: {result_num_add} and isinstance: {isinstance(result_num_add, String)}")
    print(f"String multiplication: {result_num_mul} and isinstance: {isinstance(result_num_mul, String)}")

# String (<|>|<=|>=|==|!=) String = boolean (TRUE|FALSE)
def testStringComparison():
    str1 = String("string")
    str2 = String("string2")
    result_num_eq = str1 == str2
    result_num_neq = str1 != str2
    result_num_lt = str1 < str2
    result_num_gt = str1 > str2
    result_num_lte = str1 <= str2
    result_num_gte = str1 >= str2

    print(f"String equal: {result_num_eq} and isinstance: {isinstance(result_num_eq, bool)}")
    print(f"String not equal: {result_num_neq} and isinstance: {isinstance(result_num_neq, bool)}")
    print(f"String less than: {result_num_lt} and isinstance: {isinstance(result_num_lt, bool)}")
    print(f"String greater than: {result_num_gt} and isinstance: {isinstance(result_num_gt, bool)}")
    print(f"String less than or equal to: {result_num_lte} and isinstance: {isinstance(result_num_lte, bool)}")
    print(f"String greater than or equal to: {result_num_gte} and isinstance: {isinstance(result_num_gte, bool)}")

if __name__ == "__main__":
    testNumberComparison()
