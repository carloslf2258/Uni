#!/bin/bash

SRC_DIR="../src"
TEST_DIR="iml"
OUT_DIR="out"

SUCCESS=0
FAIL=0

ORIG_DIR="$(pwd)"

mkdir -p "$OUT_DIR"

for file in "$TEST_DIR"/*.iml; do
  if [ -f "$file" ]; then
    echo "=============================="
    echo "Compilando: $file"
    # Obter caminho absoluto do ficheiro de teste
    ABS_FILE="$(realpath "$file")"
    # Ir para o diretório do script compile.sh
    pushd "$SRC_DIR" > /dev/null
    ./compile.sh "$ABS_FILE"
    RESULT=$?
    # Supondo que o código python gerado tem o mesmo nome do ficheiro .iml mas com .py
    GEN_PY="$(basename "$file" .iml).py"
    GEN_PY_PATH="../examples/generated/$GEN_PY"
    # Voltar ao diretório original
    popd > /dev/null
    if [ $RESULT -eq 0 ]; then
      # Comparar o código python gerado com o ficheiro esperado
      if [ -f "$GEN_PY_PATH" ]; then
        BASE_EXPECTED="${file%.iml}.expected"
        if [ -f "$BASE_EXPECTED" ]; then
          diff -u -B -w "$BASE_EXPECTED" "$GEN_PY_PATH" > "${file}.diff"
          if [ $? -eq 0 ]; then
            echo "Teste PASSED"
            SUCCESS=$((SUCCESS+1))
            rm -f "${file}.diff"
          else
            echo "Teste FAILED (código Python diferente do esperado)"
            FAIL=$((FAIL+1))
            echo "Veja ${file}.diff para detalhes."
          fi
        else
          echo "FALHA: ficheiro esperado '${BASE_EXPECTED}' não encontrado."
          FAIL=$((FAIL+1))
        fi
        # Executar o ficheiro Python gerado usando run.sh e guardar o output em out/
        OUT_FILE="$OUT_DIR/$(basename "$file" .iml).out"
        echo "Executando o script Python (output em $OUT_FILE):"
        "$SRC_DIR/run.sh" "$GEN_PY_PATH" > "$OUT_FILE" 2>&1
      else
        echo "Erro: código python '$GEN_PY' não encontrado."
        FAIL=$((FAIL+1))
      fi
    else
      echo "Compilação falhou."
      FAIL=$((FAIL+1))
    fi
    echo
  fi
done

echo "=============================="
echo "Testes concluídos: $SUCCESS sucesso(s), $FAIL falha(s)"


