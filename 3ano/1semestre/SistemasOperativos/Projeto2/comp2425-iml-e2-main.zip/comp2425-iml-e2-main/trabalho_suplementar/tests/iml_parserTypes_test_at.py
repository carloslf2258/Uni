# iml_parserTypes_test.py

#!: TEST ANTIGO PARA A GRAMATICA COM ATRIBUICOES

import pytest
from antlr4 import InputStream, CommonTokenStream
from IMLLexer import IMLLexer
from IMLParser import IMLParser
from src_python.iml_types import (
    ImageType, NumberType, StringType,
    PercentageType, ListType
)

def parse_type(text: str):
    """
    Lê apenas o fragmento `text` como input na regra 'type'
    do teu parser e devolve o atributo .res definido pelo
    action Python no grammar.
    """
    # cria lexer e token stream
    lexer  = IMLLexer(InputStream(text))
    tokens = CommonTokenStream(lexer)
    parser = IMLParser(tokens)
    # chama diretamente a regra 'type'
    ctx = parser.type_()
    return ctx.res

@pytest.mark.parametrize("txt,cls", [
    ("image",      ImageType),
    ("number",     NumberType),
    ("string",     StringType),
    ("percentage", PercentageType),
])
def test_basic_types(txt, cls):
    t = parse_type(txt)
    assert isinstance(t, cls)

def test_list_of_number():
    t = parse_type("list of number")
    assert isinstance(t, ListType)
    # e que o elemento seja NumberType
    assert isinstance(t.elem_type, NumberType)

def test_nested_list():
    t = parse_type("list of list of percentage")
    assert isinstance(t, ListType)
    inner = t.elem_type
    assert isinstance(inner, ListType)
    assert isinstance(inner.elem_type, PercentageType)
