# iml_types_test.py

import pytest
from src_python.iml_types import (
    ImageType, NumberType, StringType, PercentageType, ListType
)

@pytest.mark.parametrize("cls, repr_txt", [
    (ImageType,      "Image"),
    (NumberType,     "Number"),
    (StringType,     "String"),
    (PercentageType, "Percentage"),
])
def test_basic_repr_and_eq(cls, repr_txt):
    t1 = cls()
    t2 = cls()
    assert repr(t1) == repr_txt
    # igualdade estrutural
    assert t1 == t2
    # diferentes classes não são iguais
    other = NumberType() if cls is not NumberType else ImageType()
    assert not (t1 == other)

def test_list_type_repr_eq():
    lt1 = ListType(NumberType())
    lt2 = ListType(NumberType())
    lt3 = ListType(PercentageType())
    assert repr(lt1) == "List[Number]"
    assert lt1 == lt2
    assert not (lt1 == lt3)

