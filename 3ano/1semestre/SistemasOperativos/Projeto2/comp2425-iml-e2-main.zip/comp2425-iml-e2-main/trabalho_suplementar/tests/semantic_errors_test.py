# tests/semantic_errors_test.py
import pytest
from tests.utils import parse_iml
from src_python.iml_semanticAnalyzer import iml_semanticAnalyzer, SemanticError

# TODO organizar por seccoes
# SECTION[epic=semantic_errors,seq=1]
def test_redefinition_error():
    src = """
      number x is 1
      number x is 2
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Symbol already declared in this scope: " in str(ei.value)

def test_undefined_variable():
    src = "x is 5"
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(Exception) as ei:
        sem.visit(tree)
    # pode serUndefinedVariableError ou SemanticError dependendo de como você levantou
    assert "Variable not declared" in str(ei.value)

def test_type_mismatch():
    src = """
      number x is 1
      x is "foo"
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Cannot assign" in str(ei.value)

def test_load_img_redefinition_error():
    src = """
    image i0 is load from "image.pgm"
    image i0 is load from "other.pgm"
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Symbol already declared" in str(ei.value)

def test_create_img_type_error():
    src = """
        image size 1 by "1" background 0
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Parameter 2 of image creation must be Number" in str(ei.value)

def test_until_condition_type_error():
    src = """
        number n is 10
        until n do
            number x is 5
        done
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Condition of until must be Boolean" in str(ei.value)

def test_place_shape_type_error():
    src = """
        number r is 5
        place circle radius r at "1/2" 1/2 with intensity 1
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Parameter 2 of shape placement must be Number" in str(ei.value)

def test_draw_img_type_error():
    src = """
        number x is 42
        draw x
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Can only draw images" in str(ei.value)

def test_draw_img_undeclared_variable():
    src = """
        draw i
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    # por enquanto continua a aceitar qualquer exceção
    with pytest.raises(Exception) as ei:
        sem.visit(tree)
    assert "Variable not declared" in str(ei.value)

def test_output_undeclared_var():
    src = """
        output x
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(Exception) as ei:
        sem.visit(tree)
    assert "Variable not declared" in str(ei.value)

def test_append_type_error():
    src = """
        list of number xs is []
        xs append "text"
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Cannot append" in str(ei.value)

def test_store_non_image():
    src = """
        number x is 10
        x store into "copy.pgm"
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Cannot store non-image variable" in str(ei.value)

def test_negate_string_error():
    src = """
        string s is -"word"
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Cannot apply '-' to" in str(ei.value)

def test_not_expr_type_error():
    src = """
        not 5
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "'not' operator requires Boolean" in str(ei.value)

def test_pixel_op_type_error():
    src = """
        image img is load from "images/sample.pgm"
        img .+ "abc"
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Pixel operation requires number or percentage on the right" in str(ei.value)

def test_scale_op_type_error():
    src = """
        image i is load from "images/sample.pgm"
        i -* "word"
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Scale operation requires number or percentage on the right" in str(ei.value)

def test_scale_op_invalid_left_operand():
    src = """
        string word is "image"
        word -* 0.5
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Scale operation requires image on the left" in str(ei.value)

def test_muldiv_type_error():
    src = """
        number x is "abc" * 2
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(TypeError) as ei:
        sem.visit(tree)
    assert "cannot unify" in str(ei.value)

def test_addsub_type_error():
    src = """
        number x is "hello" + true
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(TypeError) as ei:
        sem.visit(tree)
    assert "cannot unify" in str(ei.value)

def test_relational_expr_type_error():
    src = """
        number x is 10
        x == 50%
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Cannot compare" in str(ei.value)

def test_logical_expr_type_error():
    src = """
        number x is 56
        (6 > 5) or x
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Logical operators require Booleans" in str(ei.value)

def test_morph_op_left_not_image():
    src = """
        number i is 5
        image k is load from "img.pgm"
        i erode by k
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Morphological operation requires image on the left" in str(ei.value)

def test_morph_op_right_invalid_type():
    src = """
        image i is load from "img.pgm"
        string k is "invalid"
        i dilate by k
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Morphological operation requires list of list of numbers or image on the right" in str(ei.value)

def test_any_pixel_expr_wrong_type():
    src = """
        number x is 10
        any pixel x > 0
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "'any pixel' expression requires an image or list of booleans" in str(ei.value)

def test_all_pixel_expr_wrong_type():
    src = """
        number x is 10
        all pixel x
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "'all pixel' expression requires an image or list of booleans" in str(ei.value)

def test_count_pixel_expr_wrong_left_type():
    src = """
        image i is load from "images/sample.pgm"
        number n is count pixel "bright" in i
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "'count pixel' requires a number or percentage on the left" in str(ei.value)

def test_count_pixel_expr_wrong_right_type():
    src = """
        number x is 1
        number n is count pixel 1 in x
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "'count pixel' requires an image on the right" in str(ei.value)

# img não declarada
def test_rcol_expr_undeclared_variable():
    src = """
        number n is rows of img
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(Exception) as ei:
        sem.visit(tree)
    assert "Variable not declared" in str(ei.value)

def test_rcol_expr_wrong_type():
    src = """
        number x is 10
        number n is columns of x
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "'rows of' or 'columns of' requires image" in str(ei.value)

def test_var_expr_undeclared():
    src = """
        y
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(Exception) as ei:
        sem.visit(tree)
    assert "Variable not declared1" in str(ei.value)

def test_number_cast_from_boolean_error():
    src = """
        number n is number(true)
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Cannot cast Boolean to number" in str(ei.value)

def test_number_cast_from_percentage_error():
    src = """
        number n is number(42%)
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Cannot cast Percentage to number" in str(ei.value)

# SECTION IfStt

def test_if_non_boolean_condition():
    src = """
    number n is 5
    if n then
        number x is 1
    done
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Condition of if must be Boolean" in str(ei.value)


def test_if_undeclared_in_then():
    src = """
    boolean b is true
    if b then
        x is 1
    done
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(Exception) as ei:
        sem.visit(tree)
    assert "Variable not declared" in str(ei.value)


def test_if_redefinition_in_same_block():
    src = """
    boolean b is true
    if b then
        number x is 1
        number x is 2
    done
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Symbol already declared in this scope" in str(ei.value)


def test_if_local_scope_not_visible_outside():
    src = """
    boolean b is true
    if b then
        number x is 1
    done
    x is 2
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    with pytest.raises(Exception) as ei:
        sem.visit(tree)
    assert "Variable not declared" in str(ei.value)


def test_if_else_type_mismatch():
    src = """
    boolean b is true
    number x is 0
    if b then
        x is 1
    else
        x is "foo"
    done
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    # mismatch no ramo else
    with pytest.raises(SemanticError) as ei:
        sem.visit(tree)
    assert "Cannot assign" in str(ei.value)


# !SECTION
# !SECTION
