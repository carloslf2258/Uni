# tests/utils.py
import pytest
from antlr4 import InputStream, CommonTokenStream
from IMLLexer import IMLLexer
from IMLParser import IMLParser

def parse_iml(src: str):
    """
    Recebe uma string com o programa IML, devolve o ctx.program() ou dispara
    se houver erro sintático.
    """
    char_stream = InputStream(src)
    lexer = IMLLexer(char_stream)
    tokens = CommonTokenStream(lexer)
    parser = IMLParser(tokens)
    tree = parser.program()
    if parser.getNumberOfSyntaxErrors() > 0:
        pytest.skip("Erro sintático, não posso testar o semântico")
    return tree
