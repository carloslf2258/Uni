# tests/test_semantic_success.py
import pytest
from tests.utils import parse_iml
from src_python.iml_semanticAnalyzer import iml_semanticAnalyzer

#TODO organizar por seccoes
# SECTION[epic=semantic_sucess,seq=1]
def test_decl_and_assign_ok():
    src = """
      number x is 10
      x is 5
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    # não deve lançar exceção
    sem.visit(tree)

def test_load_img():
    src = 'image i0 is load from "image.pgm"'
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_create_img():
    src = """
        image size 1 by 1 background 0
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_until():
    src = """
        boolean b is true
        until b do
          number x is 10
        done
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_place_shape():
    src = """
        number r is 5
        place circle radius r at 1/2 1/2 with intensity 1
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_draw_img():
    src = """
        image i is load from "image.pgm"
        draw i
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_output():
    src = """
        image i is load from "images/sample00.pgm"
        output i
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_append():
    src = """
        list of number xs is []
        xs append 10
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_store_img():
    src = """
        image i is load from "file.pgm"
        i store into "copy.pgm"
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_expr_stmt():
    src = """
        true
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_negate_number():
    src = """
        number x is -10
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_not_expr():
    src = """
        not true
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_pixel_op():
  src = """
      image img is load from "images/sample.pgm"
      img .+ 1
  """
  tree = parse_iml(src)
  sem = iml_semanticAnalyzer()
  sem.visit(tree)

def test_scale_op():
    src = """
        image i is load from "images/sample.pgm"
        i -* 0.5
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_muldiv():
    src = """
        number x is 10 * 2
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_addsub():
    src = """
        number x is 10 + 5
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_relational_expr():
    src = """
        number a is 5
        number b is 10
        a == b
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_logical_expr():
    src = """
        (5 > 6) and (6 > 4)
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_morph_op_with_list_of_lists():
    src = """
        image i is load from "img.pgm"
        list of list of number k is []
        k append [0, 1, 0]
        k append [1, 1, 1]
        k append [0, 1, 0]
        i erode by k
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_morph_op_with_img():
    src = """
        image i is load from "img.pgm"
        image k is run from read "Path: "
        i open by k
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_any_pixel_expr():
    src = """
        image i is load from "images/sample.pgm"
        any pixel i .> 0
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_all_pixel_expr():
    src = """
        image i is load from "images/sample00.pgm"
        all pixel i
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_count_pixel_expr():
    src = """
        image i is load from "images/sample.pgm"
        number n is count pixel 1 in i
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_rcol_expr_rows():
    src = """
        image img is load from "images/sample.pgm"
        number n is rows of img
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_rcol_expr_cols():
    src = """
        image img is load from "images/sample.pgm"
        number n is columns of img
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_literal_expr_string():
    src = """
        string s is "hello"
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_literal_expr_percentage():
    src = """
        percentage p is 50%
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_var_expr():
    src = """
        number x is 42
        x
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_number_cast_from_string():
    src = """
        number n is number("42")
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)

def test_number_cast_from_number():
    src = """
        number n is number(123)
    """
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    sem.visit(tree)


# SECTION IfStt
@pytest.mark.parametrize("src", [
    #+: if sem else, declara e usa variável local
    """
    boolean b is true
    if b then
        number x is 1
    done
    """,
    #+: if com else, variáveis diferentes
    """
    boolean b is false
    if b then
        number x is 1
    else
        number y is 2
    done
    """,
    #+: referência a variável externa dentro do if
    """
    number n is 5
    if n > 0 then
        number x is n
    done
    """,
])
def test_if(src):
    tree = parse_iml(src)
    sem = iml_semanticAnalyzer()
    # não deve lançar exceção
    sem.visit(tree)
#!SECTION








#!SECTION
