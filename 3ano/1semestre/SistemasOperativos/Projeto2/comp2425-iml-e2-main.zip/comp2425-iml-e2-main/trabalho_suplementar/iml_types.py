# iml_types.py

import re
from abc import ABC, abstractmethod
from typing import Dict, Any

class Type(ABC):
    @abstractmethod
    def __repr__(self) -> str:
        ...
        
    def __eq__(self, other: object) -> bool:
        return type(self) is type(other) and self._equals(other)  # exact same class

    def _equals(self, other: "Type") -> bool:
        # override in subclasses with parameters (e.g. ListType)
        return True

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __hash__(self):
        # garante que t1 == t2 ⇒ hash(t1) == hash(t2)
        return hash((self.__class__, getattr(self, "elem_type", None)))
    
    def __str__(self) -> str:
        return repr(self)

    def is_assignable_from(self, other: "Type") -> bool:
        """
        Can we assign a value of `other` into a variable of this type?
        By default requires equal types; override if you want subtyping.
        """
        return self == other

    def unify(self, other: "Type") -> "Type":
        """
        Least‐upper‐bound of two types, for e.g. checking branches of an if.
        By default only equal types unify to themselves.
        """
        if self == other:
            return self
        raise TypeError(f"cannot unify {self!r} with {other!r}")

    def to_json(self) -> Dict[str, Any]:
        """Serialize for debugging or error messages."""
        return {"kind": self.__class__.__name__}
    

class ImageType(Type):
    def __repr__(self)-> str:
        return "Image"

class NumberType(Type):
    def __repr__(self)-> str:
        return "Number"
    
    def unify(self, other):
         # Number + Percentage => Number
        if isinstance(other, PercentageType):
            return NumberType()
         # Number + Number => Number
        if isinstance(other, NumberType):
            return self
        return super().unify(other)

class StringType(Type):
    def __repr__(self)-> str:
        return "String"

class PercentageType(Type):
    def __repr__(self)-> str:
        return "Percentage"
    
    def unify(self, other: Type) -> Type:
        # Percentage + Number => Number (mesmo que em NumberType)
        if isinstance(other, NumberType):
            return NumberType()
        # Percentage + Percentage => Percentage
        if isinstance(other, PercentageType):
            return self
        return super().unify(other)

class BooleanType(Type):
    def __repr__(self)-> str:
        return "Boolean"

class ListType(Type):
    """
    List[T], onde T é outro Type qualquer.
    """
    def __init__(self, elem_type: Type):
        self.elem_type = elem_type

    def _equals(self, other: "ListType") -> bool:
        return self.elem_type == other.elem_type
    
    def __repr__(self):
        return f"List[{self.elem_type!r}]"
    
    def is_assignable_from(self, other: Type) -> bool:
        return (
            isinstance(other, ListType)
            and self.elem_type.is_assignable_from(other.elem_type)
        )

    def unify(self, other: Type) -> Type:
        if isinstance(other, ListType):
            inner = self.elem_type.unify(other.elem_type)
            return ListType(inner)
        return super().unify(other)
    
    def to_json(self) -> Dict[str, Any]:
        return {"kind": "List", "elem": self.elem_type.to_json()}

# -----------------------------------------------------------------------------
# helper para mapear ctx de "type" do parser no nosso Type
# -----------------------------------------------------------------------------

def type_from_ctx(ctx):
    """
    Recebe um ctx de IMLGrammar2Parser.type() e devolve a instância
    do Type correspondente.
    """
    # ctx.IMAGE_T(), ctx.NUMBER_T(), etc. vêm do parser
    if ctx.IMAGE_T():
        return ImageType()
    if ctx.NUMBER_T():
        return NumberType()
    if ctx.STRING_T():
        return StringType()
    if ctx.PERCENTAGE_T():
        return PercentageType()
    # Boolean adicionado
    if ctx.BOOLEAN_T():
        return BooleanType()
    # regra recursiva para LIST OF type
    if ctx.LIST() and ctx.OF():
        inner = type_from_ctx(ctx.type_())
        return ListType(inner)

    raise ValueError(f"Tipo desconhecido em type_from_ctx: {ctx.getText()}")

# -----------------------------------------------------------------------------
# Helper: infer a Type from a literal token text
# -----------------------------------------------------------------------------

_literal_re = {
    "integer": re.compile(r"^[0-9]+$"),
    "real":    re.compile(r"^[0-9]+\.[0-9]*$"),
    "percent": re.compile(r"^[0-9]+(\.[0-9]+)?%$"),
    "boolean": re.compile(r"^(true|false)$", re.IGNORECASE),
    "string":  re.compile(r'^".*"$'),
}

def type_of_literal(text: str) -> Type:
    """
    Given the raw token text of a literal, return its Type.
    E.g. "123" → NumberType(), "12.3" → NumberType(),
          "50%" → PercentageType(), '"foo"' → StringType(),
          true → BooleanType().
    """
    if _literal_re["percent"].match(text):
        return PercentageType()
    if _literal_re["real"].match(text) or _literal_re["integer"].match(text):
        return NumberType()
    if _literal_re["boolean"].match(text):
        return BooleanType()
    if _literal_re["string"].match(text):
        return StringType()
    raise ValueError(f"Unrecognized literal for type inference: {text!r}")