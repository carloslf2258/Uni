from antlr4 import *
from IMLParser import IMLParser
from IMLVisitor import IMLVisitor
from src_python.iml_symbolTable import (
    SymbolTable,
    VarSymbol,
    RedefinitionError,
    UndefinedVariableError,
)
from src_python.iml_types import (
    NumberType,
    StringType,
    BooleanType,
    ImageType,
    ListType,
    PercentageType,
    type_of_literal,
)

# TODO No final integrar com a geracao de codigo


class SemanticError(Exception):
    pass


class iml_semanticAnalyzer(IMLVisitor):
    def __init__(self):
        self.symtab = SymbolTable()

    # ─── Entry point ────────────────────────────────────────────────────────────
    # +: isto é feito pelo IMLMain.py
    # def analyze(self, parse_tree):
    #    try:
    #        self.visit(parse_tree)
    #    except (SemanticError, RedefinitionError, UndefinedVariableError) as e:
    #        print("Semantic error:", e)
    #       raise

    def visitProgram(self, ctx: IMLParser.ProgramContext):
        return self.visitChildren(ctx)

    def visitVarDeclStt(self, ctx: IMLParser.VarDeclSttContext):
        declared_type = self.visit(ctx.type_())  # e.g. returns a Type object
        name = ctx.ID().getText()
        try:
            self.symtab.define(VarSymbol(name, declared_type))
        except RedefinitionError as e:
            raise SemanticError(str(e))
        # Now visit the initializer expression
        expr_type = self.visit(ctx.e)

        # tratamento de listas vazias
        if isinstance(expr_type, ListType) and expr_type.elem_type is None:
            expr_type = declared_type

        if not declared_type.is_assignable_from(expr_type):
            raise SemanticError(f"Cannot assign {expr_type!r} to {declared_type!r}")
        return None

    def visitAssignStt(self, ctx: IMLParser.AssignSttContext):
        name = ctx.ID().getText()
        sym = self.symtab.lookup(name)
        if sym is None:
            raise UndefinedVariableError(f"Variable not declared: {name}")
        expr_type = self.visit(ctx.e)
        if not sym.type.is_assignable_from(expr_type):
            raise SemanticError(f"Cannot assign {expr_type!r} to {sym.type!r}")
        return None

    def visitLoad_RunStt(self, ctx: IMLParser.Load_RunSttContext):
        print("Visiting Load/Run statement")
        name = ctx.ID().getText()
        try:
            self.symtab.define(VarSymbol(name, ImageType()))
        except RedefinitionError as e:
            raise SemanticError(str(e))
        return None

    def visitImageCreateStt(self, ctx: IMLParser.ImageCreateSttContext):
        t1 = self.visit(ctx.e1)
        t2 = self.visit(ctx.e2)
        t3 = self.visit(ctx.e3)

        for i, t in enumerate([t1, t2, t3], start=1):
            if not NumberType().is_assignable_from(t):
                raise SemanticError(
                    f"Parameter {i} of image creation must be Number, got {t!r}"
                )

        return ImageType()

    def visitPlaceShapeStt(self, ctx: IMLParser.PlaceShapeSttContext):
        t1 = self.visit(ctx.e1)
        t2 = self.visit(ctx.e2)
        t3 = self.visit(ctx.e3)
        t4 = self.visit(ctx.e4)

        for i, t in enumerate([t1, t2, t3, t4], start=1):
            if not NumberType().is_assignable_from(t):
                raise SemanticError(
                    f"Parameter {i} of shape placement must be Number, got {t!r}"
                )

        # A "shape" é validada diretamente no parser

        return None

    def visitDrawStt(self, ctx: IMLParser.DrawSttContext):
        name = ctx.ID().getText()
        sym = self.symtab.lookup(name)
        if sym is None:
            raise UndefinedVariableError(f"Variable not declared: {name}")
        if not isinstance(sym.type, ImageType):
            raise SemanticError(f"Can only draw images and {name} is {sym.type!r}")
        return None

    def visitOutputStt(self, ctx: IMLParser.OutputSttContext):
        # garantir que a expressão é visitada e válida semanticamente
        self.visit(ctx.e)
        return None

    def visitAppendStt(self, ctx: IMLParser.AppendSttContext):
        name = ctx.ID().getText()
        sym = self.symtab.lookup(name)
        if sym is None:
            raise UndefinedVariableError(f"Variable not declared: {name}")
        if not isinstance(sym.type, ListType):
            raise SemanticError(f"Variable {name} is not a list")

        elem_type = self.visit(ctx.e)
        if not sym.type.elem_type.is_assignable_from(elem_type):
            raise SemanticError(f"Cannot append {elem_type!r} to {sym.type!r}")

        return None

    def visitStoreStt(self, ctx: IMLParser.StoreSttContext):
        print("Visiting Store statement")
        name = ctx.ID().getText()
        sym = self.symtab.lookup(name)
        if sym is None:
            raise UndefinedVariableError(f"Variable not declared: {name}")
        if not isinstance(sym.type, ImageType):
            raise SemanticError(f"Cannot store non-image variable {name!r}")
        return None

    def visitIfStt(self, ctx: IMLParser.IfSttContext):
        # REVIEW se e para usar o boolean
        cond_type = self.visit(ctx.e)
        if not BooleanType().is_assignable_from(cond_type):
            raise SemanticError("Condition of if must be Boolean")
        # then‐block
        self.symtab.push()
        #!: penso que nao da para fazer ctx.statement(0), ctx.statement(1)
        for st in ctx.thenBlock.statement():
            self.visit(st)
        self.symtab.pop()
        # else‐block (if present)
        if ctx.ELSE():
            self.symtab.push()
            for st in ctx.elseBlock.statement():
                self.visit(st)
            self.symtab.pop()
        return None

    def visitForStt(self, ctx: IMLParser.ForSttContext):
        # e.g. "for number i in someList ..."
        list_type = self.visit(ctx.e)
        if not isinstance(list_type, ListType):
            raise SemanticError(f"Cannot iterate over non‐list {list_type!r}")
        # new inner scope for loop
        self.symtab.push()
        # if they declared the loop variable type explicitly:
        if ctx.type_():
            declared = self.visit(ctx.type_())
        else:
            declared = list_type.elem_type
        name = ctx.ID().getText()
        self.symtab.define(VarSymbol(name, declared))
        for st in ctx.forBlock.statement():
            self.visit(st)
        self.symtab.pop()
        return None

    def visitUntilStt(self, ctx: IMLParser.UntilSttContext):
        # Ver se condição é boleana
        cond_type = self.visit(ctx.e)
        if not BooleanType().is_assignable_from(cond_type):
            raise SemanticError("Condition of until must be Boolean")

        # Novo escopo para o bloco until
        self.symtab.push()
        for st in ctx.untilBlock.statement():
            self.visit(st)
        self.symtab.pop()

        return None

    def visitExprStt(self, ctx: IMLParser.ExprSttContext):
        # apenas garantir que a expressão é semanticamente válida
        self.visit(ctx.e)
        return None

    def visitStatement_list(self, ctx: IMLParser.Statement_listContext):
        return self.visitChildren(ctx)

    # fileName: READ? STRING;
    # parser já verifica se é string e por isso função fica igual
    def visitFileName(self, ctx: IMLParser.FileNameContext):
        # TODO fazer testes de erro com o token READ
        print("Visiting FileName")
        str_node = ctx.STRING()  # o token com o path e obrigatorio
        if str_node is None:  # ve se existe o token STRING
            raise SemanticError("Load/run requires a filename literal")
        if ctx.READ() is None:
            filename = str_node.getText()
            # print(f"Filename: {filename}")
            if not (filename.lower().endswith(".pgm\"")):  # apenas .pgm permitido
                raise SemanticError(f"Invalid file extension in load/run: {filename}")
        return None

    # Tambem não precisa de verificação semantica especifica
    # Tipo String é verificado no parser
    def visitReadStmt(self, ctx: IMLParser.ReadStmtContext):
        return self.visitChildren(ctx)

    def visitPixelOpExpr(self, ctx: IMLParser.PixelOpExprContext):
        t1 = self.visit(ctx.e1)
        t2 = self.visit(ctx.e2)

        if not isinstance(t1, ImageType):
            raise SemanticError(
                f"Pixel operation requires image on the left, got {t1!r}"
            )
        if not isinstance(t2, (NumberType, PercentageType)):
            raise SemanticError(
                f"Pixel operation requires number or percentage on the right, got {t2!r}"
            )

        return ImageType()

    # conta pixeis de intensidade do tipo number ou percentage (penso que pode receber percentage tambem mas ns)
    # em uma imagem e retorna o numero de pixeis com essa intensidade
    def visitCountPixelExpr(self, ctx: IMLParser.CountPixelExprContext):
        t1 = self.visit(ctx.e1)
        t2 = self.visit(ctx.e2)

        if not isinstance(t1, (NumberType, PercentageType)):
            raise SemanticError(
                f"'count pixel' requires a number or percentage on the left, got {t1!r}"
            )

        if not isinstance(t2, ImageType):
            raise SemanticError(
                f"'count pixel' requires an image on the right, got {t2!r}"
            )

        return NumberType()

    def visitAnyPixelExpr(self, ctx: IMLParser.AnyPixelExprContext):
        expr_type = self.visit(ctx.e)
        if isinstance(expr_type, ImageType):
            return BooleanType()
        if isinstance(expr_type, ListType) and isinstance(
            expr_type.elem_type, BooleanType
        ):
            return BooleanType()
        raise SemanticError(
            f"'any pixel' expression requires an image or list of booleans, got {expr_type!r}"
        )

    def visitScaleOpExpr(self, ctx: IMLParser.ScaleOpExprContext):
        t1 = self.visit(ctx.e1)
        t2 = self.visit(ctx.e2)

        if not isinstance(t1, ImageType):
            raise SemanticError(
                f"Scale operation requires image on the left, got {t1!r}"
            )
        if not isinstance(t2, (NumberType, PercentageType)):
            raise SemanticError(
                f"Scale operation requires number or percentage on the right, got {t2!r}"
            )

        return ImageType()

    def visitRelationalExpr(self, ctx: IMLParser.RelationalExprContext):
        t1 = self.visit(ctx.e1)
        t2 = self.visit(ctx.e2)

        if t1 != t2:
            raise SemanticError(f"Cannot compare {t1!r} with {t2!r}")

        return BooleanType()

    # não precisa de alteração porque o atom não é um nó “real”
    # com semântica própria, apenas reencaminha para um dos casos concretos(filhos)
    def visitAtomExpr(self, ctx: IMLParser.AtomExprContext):
        return self.visitChildren(ctx)

    def visitNegateExpr(self, ctx: IMLParser.NegateExprContext):
        expr_type = self.visit(ctx.e)
        if not isinstance(expr_type, (NumberType, PercentageType)):
            raise SemanticError(f"Cannot apply '-' to {expr_type!r}")
        return expr_type

    def visitAllPixelExpr(self, ctx: IMLParser.AllPixelExprContext):
        expr_type = self.visit(ctx.e)

        if isinstance(expr_type, ImageType):
            return BooleanType()

        if isinstance(expr_type, ListType) and isinstance(
            expr_type.elem_type, BooleanType
        ):
            return BooleanType()

        raise SemanticError(
            f"'all pixel' expression requires an image or list of booleans, got {expr_type!r}"
        )

    def visitMulDivExpr(self, ctx: IMLParser.MulDivExprContext):
        t1 = self.visit(ctx.e1)
        t2 = self.visit(ctx.e2)
        return t1.unify(t2)

    def visitNotExpr(self, ctx: IMLParser.NotExprContext):
        expr_type = self.visit(ctx.e)
        if not BooleanType().is_assignable_from(expr_type):
            raise SemanticError(f"'not' operator requires Boolean, got {expr_type!r}")
        return BooleanType()

    # apenas visitar o contexto da expressão dentro dos parentises -> por isso fica assim
    def visitParenExpr(self, ctx: IMLParser.ParenExprContext):
        return self.visit(ctx.e)

    def visitAddSubExpr(self, ctx: IMLParser.AddSubExprContext):
        t1 = self.visit(ctx.e1)
        t2 = self.visit(ctx.e2)
        return t1.unify(t2)

    def visitLogicalExpr(self, ctx: IMLParser.LogicalExprContext):
        # and/or both require Boolean operands
        t1, t2 = self.visit(ctx.e1), self.visit(ctx.e2)
        if not BooleanType().is_assignable_from(
            t1
        ) or not BooleanType().is_assignable_from(t2):
            raise SemanticError("Logical operators require Booleans")
        return BooleanType()

    # Penso que à direita é possível ter tanto uma imagem como uma matriz de números (pelos exemplos)
    # Não tenho a certeza se a análise semântica desta expressão está certa
    # Poderá poder receber apenas uma lista de números à direita??
    def visitMorphOpExpr(self, ctx: IMLParser.MorphOpExprContext):
        t1 = self.visit(ctx.e1)
        t2 = self.visit(ctx.e2)

        if not isinstance(t1, ImageType):
            raise SemanticError(
                f"Morphological operation requires image on the left, got {t1!r}"
            )

        if isinstance(t2, ImageType):
            return ImageType()

        if not (
            isinstance(t2, ListType)
            and isinstance(t2.elem_type, ListType)
            and isinstance(t2.elem_type.elem_type, NumberType)
        ):
            raise SemanticError(
                f"Morphological operation requires list of list of numbers or image on the right, got {t2!r}"
            )

        return ImageType()

    # ID tem de ser uma imagem -> tem de estar declarada
    # retorna um numero
    def visitRColExpr(self, ctx: IMLParser.RColExprContext):
        name = ctx.ID().getText()
        sym = self.symtab.lookup(name)

        if sym is None:
            raise UndefinedVariableError(f"Variable not declared: {name}")
        if not isinstance(sym.type, ImageType):
            raise SemanticError(
                f"'rows of' or 'columns of' requires image, got {sym.type!r}"
            )

        return NumberType()

    def visitLiteralExpr(self, ctx: IMLParser.LiteralExprContext):
        text = ctx.getText()
        return type_of_literal(text)

    def visitVarExpr(self, ctx: IMLParser.VarExprContext):
        name = ctx.ID().getText()
        sym = self.symtab.lookup(name)
        if sym is None:
            raise UndefinedVariableError(f"Variable not declared1: {name}")
        return sym.type

    # A nivel semantico penso que pode ser retirado da gramatica porque esta funcao nunca é visitada
    # Visita sempre visitNegateExpr que penso que já tem o comportamento semantico adequado,
    # deixando apenas negar expressões que sejam ou que resultem num número ou percentagem.
    """def visitUnaryMinusExpr(self, ctx:IMLParser.UnaryMinusExprContext):
        expr_type = self.visit(ctx.atom())

        if not isinstance(expr_type, (NumberType, PercentageType)):
            raise SemanticError(f"Unary '-' only applies to numbers or percentages, got {expr_type!r}")

        return expr_type"""

    def visitNumberCastExpr(self, ctx: IMLParser.NumberCastExprContext):
        arg_type = self.visit(ctx.expr() or ctx.readStmt())

        if not isinstance(arg_type, (NumberType, StringType)):
            raise SemanticError(f"Cannot cast {arg_type!r} to number")

        return NumberType()

    def visitPercentageCastExpr(self, ctx: IMLParser.PercentageCastExprContext):
        # TODO fazer testes
        arg_type = self.visit(ctx.expr() or ctx.readStmt())
        if not isinstance(arg_type, (NumberType, PercentageType, StringType)):
            raise SemanticError(f"Cannot cast {arg_type!r} to Percentage")
        return PercentageType()

    def visitStringCastExpr(self, ctx: IMLParser.StringCastExprContext):
        # TODO fazer testes
        arg_type = self.visit(ctx.expr() or ctx.readStmt())
        if not isinstance(arg_type, ImageType):
            raise SemanticError(f"Cannot cast {arg_type!r} to String")
        return StringType()

    def visitListExpr(self, ctx: IMLParser.ListExprContext):
        elements = ctx.expr()
        if not elements:
            return ListType(None)  # lista vazia: sem tipo definido ainda
        first_type = self.visit(elements[0])
        for e in elements[1:]:
            t = self.visit(e)
            first_type = first_type.unify(t)
        return ListType(first_type)

    def visitRelOp(self, ctx: IMLParser.RelOpContext):
        return self.visitChildren(ctx)

    def visitLogicOp(self, ctx: IMLParser.LogicOpContext):
        return self.visitChildren(ctx)

    def visitArithOp(self, ctx: IMLParser.ArithOpContext):
        return self.visitChildren(ctx)

    def visitFlipOp(self, ctx: IMLParser.FlipOpContext):
        return self.visitChildren(ctx)

    def visitPixelOp(self, ctx: IMLParser.PixelOpContext):
        return self.visitChildren(ctx)

    def visitScaleOp(self, ctx: IMLParser.ScaleOpContext):
        return self.visitChildren(ctx)

    def visitMorphOp(self, ctx: IMLParser.MorphOpContext):
        return self.visitChildren(ctx)

    def visitType(self, ctx: IMLParser.TypeContext):
        # +: HELPER
        from src_python.iml_types import type_from_ctx

        return type_from_ctx(ctx)

    def visitShape(self, ctx: IMLParser.ShapeContext):
        return self.visitChildren(ctx)
