# iml_symbolTable.py

from src_python.iml_types import Type

class Symbol:
    #+: Superclasse para tudo o que se possa colocar na tabela de símbolos.
    def __init__(self, name: str, type_: Type):
        self.name = name
        self.type = type_

    def __repr__(self):
        return f"<Symbol name={self.name!r} type={self.type!r}>"

class VarSymbol(Symbol):
    # +: Uma variável declarada
    pass

# NOTE[id=ConstantSymbol] Só para caso começar a suportar constantes nomeadas, ex: PI = 3.1415…, E = 2.718…, NEWLINE = "\n"
# class ConstantSymbol(Symbol):
#   pass
#
# NOTE[id=FunctionParameterSymbol] Só para caso começar a suportar funções, ex: function foo(x: number, y: number) returns number { … }
# class FunctionSymbol(Symbol):
# def __init__(self, name: str, ret_type: Type, params: list[VarSymbol]):
#        super().__init__(name, ret_type)
#        self.params = params
#
#    def __repr__(self):
#        return f"<Function {self.name}({', '.join(p.name for p in self.params)}) -> {self.type!r}>"
#
# NOTE[id=FunctionParameterSymbol]  Só para caso começar a suportar funções
# class ParameterSymbol(Symbol): #?: para parâmetros de funções
#   pass
#

#REVIEW confirmar se IML usa variaveis com scope apenas em blocos por exemplo "if(tal)then x is (tal) ... done" depois nao pode dar para acessar x
class Scope:
    #+: Um escope único, apontando possivelmente para um pai (escopo exterior)
    def __init__(self, parent=None):
        self.parent = parent
        self.symbols: dict[str,VarSymbol] = {}

    def define(self, sym: VarSymbol):
        if sym.name in self.symbols:
            raise RedefinitionError(f"Symbol already declared in this scope: {sym.name}")
        self.symbols[sym.name] = sym

    def lookup(self, name: str) -> VarSymbol | None:
        #+: Procura recursivamente em escopes ascendentes
        if name in self.symbols:
            return self.symbols[name]
        if self.parent:
            return self.parent.lookup(name)
        return None
    
    def all_symbols(self) -> list[VarSymbol]:
        #+: Para debug: todos os simbolos
        result = list(self.symbols.values())
        if self.parent:
            result += self.parent.all_symbols()
        return result

class SymbolTable:
    #+: Gerencia pilha de scopes para analise semantica
    #+: Uso de scopes para casos como blocos de if 
    def __init__(self):
        self.current = Scope()
        # Exemplo: predefinir a variável pipeline, ou constantes…
        # from iml_types import NumberType
        # self.define(VarSymbol("PI", NumberType()))

    def push(self):
        self.current = Scope(parent=self.current)

    def pop(self):
        if self.current.parent is None:
            raise SymbolError("Tried to exit the global scope")
        self.current = self.current.parent

    def define(self, sym: VarSymbol):
        #+: Adiciona uma variável ao escopo atual
        self.current.define(sym)

    def lookup(self, name: str):
        #+: Para debug: procura no escope atual -> proucura em todos os escopos começando no atual 
        return self.current.lookup(name)


class SymbolError(Exception): 
    #+: Erro generico de simbolos
    pass
class RedefinitionError(SymbolError): 
    #+: Caso de tentativa de redefinir uma variável já declarada
    pass
class UndefinedVariableError(SymbolError): 
    #+: Caso de tentativa de usar uma variável não declarada
    pass
