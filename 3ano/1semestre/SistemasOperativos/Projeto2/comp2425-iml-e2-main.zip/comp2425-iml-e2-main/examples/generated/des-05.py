import numpy as np
from skimage import morphology
from PIL import Image as PILImage
import sys
import os
if (sys.path[0].split('/')[0] != 'src'):
    sys.path.insert(0, os.path.abspath(os.path.join('..', '')))
from IIML.Types import ImagePGM, Number, String, Percentage, ListType
import IIML.IIMLMain as IIMLMain 

i = ImagePGM.load(input("Path: ")) 
k = [] 
k.append([0 , 1 , 0 ]) 
k.append([1 , 1 , 1 ]) 
k.append([0 , 1 , 0 ]) 
t = i.top_hat(k) 
b = i.black_hat(k) 
r = i + t - b 
r.store("images/enhanced.pgm")  