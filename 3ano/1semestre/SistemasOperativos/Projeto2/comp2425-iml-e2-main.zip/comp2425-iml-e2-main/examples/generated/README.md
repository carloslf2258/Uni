# Diretório de Ficheiros Gerados

Ficheiros gerados a partir do script `compile` (isto é, ficheiros Python resultantes da tradução de código IML, incluindo ficheiros gerados na realização de testes) são guardados aqui.