# Projeto IML - Compiladores - UA.

## Integrantes:
```
Carlos Verenzuela - 114597
Lázaro Sá - 115884
Olha Buts - 112920
André Marques - 87818
Francisco Fernandes - 98178
Luís Diogo - 108668
```

## Preparar o ambiente
```bash
python3 -m venv .venv # create a virtual environment
source .venv/bin/activate # activate the virtual environment
pip install -r requirements.txt # install dependencies
pip install -e . # install the package in editable mode
```

# Scripts
```
build.sh
compile.sh
run.sh
clean.sh
```

# Trabalho suplementar
Foi desenvolvido uma gramática e um analisador semântico em python para explorar opções de desenvolvimento bem com as suas limitações.

## Nossos testes (pasta tests):
### Fora da src do projeto, está a pasta "tests". Nesta se encontram: 
### - Conjunto de testes feitos pelo grupo
### - script run_IMLtests.sh para correr todos

```
./run_IMLtests.sh 
```

### Em caso de erro:
#### Converter para Unix (CRLF -> LF)
```
sed -i 's/\r$//' script_name.sh
```
#### Pôr script como executável
```
chmod +x script_name.sh
``` 

# IML — Visitor de Geração de Código
Este componente implementa a geração de código Python a partir de programas escritos na linguagem IML.

## Objetivo
```
O objetivo deste componente é traduzir um programa IML para código Python válido. Esse código gerado utiliza bibliotecas como PIL (Python Imaging Library) e matplotlib para manipulação, visualização e armazenamento de imagens.
```

## Como funciona
```
A conversão é feita através de um visitor ANTLR, Compiler.py, que herda de IMLVisitor. Cada método do visitor corresponde a uma regra da gramática IML.g4 e gera a respetiva instrução Python.
```

### Exemplo de fluxo:
```
1. Um programa `.iml` é lido e processado por um parser gerado pelo ANTLR.
2. O visitor `Compiler` percorre a AST (Abstract Syntax Tree).
3. Gera um ficheiro `.py` com código equivalente, que pode ser executado para produzir os mesmos efeitos definidos em IML.
```

## Agentes essenciais
```
IML.g4            → Gramática ANTLR4 da linguagem IML   
Compiler.py       → Visitor personalizado para geração de código Python  
IMLMain.py        → Script de entrada: lê `.iml`, aplica parser e visitor  
Types.py          → Tipos auxiliares (Number, Percentage, String)
```

## Manipulação de Imagens
```
visitLoad_RunStt   → Carrega imagem com Image.open(...)  
visitStoreStt      → Guarda imagem com .save(...)  
visitDrawStt       → Mostra imagem com matplotlib.pyplot  
visitOutputStt     → Imprime informações da imagem (size, mode, etc.)
```

### Exemplos:
- `echo 'image i is load from "images/sample00.pgm"' | antlr4-run -python`
- `echo 'i store into "images/output.pgm"' | antlr4-run -python`
- `echo 'draw i' | antlr4-run -python`
- `echo 'output i' | antlr4-run -python`

### Expressões
```
visitPixelOpExpr, visitAddSubExpr, visitMulDivExpr, visitRelationalExpr  
→ Geram operações como +, *, >, etc.

visitRColExpr  
→ Devolve número de linhas ou colunas (img.size[1], img.size[0])
```

### Exemplos:
- `echo '2 + 2' | antlr4-run -python`
- `echo 'i0 -* (i1cols / i0cols)' | antlr4-run -python`
- `echo 'rows of i' | antlr4-run -python`


### Estruturas de Controlo
```
visitIfStt         → Traduz estrutura condicional if-else  
visitForStt        → Placeholder para laço for  
visitUntilStt      → Placeholder para laço until
```

### Exemplos:
- `echo 'if 2 > 1 then output i end' | antlr4-run -python`
- `echo 'for x from 0 to 10 do draw i end' | antlr4-run -python` *(placeholder)*
- `echo 'until x > 10 do draw i end' | antlr4-run -python` *(placeholder)*


### Variáveis e Atribuições
```
visitVarDeclStt    → Declara variáveis (e.g., number a is columns of img)  
visitAssignStt     → Atribui valores a variáveis
```
### Exemplos:
- `echo 'number a is columns of i' | antlr4-run -python`
- `echo 'a is a + 1' | antlr4-run -python`

### Literais e variáveis
```
visitLiteralExpr, visitVarExpr  
→ Devolvem diretamente os valores ou nomes das variáveis
```

### Exemplos:
- `echo '2.0' | antlr4-run -python`
- `echo 'myVar' | antlr4-run -python`
---

# IIML (Subset da IML, Interpretada):
<br>

### Gerar uma imagem:
- #### echo "image size 10 by 10 background 0.7" | antlr4-run -python (**DONE**)
<br>


### Adicionar Figuras a uma imagem existente:
- #### echo "place [rect|circle|plus] size 100 at 50 50 with intensity 0.3" | antlr4-run -python (**DONE**)
<br>


### Input de Valores (read from terminal):
- #### echo 'read "size: "'| antlr4-run -python (**DONE**)
<br>


### Atribuições de Valor:
- #### echo "[number|string|percentage] nomeVar is 2%" | antlr4-run -python (**DONE**)
<br>


## Aritmética Standard:

- ### **Number/String/Percentage Data Types:**
    - #### echo '"2" [+|-|*|/] "2"' | antlr4-run -python
    - #### echo "2.0 [+|-|*|/] 2.0" | antlr4-run -python
<br>

- ### **Image Data Type:**
    - #### **Entre duas imagens:**
        - #### echo "img1 [+|-|*|/] img2" | antlr4-run -python

    - #### **Apenas sobre uma imagem:**
        - #### Inverso da Imagem (.-): echo "img1 .-" | antlr4-run -python
        - #### Operações de Escala: echo "img1 [-*|/*|+*] 2" | antlr4-run -python
        - #### Operações de Flip: echo "img1 [-|/|+] 2" | antlr4-run -python


### Notas:

- ### antlr4-build -python && antlr4-main -python -f -v Interpreter IIML program
- ### clear && echo 'image valor is image size 1000 by 1000 background 0.3 place rect size 350 at 500 500 with intensity 0.8' | antlr4-run -python

---
# Visitor de análise semântica:

### Para executar:
- **JAVA**
```bash
antlr4 IML.g4 -visitor -no-listener   # geracao codigo fonte para o diretorio generated
antlr4-javac *.java 
cat ../../examples/min-01.iml | antlr4-test IML program -tokens -tree


#---------------------CLEAN---------------------
antlr4-clean
```
- **PYTHON**
```bash
antlr4-build -python IML.g4 # gerar os cripts do antlr4 
python antlr4py-test.py IML ../../examples/min-01.iml --tokens --tree # testar parser e lexer
pytest -q # executar os testes
antlr4-clean -python # clean generated files
```

### Rascunho
- **JAVA**
```bash
    #---------------------TESTES---------------------
    # 1)
antlr4-visitor IML SemanticAnalyser Type
antlr4 IML.g4 -visitor -no-listener 
antlr4-javac *.java
cat ../../../examples/min-01.iml | antlr4-test IML program -tokens -tree
    # 2)
antlr4-main IML program -v SemanticAnalyser
    # x) talvez usar isto no final de ter semanticAnalyzer feito
antlr4-build IML
```
- Executar
```bash
cd src # entrar no diretorio src
antlr4 IML.g4 -visitor -no-listener -o ../generated # geracao codigo fonte para o diretorio generated
antlr4-javac ../generated/IML*.java -d ../classes # depois disto ja se pode testar a arvore sintatica
antlr4-java -ea[:<packagename>...|:<classname>]
```
- Teste à arvore sintatica

```bash
cat ../../examples/min-01.iml | antlr4-test IML program -tokens -tree -gui
```

- Executar todos os testes à arvore sintatica

```bash
cat ../../examples/min-01.iml | antlr4-test IML program -tokens -tree && \
echo "-------------------------" && \
cat ../../examples/min-02.iml | antlr4-test IML program -tokens -tree && \
echo "-------------------------" && \
cat ../../examples/min-03.iml | antlr4-test IML program -tokens -tree && \
echo "-------------------------" && \
cat ../../examples/des-01.iml | antlr4-test IML program -tokens -tree && \
echo "-------------------------" && \
cat ../../examples/des-02.iml | antlr4-test IML program -tokens -tree && \
echo "-------------------------" && \
cat ../../examples/des-03.iml | antlr4-test IML program -tokens -tree && \
echo "-------------------------" && \
cat ../../examples/des-04.iml | antlr4-test IML program -tokens -tree && \
echo "-------------------------" && \
cat ../../examples/des-05.iml | antlr4-test IML program -tokens -tree
```
- **PYTHON**
```bash
antlr4-build -python IML.g4
antlr4-main -python -indent 4 IML program
antlr4-main -python -indent 4 IML program -v VisitorName # cria um main com o visitor VisitorName
antlr4-visitor -python -indent 4 IML VisitorName BaseVisitor
antlr4-visitor -python -indent 4 IML VisitorName CustomVisitor

antlr4-visitor -python -indent 4 IML iml_semanticAnalyzer BaseVisitor
```

