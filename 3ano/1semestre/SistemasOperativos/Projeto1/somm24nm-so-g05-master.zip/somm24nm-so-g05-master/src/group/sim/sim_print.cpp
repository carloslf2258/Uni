/*
 *  \author Rafael Claro
 *  \author Rúben Franco
 */

#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cinttypes>
#include "dbc.h"
#include "probing.h"
#include "sim.h"
#include "jdt.h"
#include "pct.h"
#include "mem.h"
#include "rdy.h"
#include "swp.h"

namespace group
{

// ================================================================================== //

    void simPrint(FILE *fout, uint32_t satelliteModules)
    {
        soProbe(103, "%s(\"%p\")\n", __func__, fout);

        require(simTime != UNDEF_TIME and stepCount != UNDEF_COUNT, "Module not in a valid open state!");
        require(submissionTime != UNDEF_TIME and runoutTime != UNDEF_TIME, "Module is not in a valid open state!");
        require(runningProcess != UNDEF_PID, "Module is not in a valid open state!");
        require(fout != NULL and fileno(fout) != -1, "fout must be a valid file stream");

        enum class ModuleMask : uint32_t {
            JDT = 1 << 0,
            PCT = 1 << 1,
            MEM = 1 << 2,
            RDY = 1 << 3,
            SWP = 1 << 4,
        };

        if ((satelliteModules & static_cast<uint32_t>(ModuleMask::JDT)) != 0) {
            jdtPrint(fout);
            fputc('\n', fout);
        }
        if ((satelliteModules & static_cast<uint32_t>(ModuleMask::PCT)) != 0) {
            pctPrint(fout);
            fputc('\n', fout);
        }
        if ((satelliteModules & static_cast<uint32_t>(ModuleMask::MEM)) != 0) {
            memPrint(fout);
            fputc('\n', fout);
        }
        if ((satelliteModules & static_cast<uint32_t>(ModuleMask::RDY)) != 0) {
            rdyPrint(fout);
            fputc('\n', fout);
        }
        if ((satelliteModules & static_cast<uint32_t>(ModuleMask::SWP)) != 0) {
            swpPrint(fout);
            fputc('\n', fout);
        }

        constexpr size_t RUNNING_PROCESS_STR_LEN{15};
        char running_process_str[RUNNING_PROCESS_STR_LEN]{};
        if (runningProcess == 0) {
            strncpy(running_process_str, "---", RUNNING_PROCESS_STR_LEN);
        } else {
            snprintf(
                running_process_str,
                RUNNING_PROCESS_STR_LEN,
                "%" PRIu16,
                runningProcess
            );
        }

        constexpr size_t SUBMISSION_TIME_STR_LEN{15};
        char submission_time_str[SUBMISSION_TIME_STR_LEN]{};
        if (submissionTime == NEVER) {
            strncpy(submission_time_str, "NEVER", SUBMISSION_TIME_STR_LEN);
        } else {
            snprintf(
                submission_time_str,
                SUBMISSION_TIME_STR_LEN,
                "%.1f",
                submissionTime
            );
        }

        constexpr size_t RUNOUT_TIME_STR_LEN{15};
        char runout_time_str[RUNOUT_TIME_STR_LEN]{};
        if (runoutTime == NEVER) {
            strncpy(runout_time_str, "NEVER", RUNOUT_TIME_STR_LEN);
        } else {
            snprintf(
                runout_time_str,
                RUNOUT_TIME_STR_LEN,
                "%.1f",
                runoutTime
            );
        }

        fprintf(
            fout,
            "+====================================================================================+\n"
            "+ -------------------------------- SIM Module State -------------------------------- +\n"
            "+====================================================================================+\n"
            "| simulation time |  step count  | running process | next submission |  next runout  |\n"
            "+-----------------+--------------+-----------------+-----------------+---------------+\n"
            "| %15.1f | %12" PRIu32 " | %15s | %15s | %13s |\n"
            "+====================================================================================+\n",
            simTime,
            stepCount,
            running_process_str,
            submission_time_str,
            runout_time_str
        );
    }

// ================================================================================== //

} // end of namespace group
