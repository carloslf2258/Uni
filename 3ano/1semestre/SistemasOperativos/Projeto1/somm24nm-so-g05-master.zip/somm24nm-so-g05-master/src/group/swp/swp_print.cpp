/*
 *  \author Rafael Claro
 *  \author Bruno Pereira
 */

#include <cstdio>
#include <cstddef>
#include <cinttypes>
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "swp.h"

namespace group
{

// ================================================================================== //

    void swpPrint(FILE *fout)
    {
        soProbe(603, "%s(%p)\n", __func__, fout);

        require(swappingPolicy == FIFO or swappingPolicy == FirstFit, "Module is not in a valid open state!");
        require(swpList != UNDEF_SWP_NODE and swpTail != UNDEF_SWP_NODE, "Module is not in a valid open state!");
        require(fout != NULL and fileno(fout) != -1, "fout must be a valid file stream");

        auto const policy_string{
            swappingPolicy == SwappingPolicy::FIFO
            ? "  (FIFO)  "
            : "(FirstFit)"
        };

        fprintf(
            fout,
            "+=====================+\n"
            "|  SWP Module State   |\n"
            "|     %s      |\n"
            "+-------+-------------+\n"
            "|  PID  | memory size |\n"
            "+-------+-------------+\n",
            policy_string
        );


        for (
            auto current{swpList};
            current != nullptr;
            current = current->next
        ) {
            fprintf(
                fout,
                "| %5" PRIu16 " | %#11" PRIx32 " |\n",
                current->process.pid,
                current->process.size
            );
        }

        fputs("+=====================+\n", fout);
    }

// ================================================================================== //

} // end of namespace group
