/*
 *  \author Bruno Pereira
 */

#include <cstdio>
#include <cinttypes>
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "rdy.h"

namespace group 
{

// ================================================================================== //

    void rdyPrint(FILE *fout)
    {
        soProbe(503, "%s(%p)\n", __func__, fout);

        require(schedulingPolicy == FCFS or schedulingPolicy == SPN, "Module is not in a valid open state!");
        require(rdyList != UNDEF_RDY_NODE and rdyTail != UNDEF_RDY_NODE, "Module is not in a valid open state!");
        require(fout != nullptr, "Output file stream must be valid!");

        fprintf(
            fout,
            "+====================+\n"
            "|  RDY Module State  |\n"
            "|       (%-5s       |\n"
            "+-------+------------+\n"
            "|  PID  |  lifetime  |\n"
            "+-------+------------+\n",
            schedulingPolicy == SchedulingPolicy::FCFS ? "FCFS)" : "SPN)"
        );

        for (
            auto current{rdyList};
            current != nullptr;
            current = current->next
        ) {
            auto [pid, lifetime]{current->process};
            fprintf(
                fout,
                "| %5" PRIu32 " | %10.1f |\n",
                pid,
                lifetime
            );
        }

        fputs("+====================+\n", fout);
    }

// ================================================================================== //

} // end of namespace group
