/*
 *  \author Rafael Claro
 */

#include "dbc.h"
#include "probing.h"
#include "pct.h"

namespace group 
{

    void pctTerm() 
    {
        soProbe(302, "%s()\n", __func__);

        require(pctList != UNDEF_PCT_NODE, "Module is not in a valid open state!");

        PctNode* current = pctList;

        while (current != nullptr) {
            PctNode* next = current->next;
            free(current);
            current = next;
        }

        pctList = UNDEF_PCT_NODE; // Reset to indicate the module is closed
    }

} // end of namespace group
