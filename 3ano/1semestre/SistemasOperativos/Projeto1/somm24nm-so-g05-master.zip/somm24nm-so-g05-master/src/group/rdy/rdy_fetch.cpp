/*
 *  \author Rafael Claro
 */

#include <cstdint>
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "rdy.h"

namespace group 
{

    uint16_t rdyFetch()
    {
        soProbe(505, "%s()\n", __func__);

        require(schedulingPolicy == FCFS or schedulingPolicy == SPN, "Module is not in a valid open state!");
        require(rdyList != UNDEF_RDY_NODE and rdyTail != UNDEF_RDY_NODE, "Module is not in a valid open state!");

        if (rdyList == nullptr) {
            return 0; // List is empty
        }

        RdyNode *nodeToRemove = rdyList;
        uint16_t pid = nodeToRemove->process.pid;

        rdyList = rdyList->next;
        if (rdyList == nullptr) {
            rdyTail = nullptr; // Update tail if the list becomes empty
        }

        free(nodeToRemove);
        return pid;
    }

// ================================================================================== //

} // end of namespace group
