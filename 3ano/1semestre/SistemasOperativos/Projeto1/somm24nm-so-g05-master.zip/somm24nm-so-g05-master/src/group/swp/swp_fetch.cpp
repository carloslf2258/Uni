/*
 *  \author Ricardo Carmo
 */

#include <cstdint>
#include <cstddef>
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "swp.h"

namespace group
{

// ================================================================================== //

    uint16_t swpFetch(uint32_t sizeAvailable)
    {
        soProbe(605, "%s(%#x)\n", __func__, sizeAvailable);

        require(swappingPolicy == FIFO or swappingPolicy == FirstFit, "Module is not in a valid open state!");
        require(swpList != UNDEF_SWP_NODE and swpTail != UNDEF_SWP_NODE, "Module is not in a valid open state!");

        SwpNode *current = swpList;

        // If the active policy is FIFO
        if (swappingPolicy == FIFO) {
            if (current != nullptr && current->process.size <= sizeAvailable) {
                uint16_t pid = current->process.pid;
                // Update list to the next node
                swpList = current->next;

                // If it was the only node, update tail
                if (swpList == nullptr) {
                    swpTail = nullptr;
                }

                // Free memory and return pid
                free(current);
                return pid;
            }
        // If the active policy is FirstFit
        } else if (swappingPolicy == FirstFit) {
            SwpNode *prev = nullptr; // To track the previous node

            while (current != nullptr) {
                // Check if the process fits in memory
                if (current->process.size <= sizeAvailable) {
                    uint16_t pid = current->process.pid;

                    // Update head if removing the first node
                    if (prev == nullptr) {
                        swpList = current->next;
                    } else {
                        prev->next = current->next;
                    }

                    // Update tail if removing the last node
                    if (swpTail == current) {
                        swpTail = prev;
                    }

                    // Free memory and return pid
                    free(current);
                    return pid;
                }

                // Move to the next node
                prev = current;
                current = current->next;
            }
        }

        return 0;
    }


// ================================================================================== //

} // end of namespace group
