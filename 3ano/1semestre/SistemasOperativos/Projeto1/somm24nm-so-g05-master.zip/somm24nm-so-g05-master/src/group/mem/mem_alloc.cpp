/*
 *  \author Rafael Claro
 *  \author Rúben Franco
 */

#include <cstdint>
#include "dbc.h"
#include "probing.h"
#include "mem.h"

namespace group 
{

// ================================================================================== //

    uint32_t memBiggestFreeBlockSize()
    {
        soProbe(406, "%s()\n", __func__);

        require(memAllocationPolicy != UndefMemoryAllocationPolicy, "Module is not in a valid open state!");
        require(memFreeList != UNDEF_MEM_NODE and memOccupiedList != UNDEF_MEM_NODE, "Module is not in a valid open state!");

        uint32_t biggestSize = 0;
        MemNode* currentNode = memFreeList;

        while (currentNode != nullptr) {
            auto const block_size{currentNode->block.size};
            if (block_size > biggestSize) {
                biggestSize = block_size;
            }
            currentNode = currentNode->next;
        }

        return biggestSize;
    }

// ================================================================================== //

    uint32_t memAlloc(uint32_t size)
    {
        soProbe(404, "%s(%#x)\n", __func__, size);

        require(memAllocationPolicy != UndefMemoryAllocationPolicy, "Module is not in a valid open state!");
        require(memFreeList != UNDEF_MEM_NODE and memOccupiedList != UNDEF_MEM_NODE, "Module is not in a valid open state!");

        auto const node{memRetrieveNodeFromFreeList(size, memAllocationPolicy)};
        memAddNodeToOccupiedList(node);
        return node->block.start;
    }

// ================================================================================== //

} // end of namespace group


