/*
 *  \author Rafael Claro
 *  \author Bruno Pereira
 *  \author Rúben Franco
 */

#include "somm24.h"

#include <cstdio>
#include <cinttypes>
#include <stdint.h>

namespace group 
{

// ================================================================================== //

    void memPrint(FILE *fout)
    {
        soProbe(403, "%s(\"%p\")\n", __func__, fout);

        require(memAllocationPolicy != UndefMemoryAllocationPolicy, "Module is not in a valid open state!");
        require(memFreeList != UNDEF_MEM_NODE and memOccupiedList != UNDEF_MEM_NODE, "Module is not in a valid open state!");
        require(fout != NULL and fileno(fout) != -1, "fout must be a valid file stream");

        fprintf(
            fout,
            "+===============================+\n"
            "|       MEM module state        |\n"
            "|          %9s)           |\n"
            "+-------------------------------+\n"
            "|         occupied list         |\n"
            "+---------------+---------------+\n"
            "|  start frame  |     size      |\n"
            "+---------------+---------------+\n",
            memAllocationPolicy == BestFit ? "(BestFit" : "(WorstFit"
        );

        MemNode* currentNode = memOccupiedList;
        while (currentNode != nullptr) {
            auto const& block{currentNode->block};
            fprintf(
                fout,
                "| %#13" PRIx32 " | %#13" PRIx32 " |\n",
                block.start,
                block.size
            );
            currentNode = currentNode->next;
        }

        fputs(
            "+---------------+---------------+\n"
            "|            free list          |\n"
            "+---------------+---------------+\n"
            "|  start frame  |     size      |\n"
            "+---------------+---------------+\n",
            fout
        );

        currentNode = memFreeList;
        while (currentNode != nullptr) {
            auto const& block{currentNode->block};
            fprintf(
                fout,
                "| %#13" PRIx32 " | %#13" PRIx32 " |\n",
                block.start,
                block.size
            );
            currentNode = currentNode->next;
        }

        fputs("+===============================+\n", fout);
    }

// ================================================================================== //

} // end of namespace group
