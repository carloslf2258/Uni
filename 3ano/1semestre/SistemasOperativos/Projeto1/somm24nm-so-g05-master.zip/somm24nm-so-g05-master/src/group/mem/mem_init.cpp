/*
 *  \author Ricardo Carmo
 */

#include <cstdlib>
#include <cstdint>
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "mem.h"

namespace group 
{

// ================================================================================== //

    void memInit(uint32_t memSize, uint32_t memKernelSize, MemoryAllocationPolicy policy)
    {
        const char *pas;
        switch (policy)
        {
            case UndefMemoryAllocationPolicy: pas = "UndefMemoryAllocationPolicy"; break;
            case BestFit: pas = "BestFit"; break;
            case WorstFit: pas = "WorstFit"; break;
            default: pas = "InvalidPattern"; break;
        }
        soProbe(401, "%s(%#x, %#x, %s)\n", __func__, memSize, memKernelSize, pas);

        require(memAllocationPolicy == UndefMemoryAllocationPolicy, "Module is not in a valid closed state!");
        require(memFreeList == UNDEF_MEM_NODE and memOccupiedList == UNDEF_MEM_NODE, "Module is not in a valid closed state!");
        require(memSize > memKernelSize, "total memory size must be bigger than the one use by the kernel of OS");
        require(policy == BestFit or policy == WorstFit, "policy must be BestFit or WorstFit");

        auto const free_list_init{static_cast<MemNode*>(malloc(sizeof(MemNode)))};
        if (free_list_init == nullptr) {
            throw Exception(ENOSYS, "Failed to allocate memory for FreeListInit in mem_init.cpp");
        }
        *free_list_init = MemNode{
            .block{
                .start{memKernelSize},
                .size{memSize - memKernelSize},
            },
            .next{nullptr},
        };

        memAllocationPolicy = policy;
        memFreeList = free_list_init;
        memOccupiedList = nullptr;
    }

// ================================================================================== //

} // end of namespace group
