/*
 *  \author Rafael Claro
 *  \author Rúben Franco
*/
#include <cstdlib>
#include <cerrno>
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "swp.h"

namespace group
{

// ================================================================================== //

    void swpInsert(uint16_t pid, uint32_t size)
    {
        soProbe(604, "%s(%hu, %u)\n", __func__, pid, size);

        // Garantir que o módulo esteja em um estado válido
        require(swappingPolicy == FIFO or swappingPolicy == FirstFit, "Module is not in a valid open state!");
        require(swpList != UNDEF_SWP_NODE and swpTail != UNDEF_SWP_NODE, "Module is not in a valid open state!");
        require(pid != 0, "A valid process ID must be greater than zero");

        // Criar um novo nó para o processo
        SwpNode *newNode = (SwpNode *)malloc(sizeof(SwpNode));
        if (newNode == nullptr)
        {
            throw Exception(errno, __func__);
        }

        // Inicializar os dados do processo no novo nó
        *newNode = SwpNode{
            .process{
                .pid{pid},
                .size{size}
            },
            .next{nullptr},
        };

        // Inserir no final da lista
        if (swpTail == nullptr) // Caso especial: lista está vazia
        {
            swpList = newNode;
        }
        else
        {
            swpTail->next = newNode; // Conectar o nó ao final da lista
        }
        swpTail = newNode;       // Atualizar o ponteiro do "tail"
    }

// ================================================================================== //

} // end of namespace group
