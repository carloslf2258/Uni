/*
 *  \author Diogo Couto
 *  \author Rúben Franco
 */

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cinttypes>
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "sim.h"

namespace {
    enum class ParserState {
        READING_PAIRS,
        SKIPPING,
    };
}

namespace group
{
// ================================================================================== //

    void simConfig(FILE *fin, SimParameters *spp)
    {
        soProbe(104, "%s(\"%p\")\n", __func__, fin);

        require(simTime == UNDEF_TIME and stepCount == UNDEF_COUNT, "Module is not in a valid closed state!");
        require(submissionTime == UNDEF_TIME and runoutTime == UNDEF_TIME, "Module is not in a valid closed state!");
        require(runningProcess == UNDEF_PID, "Module is not in a valid closed state!");
        require(fin != nullptr and fileno(fin) != -1, "fin must be a valid file stream");
        require(spp != nullptr, "spp must be a valid pointer");

        auto any_error{false};

        auto parser_state{ParserState::READING_PAIRS};
        while (!feof(fin)) {
            errno = 0;
            std::size_t len{};
            char* line{};
            auto const ref{
                getline(&line, &len, fin)
            };
            if (ref == -1) {
                if (errno != 0) {
                    throw Exception(errno, __func__);
                } else {
                    break;
                }
            }
            *strchrnul(line, '\n') = '\0';
            *strchrnul(line, '#') = '\0';

            switch (parser_state) {
                case ParserState::READING_PAIRS: {
                    char* key{};
                    char* value{};
                    int64_t len{};
                    int64_t should_be_zero{};
                    auto const ret{sscanf(
                        line, " %ms = %ms%ln %*c %ln",
                        &key,
                        &value,
                        &len,
                        &should_be_zero
                    )};

                    // Not assignment
                    if (ret <= 1) {
                        if (ret == 1) {
                            free(key);
                        }

                        {
                            int64_t before_space{};
                            int64_t after_space{};
                            int64_t after_jobs{};
                            int64_t char_after_statement{};
                            sscanf(
                                line,
                                " End%ln %lnJobs%ln %*c %ln",
                                &before_space,
                                &after_space,
                                &after_jobs,
                                &char_after_statement
                            );

                            // Didn't even parse "Begin"
                            if (before_space == 0 || after_jobs == 0) {
                                goto parse_begin_line;
                            }

                            check(before_space == 0 || after_space != 0, "should consume whitespace");


                            if (after_space - before_space != 1) {
                                fputs(
                                    "\"End\" is not followed by a single whitespace character\n",
                                    stderr
                                );
                                any_error = true;
                                free(line);
                                continue;
                            }


                            if (char_after_statement != 0) {
                                fputs(
                                    "\"End Jobs\" statement followed by non whitespace characters\n",
                                    stderr
                                );
                                any_error = true;
                                free(line);
                                continue;
                            }

                            fputs(
                                "\"End Jobs\" statement before a \"Begin Jobs\" statement\n",
                                stderr
                            );
                            any_error = true;
                            free(line);
                            continue;
                        }

                        // cmon man
                        parse_begin_line:
                        int64_t before_space{};
                        int64_t after_space{};
                        int64_t after_jobs{};
                        int64_t char_after_statement{};
                        sscanf(
                            line,
                            " Begin%ln %lnJobs%ln %*c %ln",
                            &before_space,
                            &after_space,
                            &after_jobs,
                            &char_after_statement
                        );

                        // Didn't even parse "Begin"
                        if (before_space == 0 || after_jobs == 0) {
                            free(line);
                            continue;
                        }

                        check(before_space == 0 || after_space != 0, "should consume whitespace");


                        if (after_space - before_space != 1) {
                            fputs(
                                "\"Begin\" is not followed by a single whitespace character\n",
                                stderr
                            );
                            any_error = true;
                            free(line);
                            continue;
                        }


                        if (char_after_statement != 0) {
                            fputs(
                                "\"Begin Jobs\" statement followed by non whitespace characters\n",
                                stderr
                            );
                            any_error = true;
                            free(line);
                            continue;
                        }

                        parser_state = ParserState::SKIPPING;
                        free(line);
                        continue;
                    }

                    free(line);

                    // Assignment
                    if (should_be_zero != 0) {
                        fputs(
                            "Non whitespace characters found after assignment\n",
                            stderr
                        );
                        free(key);
                        free(value);
                        any_error = true;
                        continue;
                    }

                    if (strcmp(key, "PIDStart") == 0) {
                        free(key);

                        auto const ret{
                            sscanf(value, "%" SCNu16, &spp->pidStart)
                        };
                        free(value);

                        if (ret < 1) {
                            fputs(
                                "Value given for \"PIDStart\" is invalid\n",
                                stderr
                            );
                            any_error = true;
                            continue;
                        }
                    } else if (strcmp(key, "PIDRandomSeed") == 0) {
                        free(key);

                        auto const ret{
                            sscanf(value, "%" SCNu32, &spp->pidRandomSeed)
                        };
                        free(value);

                        if (ret < 1) {
                            fputs(
                                "Value given for \"PIDRandomSeed\" is invalid\n",
                                stderr
                            );
                            any_error = true;
                            continue;
                        }
                    } else if (strcmp(key, "MemorySize") == 0) {
                        free(key);

                        auto const ret{
                            sscanf(value, "%" SCNx32, &spp->memorySize)
                        };
                        free(value);

                        if (ret < 1) {
                            fputs(
                                "Value given for \"MemorySize\" is invalid\n",
                                stderr
                            );
                            any_error = true;
                            continue;
                        }
                    } else if (strcmp(key, "MemoryKernelSize") == 0) {
                        free(key);

                        auto const ret{
                            sscanf(value, "%" SCNx32, &spp->memoryKernelSize)
                        };
                        free(value);

                        if (ret < 1) {
                            fputs(
                                "Value given for \"MemoryKernelSize\" is invalid\n",
                                stderr
                            );
                            any_error = true;
                            continue;
                        }
                    } else if (strcmp(key, "MemoryAllocationPolicy") == 0) {
                        free(key);

                        if (strcmp(value, "WorstFit") == 0) {
                            spp->memoryAllocPolicy = MemoryAllocationPolicy::WorstFit;
                        } else if (strcmp(value, "BestFit") == 0) {
                            spp->memoryAllocPolicy = MemoryAllocationPolicy::BestFit;
                        } else {
                            fputs(
                                "Value given for \"MemoryAllocationPolicy\" is invalid\n",
                                stderr
                            );
                            any_error = true;
                            free(value);
                            continue;
                        }
                        free(value);
                    } else if (strcmp(key, "SchedulingPolicy") == 0) {
                        free(key);

                        if (strcmp(value, "FCFS") == 0) {
                            spp->schedulingPolicy = SchedulingPolicy::FCFS;
                        } else if (strcmp(value, "SPN") == 0) {
                            spp->schedulingPolicy = SchedulingPolicy::SPN;
                        } else {
                            fputs(
                                "Value given for \"SchedulingPolicy\" is invalid",
                                stderr
                            );
                            any_error = true;
                            free(value);
                            continue;
                        }
                        free(value);
                    } else if (strcmp(key, "SwappingPolicy") == 0) {
                        free(key);

                        if (strcmp(value, "FIFO") == 0) {
                            spp->swappingPolicy = SwappingPolicy::FIFO;
                        } else if (strcmp(value, "FirstFit") == 0) {
                            spp->swappingPolicy = SwappingPolicy::FirstFit;
                        } else {
                            fputs(
                                "Value given for \"SwappingPolicy\" is invalid\n",
                                stderr
                            );
                            any_error = true;
                            free(value);
                            continue;
                        }
                    } else if (strcmp(key, "JobMaxSize") == 0) {
                        free(key);

                        auto const ret{
                            sscanf(value, "%" SCNx32, &spp->jobMaxSize)
                        };
                        free(value);

                        if (ret < 1) {
                            fputs(
                                "Value given for \"JobMaxSize\" is invalid\n",
                                stderr
                            );
                            any_error = true;
                            continue;
                        }
                    } else if (strcmp(key, "JobCount") == 0) {
                        free(key);

                        auto const ret{
                            sscanf(value, "%" SCNu16, &spp->jobCount)
                        };
                        free(value);

                        if (ret < 1) {
                            fputs(
                                "Value given for \"JobCount\" is invalid\n",
                                stderr
                            );
                            any_error = true;
                            continue;
                        }
                    } else if (strcmp(key, "JobRandomSeed") == 0) {
                        free(key);

                        auto const ret{
                            sscanf(value, "%" SCNu32, &spp->jobRandomSeed)
                        };
                        free(value);

                        if (ret < 1) {
                            fputs(
                                "Value given for \"JobRandomSeed\" is invalid\n",
                                stderr
                            );
                            any_error = true;
                            free(value);
                            continue;
                        }
                    } else {
                        free(key);
                        free(value);

                        fputs(
                            "Unknown key given",
                            stderr
                        );
                        any_error = true;
                    }
                } break;

                case ParserState::SKIPPING: {
                    int64_t before_space{};
                    int64_t after_space{};
                    int64_t after_jobs{};
                    int64_t char_after_statement{};
                    sscanf(
                        line,
                        " End%ln %lnJobs%ln %*c %ln",
                        &before_space,
                        &after_space,
                        &after_jobs,
                        &char_after_statement
                    );

                    // Didn't even parse "Begin"
                    if (before_space == 0 || after_jobs == 0) {
                        free(line);
                        continue;
                    }

                    check(before_space == 0 || after_space != 0, "should consume whitespace");

                    if (after_space - before_space != 1) {
                        fputs(
                            "\"End\" is not followed by a single whitespace character\n",
                            stderr
                        );
                        any_error = true;
                        free(line);
                        continue;
                    }


                    if (char_after_statement != 0) {
                        fputs(
                            "\"End Jobs\" statement followed by non whitespace characters\n",
                            stderr
                        );
                        any_error = true;
                        free(line);
                        continue;
                    }

                    free(line);
                    parser_state = ParserState::READING_PAIRS;
                    continue;
                } break;
            }
        }

        if (parser_state == ParserState::SKIPPING) {
            fputs("\"Begin Jobs\" statement was not finished by a \"End Jobs\" statement\n", stderr);
            any_error = true;
        }

        if (any_error) {
            throw Exception(EINVAL, __func__);
        }

        if (spp->memoryKernelSize > spp->memorySize) {
            fputs("Value for \"memoryKernelSize\" must not be larget than \"memorySize\"", stderr);
            throw Exception(EINVAL, __func__);
        }

        if (spp->pidStart == 0) {
            fputs("\"PIDStart\" must not be 0", stderr);
            throw Exception(EINVAL, __func__);
        }

        if (spp->jobCount == 0) {
            spp->jobLoadStream = fin;
        }

        fseek(fin, 0, SEEK_SET);
// ================================================================================== //
    } 
}  // end of namespace group
