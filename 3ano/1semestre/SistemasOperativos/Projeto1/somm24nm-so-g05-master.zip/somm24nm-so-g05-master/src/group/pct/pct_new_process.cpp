/*
 *  \author Carlos Verenzuela
 */

#include <cerrno>
#include <cstdint>
#include <cstring>
#include "exception.h"
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "pct.h"

namespace group
{

// ================================================================================== //

    uint16_t pctNewProcess(double admissionTime, double lifetime, uint32_t memSize)
    {
        soProbe(304, "%s(%0.1f, %0.1f, %#x)\n", __func__, admissionTime, lifetime, memSize);

        require(pctList != UNDEF_PCT_NODE, "Module is not in a valid open state!");
        require(admissionTime >= 0, "Bad admission time");
        require(lifetime > 0, "Bad lifetime");
        require(memSize > 0, "Bad memory size");

        // Static variable para armazenar o próximo PID disponível
        static uint16_t nextPIDIndex = 0;

        // Garantir que há PIDs disponíveis
        require(nextPIDIndex < MAX_JOBS && pctPID[nextPIDIndex] != 0, "No more valid PIDs available");

        // Obter o próximo PID válido
        uint16_t pid = pctPID[nextPIDIndex];
        pctPID[nextPIDIndex] = 0;       // Remover o PID da lista
        nextPIDIndex++;         // Atualizar o índice

        // Criar o novo nó
        auto const newNode = static_cast<PctNode*>(malloc(sizeof (PctNode)));
        if (newNode == nullptr) {
            throw Exception(errno, __func__);
        }
        *newNode = PctNode{
            .pcb{
                .pid{pid},
                .state{ProcessState::NEW},
                .admissionTime{admissionTime},
                .lifetime{lifetime},
                .storeTime{UNDEF_TIME},
                .startTime{UNDEF_TIME},
                .finishTime{UNDEF_TIME},
                .memStart{UNDEF_ADDRESS},
                .memSize{memSize},
            },
            .next{nullptr},
        };

        // Inserir o novo nó na lista ligada, mantendo a ordem crescente de PID
        // if (pctList == nullptr) // Lista vazia
        // {
        //     pctList = newNode;
        // } else {
        PctNode* current = pctList;
        PctNode* previous = nullptr;

        // Procurar o local correto para inserir o novo nó
        while (current != nullptr && current->pcb.pid < pid)
        {
            previous = current;
            current = current->next;
        }

        newNode->next = current;
        if (previous == nullptr) // Inserir no início
        {
            pctList = newNode;
        }
        else // Inserir no meio ou no final
        {
            previous->next = newNode;
        }
        // }

        // Retornar o PID do processo recém-criado
        return pid;
    }

// ================================================================================== //

} // end of namespace group
