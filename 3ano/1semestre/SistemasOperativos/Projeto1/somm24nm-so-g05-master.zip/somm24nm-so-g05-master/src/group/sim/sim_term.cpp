/*
 *  \author Rafael Claro
 *  \author Rúben Franco
 */

#include "dbc.h"
#include "probing.h"
#include "sim.h"
#include "jdt.h"
#include "pct.h"
#include "mem.h"
#include "rdy.h"
#include "swp.h"

namespace group 
{

// ================================================================================== //

    void simTerm() 
    {
        soProbe(102, "%s()\n", __func__);

        require(simTime != UNDEF_TIME and stepCount != UNDEF_COUNT, "Module not in a valid open state!");
        require(submissionTime != UNDEF_TIME and runoutTime != UNDEF_TIME, "Module is not in a valid open state!");
        require(runningProcess != UNDEF_PID, "Module is not in a valid open state!");

        // Limpar recursos específicos da simulação, se houver
        jdtTerm();
        pctTerm();
        memTerm();
        rdyTerm();
        swpTerm();

        // Reinicializar variáveis globais para seus estados indefinidos
        simTime = UNDEF_TIME;
        stepCount = UNDEF_COUNT;
        submissionTime = UNDEF_TIME;
        runoutTime = UNDEF_TIME;
        runningProcess = UNDEF_PID;
    }

// ================================================================================== //

} // end of namespace group
