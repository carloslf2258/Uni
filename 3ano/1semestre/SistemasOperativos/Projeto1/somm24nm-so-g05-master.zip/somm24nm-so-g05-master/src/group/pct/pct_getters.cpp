/*
 *  \author Diogo Couto
 */

#include <cstdint>
#include "dbc.h"
#include "probing.h"
#include "pct.h"

namespace {
    auto find_first_node_with_pid(uint16_t const pid) -> PctNode const* {
        for (
            auto current{pctList};
            current != nullptr;
            current = current->next
        ) {
            if (current->pcb.pid == pid)  {
                return current;
            }
        }
        throw Exception(EINVAL, __func__);
    }
}

namespace group
{
    /* ======================================================================== */

    double pctLifetime(uint16_t pid)
    {
        soProbe(305, "%s(%u)\n", __func__, pid);

        require(pctList != UNDEF_PCT_NODE, "The PCT linked list must exist");
        require(pid > 0, "a valid process ID must be greater than zero");

        return find_first_node_with_pid(pid)->pcb.lifetime;
    }

    /* ======================================================================== */

    uint32_t pctMemSize(uint16_t pid)
    {
        soProbe(306, "%s(%u)\n", __func__, pid);

        require(pctList != UNDEF_PCT_NODE, "The PCT linked list must exist");
        require(pid > 0, "a valid process ID must be greater than zero");

        return find_first_node_with_pid(pid)->pcb.memSize;
    }

    /* ======================================================================== */

    uint32_t pctMemAddress(uint16_t pid)
    {
        soProbe(307, "%s(%u)\n", __func__, pid);

        require(pctList != UNDEF_PCT_NODE, "The PCT linked list must exist");
        require(pid > 0, "a valid process ID must be greater than zero");

        return find_first_node_with_pid(pid)->pcb.memStart;
    }

    /* ======================================================================== */

} // end of namespace somm22
