/*
 *  \author Ricardo Carmo
 */

#include <cstdio>
#include <ctime>
#include <unistd.h>
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "sim.h"
#include "jdt.h"
#include "pct.h"
#include "mem.h"
#include "rdy.h"
#include "swp.h"


namespace group
{

// ================================================================================== //

void simInit(FILE *fin)
{
    soProbe(101, "%s(%p)\n", __func__, fin);

    // Validar estado inicial do módulo
    require(simTime == UNDEF_TIME && stepCount == UNDEF_COUNT, "Module is not in a valid closed state!");
    require(submissionTime == UNDEF_TIME && runoutTime == UNDEF_TIME, "Module is not in a valid closed state!");
    require(runningProcess == UNDEF_PID, "Module is not in a valid closed state!");
    require(fin == nullptr || fileno(fin) != -1, "fin must be NULL or a valid file pointer");

    // Parâmetros padrão
    SimParameters simP{
        .jobLoadStream{nullptr},
        .jobMaxSize{0x10000},
        .jobRandomSeed{UNDEF_SEED},
        .jobCount{0},
        .pidStart{1001},
        .pidRandomSeed{UNDEF_SEED},
        .memorySize{0x100000},
        .memoryKernelSize{0x10000},
        .memoryAllocPolicy{MemoryAllocationPolicy::WorstFit},
        .schedulingPolicy{SchedulingPolicy::FCFS},
        .swappingPolicy{SwappingPolicy::FIFO},
    };

    // Configuração a partir do arquivo
    if (fin != nullptr) {
        simConfig(fin, &simP);
    }

    if (simP.jobRandomSeed == UNDEF_SEED || simP.jobRandomSeed == 0) {
        simP.jobRandomSeed = getpid();
    }

    if (simP.pidRandomSeed == UNDEF_SEED) {
        simP.pidRandomSeed = time(NULL);
    }

    // Inicializar os  módulos 
    jdtInit();
    memInit(simP.memorySize, simP.memoryKernelSize, simP.memoryAllocPolicy);

    // Carregar os jobs
    if (simP.jobLoadStream == nullptr) {
        fputs("random fill\n", stderr);
        simP.jobCount = jdtRandomFill(simP.jobRandomSeed, simP.jobCount, simP.jobMaxSize);
    } else {
        fputs("load fill\n", stderr);
        simP.jobCount = jdtLoad(simP.jobLoadStream, simP.jobMaxSize);
    }

    
    pctInit(simP.pidStart, simP.jobCount, simP.pidRandomSeed);
    rdyInit(simP.schedulingPolicy);
    swpInit(simP.swappingPolicy);

    // Configurar as variáveis globais
    stepCount = 0;
    simTime = 0.0;
    submissionTime = jdtNextSubmission();
    runoutTime = NEVER;
    runningProcess = 0;
}

// ================================================================================== //

} // namespace group
