/*
 *  \author Rúben Franco
 */

#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "sim.h"
#include "jdt.h"
#include "pct.h"
#include "mem.h"
#include "rdy.h"
#include "swp.h"

namespace group
{

// ================================================================================== //

    bool simStep()
    {
        soProbe(105, "%s()\n", __func__);

        require(simTime != UNDEF_TIME and stepCount != UNDEF_COUNT, "Module not in a valid open state!");
        require(submissionTime != UNDEF_TIME and runoutTime != UNDEF_TIME, "Module is not in a valid open state!");
        require(runningProcess != UNDEF_PID, "Module is not in a valid open state!");

        auto status{false};
        if (
            submissionTime != NEVER
            && (runoutTime == NEVER || submissionTime < runoutTime)
        ) {
            check(
                jdtNextSubmission() == submissionTime,
                "Submission time must be equal to next submission time"
            );

            simTime = submissionTime;

            auto const next_job{jdtFetchNext()};

            auto const new_pid{pctNewProcess(
                next_job.submissionTime,
                next_job.lifetime,
                next_job.memSize
            )};

            if (next_job.memSize < memBiggestFreeBlockSize()) {
                auto const mem_address{memAlloc(next_job.memSize)};
                rdyInsert(new_pid, next_job.lifetime);
                pctUpdateState(
                    new_pid,
                    ProcessState::READY,
                    simTime,
                    mem_address
                );
            } else {
                swpInsert(new_pid, next_job.memSize);
                pctUpdateState(new_pid, ProcessState::SWAPPED);
            }

            submissionTime = jdtNextSubmission();
            status = true;
        } else if (runoutTime != NEVER) {
            simTime = runoutTime;

            memFree(pctMemAddress(runningProcess));
            pctUpdateState(runningProcess, ProcessState::TERMINATED, simTime);
            runningProcess = 0;

            for (
                auto process_to_load(swpFetch(memBiggestFreeBlockSize()));
                process_to_load != 0;
                process_to_load = swpFetch(memBiggestFreeBlockSize())
            ) {
                auto const mem_address{memAlloc(pctMemSize(process_to_load))};
                rdyInsert(process_to_load, pctLifetime(process_to_load));
                pctUpdateState(
                    process_to_load,
                    ProcessState::READY,
                    simTime,
                    mem_address
                );
            }

            status = true;
        }

        if (runningProcess == 0) {
            runningProcess = rdyFetch();
            if (runningProcess != 0) {
                runoutTime = simTime + pctLifetime(runningProcess);
                pctUpdateState(
                    runningProcess,
                    ProcessState::RUNNING,
                    simTime
                );
                status = true;
            } else {
                runoutTime = NEVER;
            }
        }

        stepCount += static_cast<decltype(stepCount)>(status);
        return status;
    }

// ================================================================================== //

} // end of namespace group

