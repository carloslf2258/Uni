/*
 *  \author Rúben Franco
 */

#include <cstdio>
#include <cinttypes>
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "jdt.h"

namespace group 
{

// ================================================================================== //

    void jdtPrint(FILE *fout)
    {
        soProbe(203, "%s(%p)\n", __func__, fout);

        require(jdtIn != UNDEF_JOB_INDEX and jdtOut != UNDEF_JOB_INDEX, "Module is not in a valid open state!");
        require(jdtCount != UNDEF_JOB_COUNT, "Module is not in a valid open state!");
        require(fout != NULL and fileno(fout) != -1, "fout must be a valid file stream");

        fputs(
            "+=====================================+\n"
            "|          JDT module state           |\n"
            "+------------+------------+-----------+\n"
            "| submission |  lifetime  |  memory   |\n"
            "|    time    |            | requested |\n"
            "+------------+------------+-----------+\n",
            fout
        );

        for (uint32_t i{jdtOut}; i != jdtIn; i = (i + 1) % MAX_JOBS) {
            auto const& job{jdtTable[i]};
            fprintf(
                fout,
                "| %10.1f | %10.1f | %#9" PRIx32 " |\n",
                job.submissionTime,
                job.lifetime,
                job.memSize
            );
        }
        fputs("+=====================================+\n", fout);
    }

// ================================================================================== //

} // end of namespace group
