/*
 *  \author Diogo Couto
 */

#include "somm24.h"

#include <stdint.h>

namespace group 
{

// ================================================================================== //

    void memAddNodeToFreeList(MemNode *p)
    {
        soProbe(407, "%s(%p)\n", __func__, p);

        require(memAllocationPolicy != UndefMemoryAllocationPolicy, "Module is not in a valid open state!");
        require(memFreeList != UNDEF_MEM_NODE and memOccupiedList != UNDEF_MEM_NODE, "Module is not in a valid open state!");
        require(p != nullptr, "p must be a valid pointer");


        if (memFreeList == nullptr)
        {
            memFreeList = p;
            p->next = nullptr;
        }
        else
        {

            MemNode *curr = memFreeList;
            MemNode *prev = nullptr;


            while (curr != nullptr && curr->block.start < p->block.start)
            {
                prev = curr;
                curr = curr->next;
            }

            if (prev == nullptr)
            {
                memFreeList = p;
            }
            else
            {
                prev->next = p;
            }
            p->next = curr;
        }

        /* ----------------------------------------------------------*/

        MemNode *prevNode = nullptr;
        MemNode *currNode = memFreeList;


        while (currNode != nullptr && currNode != p)
        {
            prevNode = currNode;
            currNode = currNode->next;
        }

        if (prevNode != nullptr)
        {
            uint32_t endPrev = prevNode->block.start + prevNode->block.size;
            if (endPrev == p->block.start)
            {
                prevNode->block.size += p->block.size;
                prevNode->next = p->next;
                p = prevNode; 
            }
        }

        MemNode *nextNode = p->next;
        if (nextNode != nullptr)
        {
            uint32_t endP = p->block.start + p->block.size;
            if (endP == nextNode->block.start)
            {
                p->block.size += nextNode->block.size;
                p->next = nextNode->next;

                /* free(nextNode); */
            }
        }




        //throw Exception(ENOSYS, __func__);
    }

// ================================================================================== //

    void memAddNodeToOccupiedList(MemNode *p)
    {
        soProbe(408, "%s(%p)\n", __func__, p);

        require(memAllocationPolicy != UndefMemoryAllocationPolicy, "Module is not in a valid open state!");
        require(memFreeList != UNDEF_MEM_NODE and memOccupiedList != UNDEF_MEM_NODE, "Module is not in a valid open state!");
        require(p != nullptr, "p must be a valid pointer");

        if (memOccupiedList == nullptr)
        {
            memOccupiedList = p;
            p->next = nullptr;
        }
        else
        {
            MemNode *curr = memOccupiedList;
            MemNode *prev = nullptr;

            while (curr != nullptr && curr->block.start < p->block.start)
            {
                prev = curr;
                curr = curr->next;
            }

            if (prev == nullptr)
            {
                p->next = memOccupiedList;
                memOccupiedList = p;
            }
            else
            {
                p->next = curr;
                prev->next = p;
            }
        }

        //throw Exception(ENOSYS, __func__);
    }

// ================================================================================== //

} // end of namespace group

