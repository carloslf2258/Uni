/*
 *  \author Rafael Claro
 *  \author Diogo Couto
 *  \author Rúben Franco
 */

#include "dbc.h"
#include "probing.h"
#include "mem.h"

namespace group 
{

// ================================================================================== //

    void memFree(uint32_t address)
    {
        soProbe(405, "%s(%#x)\n", __func__, address);

        require(memAllocationPolicy != UndefMemoryAllocationPolicy, "Module is not in a valid open state!");
        require(memFreeList != UNDEF_MEM_NODE and memOccupiedList != UNDEF_MEM_NODE, "Module is not in a valid open state!");

        auto const node{memRetrieveNodeFromOccupiedList(address)};
        memAddNodeToFreeList(node);
    }

// ================================================================================== //

} // end of namespace group


