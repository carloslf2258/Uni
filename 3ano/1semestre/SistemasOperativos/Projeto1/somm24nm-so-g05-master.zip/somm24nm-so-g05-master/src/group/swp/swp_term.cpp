/*
 *  \author ...
 *  \author Rúben Franco
 */

#include <cstdlib>
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "swp.h"

namespace group
{

// ================================================================================== //

    void swpTerm()
    {
        soProbe(602, "%s()\n", __func__);

        // Garantir que o módulo esteja em um estado válido
        require(swappingPolicy == FIFO or swappingPolicy == FirstFit, "Module is not in a valid open state!");
        require(swpList != UNDEF_SWP_NODE and swpTail != UNDEF_SWP_NODE, "Module is not in a valid open state!");

        // Liberar todos os nós da lista
        SwpNode *current = swpList;
        while (current != nullptr)
        {
            SwpNode *toDelete = current;
            current = current->next;
            free(toDelete);
        }

        // Resetar ponteiros globais
        swpList = UNDEF_SWP_NODE;
        swpTail = UNDEF_SWP_NODE;
    }

// ================================================================================== //

} // end of namespace group
