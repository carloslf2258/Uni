/*
 *  \author Rafael Claro
 */

#include <cstdint>
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "pct.h"

namespace group 
{

    void pctUpdateState(uint16_t pid, ProcessState state, double time = UNDEF_TIME, uint32_t address = UNDEF_ADDRESS)
    {
        bool validState = true;
        const char *sas = "UNKNOWN";
        switch (state) {
            case NEW: sas = "NEW"; break;
            case RUNNING: sas = "RUNNING"; break;
            case READY: sas = "READY"; break;
            case SWAPPED: sas = "SWAPPED"; break;
            case TERMINATED: sas = "TERMINATED"; break;
            default: validState = false; break;
        }
        soProbe(308, "%s(%hu, %s, %.1f, %#x)\n", __func__, pid, sas, time, address);

        require(pctList != UNDEF_PCT_NODE, "Module is not in valid open state");
        require(pid != 0, "PID can't be zero");
        require(state != NEW, "On updating, state cannot be NEW");
        require(validState, "Wrong state value");

        for (
            PctNode* current{pctList}; 
            current != nullptr; 
            current = current->next
        ) {
            if (current->pcb.pid == pid) {
                current->pcb.state = state;
                
                switch (state) {
                    case ProcessState::TERMINATED:
                        require(time != UNDEF_TIME, "Finish time must be defined for TERMINATED state");
                        current->pcb.finishTime = time;
                        break;
                    case ProcessState::RUNNING:
                        require(time != UNDEF_TIME, "Start time must be defined for RUNNING state");
                        current->pcb.startTime = time;
                        break;
                    case ProcessState::READY:
                        require(time != UNDEF_TIME, "Store time must be defined for READY state");
                        require(address != UNDEF_ADDRESS, "Memory address must be defined for READY state");
                        current->pcb.storeTime = time;
                        current->pcb.memStart = address;
                        break;
                    default:
                        break;
                }
                return;
            }
        }

        throw Exception(EINVAL, __func__);
    }

} // end of namespace group
