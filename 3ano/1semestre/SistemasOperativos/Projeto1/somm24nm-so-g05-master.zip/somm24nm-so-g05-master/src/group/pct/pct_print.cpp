
/*
 *  \author Rafael Claro
 *  \author Rúben Franco
 */

#include <cinttypes>
#include <cstdio>
#include <cstring>
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "pct.h"

namespace group 
{

    void pctPrint(FILE *fout)
    {
        soProbe(303, "%s(%p)\n", __func__, fout);

        require(pctList != UNDEF_PCT_NODE, "Module is not in a valid open state!");
        require(fout != NULL and fileno(fout) != -1, "fout must be a valid file stream");

        fputs(
            "+======================================================================================================================+\n"
            "|                                                   PCT module state                                                   |\n"
            "+-------+-------------+-------------+-------------+------------+------------+-------------+--------------+-------------+\n"
            "|  PID  |    state    |  admission  |  lifetime   | store time | start time | finish time | memory start | memory size |\n"
            "+-------+-------------+-------------+-------------+------------+------------+-------------+--------------+-------------+\n",
            fout
        );
        for (
            auto current{pctList}; 
            current != nullptr; 
            current = current->next
        ) {
            const PctBlock& pcb = current->pcb;

            char const* const state_name{
                pcb.state == ProcessState::NEW
                ? "NEW"
                : pcb.state == ProcessState::RUNNING
                ? "RUNNING"
                : pcb.state == ProcessState::READY
                ? "READY"
                : pcb.state == ProcessState::SWAPPED
                ? "SWAPPED"
                : pcb.state == ProcessState::TERMINATED
                ? "TERMINATED"
                : nullptr
            };
            require(
                state_name != nullptr,
                "process state must be valid"
            );

            size_t constexpr STORE_TIME_STR_LEN{10};
            char store_time_str[STORE_TIME_STR_LEN]{};
            if (pcb.storeTime == UNDEF_TIME) {
                strncpy(store_time_str, "UNDEF", STORE_TIME_STR_LEN);
            } else {
                auto const num_written{snprintf(
                        store_time_str,
                        STORE_TIME_STR_LEN,
                        "%.1f",
                        pcb.storeTime
                )};
                check(
                    num_written < static_cast<int>(STORE_TIME_STR_LEN),
                    "couldn't write \"storeTime\" to buffer"
                );
            }

            size_t constexpr START_TIME_STR_LEN{10};
            char start_time_str[START_TIME_STR_LEN]{};
            if (pcb.startTime == UNDEF_TIME) {
               strncpy(start_time_str, "UNDEF", START_TIME_STR_LEN);
            } else {
                auto const num_written{snprintf(
                    start_time_str,
                    START_TIME_STR_LEN,
                    "%.1f",
                    pcb.startTime
                )};
                check(
                    num_written < static_cast<int>(START_TIME_STR_LEN),
                    "couldn't write \"startTime\" to buffer"
                );
            }

            size_t constexpr FINISH_TIME_STR_LEN{11};
            char finish_time_str[FINISH_TIME_STR_LEN]{};
            if (pcb.finishTime == UNDEF_TIME) {
                strncpy(finish_time_str, "UNDEF", FINISH_TIME_STR_LEN);
            } else {
                auto const num_written{snprintf(
                    finish_time_str,
                    FINISH_TIME_STR_LEN,
                    "%.1f",
                    pcb.finishTime
                )};
                check(
                    num_written < static_cast<int>(FINISH_TIME_STR_LEN),
                    "couldn't write \"finishTime\" to buffer"
                );
            }

            size_t constexpr MEM_SIZE_STR_LEN{12};
            char mem_start_str[MEM_SIZE_STR_LEN]{};
            if (pcb.memStart == UNDEF_ADDRESS) {
                strncpy(mem_start_str, "UNDEF", MEM_SIZE_STR_LEN);
            } else {
                auto const num_written{snprintf(
                    mem_start_str,
                    MEM_SIZE_STR_LEN,
                    "%#" PRIx32,
                    pcb.memStart
                )};
                check(
                    num_written < static_cast<int>(MEM_SIZE_STR_LEN),
                    "couldn't write \"finishTime\" to buffer"
                );
            }

            fprintf(
                fout,
                "| %5" PRIu16 " | %-11s | %11.1f | %11.1f | %*s | %*s | %*s | %*s | %#11" PRIx32 " |\n",
                pcb.pid,
                state_name,
                pcb.admissionTime,
                pcb.lifetime,
                static_cast<int>(STORE_TIME_STR_LEN),
                store_time_str,
                static_cast<int>(START_TIME_STR_LEN),
                start_time_str,
                static_cast<int>(FINISH_TIME_STR_LEN),
                finish_time_str,
                static_cast<int>(MEM_SIZE_STR_LEN),
                mem_start_str,
                pcb.memSize
            );
        }

        fputs(
            "+======================================================================================================================+\n",
            fout
        );
    }

} // end of namespace group
