/*
 *  \author Rúben Franco
 */

#include <cstdio>
#include <cstddef>
#include <cstdint>
#include <cinttypes>
#include <cstring>
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "jdt.h"

namespace {
    enum class ParserState {
        SKIPPING,
        READING_JOBS,
    };

    // struct LineRead final {
    //     public:
    //         char* line_ptr{nullptr};

    //         constexpr ~LineRead() noexcept {
    //             free(this->line_ptr);
    //         }

    //         explicit LineRead(std::FILE* const stream) {
    //             errno = 0;
    //             std::size_t len{};
    //             auto const ref{
    //                 getline(&this->line_ptr, &len, stream)
    //             };
    //             if (ref == -1 and errno != 0) {
    //                 throw Exception(errno, __func__);
    //             }
    //             *strchrnul(this->line_ptr, '\n') = '\0';
    //             *strchrnul(this->line_ptr, '#') = '\0';
    //         }

    //         LineRead(LineRead const& other) = delete;
    //         LineRead(LineRead&& other) = delete;
    //         auto operator =(LineRead const& other) -> LineRead& = delete;
    //         auto operator =(LineRead&& other) -> LineRead& = delete;
    // };
}

namespace group
{

// ================================================================================== //

    uint16_t jdtLoad(FILE *fin, uint32_t maxSize)
    {
        soProbe(204, "%s(%p, %#x)\n", __func__, fin, maxSize);

        require(jdtIn != UNDEF_JOB_INDEX and jdtOut != UNDEF_JOB_INDEX, "Module is not in a valid open state!");
        require(jdtCount != UNDEF_JOB_COUNT, "Module is not in a valid open state!");
        require(fin != nullptr and fileno(fin) != -1, "fin must be a valid file stream");

        auto any_error{false};
        uint16_t jobs_read{0};
        double last_submission_time{0.0};

        auto parser_state{ParserState::SKIPPING};
        while (!feof(fin)) {
            errno = 0;
            std::size_t len{};
            char* line{};
            auto const ref{
                getline(&line, &len, fin)
            };
            if (ref == -1 and errno != 0) {
                throw Exception(errno, __func__);
            }
            *strchrnul(line, '\n') = '\0';
            *strchrnul(line, '#') = '\0';

            switch (parser_state) {
                case ParserState::SKIPPING: {
                    int64_t before_space{};
                    int64_t after_space{};
                    int64_t after_jobs{};
                    int64_t char_after_statement{};
                    sscanf(
                        line,
                        " Begin%ln %lnJobs%ln %*c %ln",
                        &before_space,
                        &after_space,
                        &after_jobs,
                        &char_after_statement
                    );

                    // Didn't even parse "Begin"
                    if (before_space == 0 || after_jobs == 0) {
                        free(line);
                        continue;
                    }

                    check(before_space == 0 || after_space != 0, "should consume whitespace");


                    if (after_space - before_space != 1) {
                        fputs(
                            "\"Begin\" is not followed by a single whitespace character\n",
                            stderr
                        );
                        any_error = true;
                        free(line);
                        continue;
                    }


                    if (char_after_statement != 0) {
                        fputs(
                            "\"Begin Jobs\" statement followed by non whitespace characters\n",
                            stderr
                        );
                        any_error = true;
                        free(line);
                        continue;
                    }

                    parser_state = ParserState::READING_JOBS;
                    free(line);
                } break;

                case ParserState::READING_JOBS: {
                    double submission_time{};
                    double lifetime{};
                    uint32_t memsize{};
                    int64_t job_line_length{};
                    int64_t last_char_if_available_pos{};
                    auto const ret{sscanf(
                        line,
                        " %lf ; %lf ; %" SCNx32 "%ln %*c %ln",
                        &submission_time,
                        &lifetime,
                        &memsize,
                        &job_line_length,
                        &last_char_if_available_pos
                    )};

                    if (ret >= 3) {
                        if (submission_time <= 0) {
                            fputs("Provided submission time is not positive\n", stderr);
                            any_error = true;
                            free(line);
                            continue;
                        }

                        if (submission_time < last_submission_time) {
                            fputs("Submission time is not after the last submission time\n", stderr);
                            any_error = true;
                            free(line);
                            continue;
                        }

                        if (lifetime <= 0) {
                            fputs("Provided submission time is not positive\n", stderr);
                            any_error = true;
                            free(line);
                            continue;
                        }

                        if (memsize <= 0) {
                            fputs("Provided memory size is not positive\n", stderr);
                            any_error = true;
                            free(line);
                            continue;
                        }

                        if (memsize > maxSize) {
                            fputs("Provided memory size is too big\n", stderr);
                            any_error = true;
                            free(line);
                            continue;
                        }

                        if (last_char_if_available_pos != 0) {
                            fputs("Job line followed by non whitespace characters\n", stderr);
                            any_error = true;
                            free(line);
                            continue;
                        }

                        if (jdtCount == MAX_JOBS) {
                            throw Exception(ENOMEM, __func__);
                        }

                        jdtTable[jdtIn] = Job{
                            .submissionTime{submission_time},
                            .lifetime{lifetime},
                            .memSize{memsize},
                        };
                        jdtIn += 1;
                        jdtIn %= MAX_JOBS;
                        jdtCount += 1;
                        last_submission_time = submission_time;

                        jobs_read += 1;
                        free(line);
                        continue;
                    }


                    int64_t before_space{};
                    int64_t after_space{};
                    int64_t after_jobs{};
                    int64_t char_after_statement{};
                    sscanf(
                        line,
                        " End%ln %lnJobs%ln %*c %ln",
                        &before_space,
                        &after_space,
                        &after_jobs,
                        &char_after_statement
                    );

                    // Didn't even parse "Begin"
                    if (before_space == 0 || after_jobs == 0) {
                        free(line);
                        continue;
                    }

                    check(before_space == 0 || after_space != 0, "should consume whitespace");


                    if (after_space - before_space != 1) {
                        fputs(
                            "\"End\" is not followed by a single whitespace character\n",
                            stderr
                        );
                        any_error = true;
                        free(line);
                        continue;
                    }


                    if (char_after_statement != 0) {
                        fputs(
                            "\"End Jobs\" statement followed by non whitespace characters\n",
                            stderr
                        );
                        any_error = true;
                        free(line);
                        continue;
                    }

                    parser_state = ParserState::SKIPPING;
                    free(line);
                } break;
            }
        }

        if (parser_state == ParserState::READING_JOBS) {
            fputs("\"Begin Jobs\" statement was not finished by a \"End Jobs\" statement\n", stderr);
            any_error = true;
        }

        if (any_error) {
            throw Exception(EINVAL, __func__);
        }

        return jobs_read;
    }

// ================================================================================== //

} // end of namespace group

