/*
 *  \author Diogo Couto
 *  \author Rúben Franco
 */

#include <cerrno>
#include <cstdint>
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "mem.h"

namespace group 
{

// ================================================================================== //

    MemNode *memRetrieveNodeFromFreeList(uint32_t size, MemoryAllocationPolicy policy)
    {
        soProbe(409, "%s(%#x, %d)\n", __func__, size, policy);

        require(memAllocationPolicy != UndefMemoryAllocationPolicy, "Module is not in a valid open state!");
        require(memFreeList != UNDEF_MEM_NODE and memOccupiedList != UNDEF_MEM_NODE, "Module is not in a valid open state!");
        require(policy == BestFit or policy == WorstFit, "Allocation policy must be 'BestFit' or 'WorstFit'");

        MemNode *candidate = nullptr;
        MemNode *candidatePrev = nullptr;

        // para o best fit, queremos smallest block >= size
        // para o best fit, queremos the largest block >= size
        uint32_t bestSize  = UINT32_MAX;
        uint32_t worstSize = 0;

        MemNode *curr = memFreeList;
        MemNode *prev = nullptr;
        while (curr != nullptr)
        {
            auto const block_size{curr->block.size};
            if (block_size >= size)
            {
                if (policy == BestFit && block_size < bestSize)
                {
                    candidate = curr;
                    candidatePrev = prev;
                    bestSize = block_size;
                }
                else if (block_size > worstSize) // pior caso, o worst fit
                {
                    candidate = curr;
                    candidatePrev = prev;
                    worstSize = block_size;
                }
            }

            prev = curr;
            curr = curr->next;
        }

        if (candidate == nullptr)
        {
            throw Exception(ENOMEM, __func__);
        }

        // ----------------------------------------------------------------------

        auto const block_size{candidate->block.size};
        if (block_size > size)
        {
            auto const leftover{static_cast<MemNode*>(malloc(sizeof (MemNode)))};
            if (leftover == nullptr)
            {
                throw Exception(errno, __func__);
            }
            *leftover = MemNode{
                .block{
                    .start{candidate->block.start + size},
                    .size{block_size - size},
                },
                .next{candidate->next},
            };

            candidate->block.size = size;
            candidate->next = leftover;
        }

        if (candidatePrev == nullptr) {
            memFreeList = candidate->next;
        } else {
            candidatePrev->next = candidate->next;
        }

        candidate->next = nullptr;
        return candidate;
    }


// ================================================================================== //

    MemNode *memRetrieveNodeFromOccupiedList(uint32_t address)
    {
        soProbe(410, "%s(%#x)\n", __func__, address);

        require(memAllocationPolicy != UndefMemoryAllocationPolicy, "Module is not in a valid open state!");
        require(memFreeList != UNDEF_MEM_NODE and memOccupiedList != UNDEF_MEM_NODE, "Module is not in a valid open state!");

        MemNode *curr = memOccupiedList;
        MemNode *prev = nullptr;
        while (curr != nullptr)
        {
            if (curr->block.start == address)
            {
                if (prev == nullptr)
                {
                    
                    memOccupiedList = curr->next;
                }
                else
                {
                    prev->next = curr->next;
                }
                curr->next = nullptr;
                return curr;
            }

            prev = curr;
            curr = curr->next;
        }

        throw Exception(ENOENT, __func__);
    }

// ================================================================================== //
}

// end of namespace group
