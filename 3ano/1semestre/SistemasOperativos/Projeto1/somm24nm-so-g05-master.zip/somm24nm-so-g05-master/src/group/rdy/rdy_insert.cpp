/*
 *  \author Rafael Claro
 */

#include <cstdint>
#include <cerrno>
#include "tam.h"
#include "dbc.h"
#include "probing.h"
#include "rdy.h"

namespace group
{

// ================================================================================== //

    void rdyInsert(uint16_t pid, double lifetime)
    {
        soProbe(504, "%s(%hu, %.1f)\n", __func__, pid, lifetime);

        require(schedulingPolicy == FCFS or schedulingPolicy == SPN, "Module is not in a valid open state!");
        require(rdyList != UNDEF_RDY_NODE and rdyTail != UNDEF_RDY_NODE, "Module is not in a valid open state!");
        require(pid != 0, "A valid process ID must be greater than zero");
        require(lifetime > 0, "A valid process lifetime must be greater than zero");

        RdyNode *newNode = (RdyNode *)malloc(sizeof(RdyNode));
        if (newNode == nullptr) {
            throw Exception(errno, __func__);
        }

        *newNode = RdyNode{
            .process{
                .pid{pid},
                .lifetime{lifetime},
            },
            .next{nullptr},
        };

        if (schedulingPolicy == SchedulingPolicy::FCFS) {
            // Insert at the end of the list
            if (rdyTail == nullptr) {
                rdyList = newNode;
            } else {
                rdyTail->next = newNode;
            }
            rdyTail = newNode;
        } else if (schedulingPolicy == SchedulingPolicy::SPN) {
            // Insert in ascending order of lifetime
            if (rdyList == nullptr || rdyList->process.lifetime > lifetime) {
                // Insert at the head
                newNode->next = rdyList;
                rdyList = newNode;
                if (rdyTail == nullptr) {
                    rdyTail = newNode;
                }
            } else {
                // Find the correct position
                RdyNode *current = rdyList;
                while (current->next != nullptr && current->next->process.lifetime <= lifetime) {
                    current = current->next;
                }
                newNode->next = current->next;
                current->next = newNode;
                if (newNode->next == nullptr) {
                    rdyTail = newNode;
                }
            }
        }
    }

// ================================================================================== //

} // end of namespace group
