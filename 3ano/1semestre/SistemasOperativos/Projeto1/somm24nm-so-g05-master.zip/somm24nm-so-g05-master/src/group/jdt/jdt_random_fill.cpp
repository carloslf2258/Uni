/*
 *  \author Rúben Franco
 */

#include <cstdint>
#include <cstdlib>
#include <cerrno>
#include "dbc.h"
#include "probing.h"
#include "jdt.h"
#include "exception.h"

namespace group
{

// ================================================================================== //

    uint16_t jdtRandomFill(uint32_t seed, uint16_t cnt, uint32_t maxSize)
    {
        soProbe(205, "%s(%u, %u, %#x)\n", __func__, seed, cnt, maxSize);

        require(jdtIn != UNDEF_JOB_INDEX and jdtOut != UNDEF_JOB_INDEX, "Module is not in a valid open state!");
        require(jdtCount != UNDEF_JOB_COUNT, "Module is not in a valid open state!");
        require(cnt == 0 or (cnt >= 2 and cnt <= MAX_JOBS), "Number of jobs is invalid");

        if (
            auto const remaining{MAX_JOBS - jdtCount};
            (cnt == 0 and (remaining) < 2) or cnt > remaining
        ) {
            throw Exception(
                static_cast<int>(ENOMEM),
                __func__
            );
        }

        srand(seed);

        if (cnt == 0) {
            uint16_t max{MAX_JOBS};
            if (
                auto const limit{
                    static_cast<uint16_t>(MAX_JOBS - jdtCount)
                };
                max > limit
            ) {
                max = limit;
            }
            cnt = rand() % (max - 2) + 2;
        }

        uint16_t constexpr LIFETIME_MIN{100};
        uint16_t constexpr LIFETIME_MAX{10000};
        double constexpr LIFETIME_DIVIDEND{10.0};
        uint16_t constexpr MEM_SIZE_MIN{1};
        uint16_t constexpr SUBMISSION_TIME_DELTA_MIN{0};
        uint16_t constexpr SUBMISSION_TIME_DELTA_MAX{1000};
        double constexpr SUBMISSION_TIME_DELTA_DIVIDEND{10.0};

        double submission_time{};
        for (uint16_t i{0}; i < cnt; i += 1) {
            auto const idx{(jdtIn + i) % MAX_JOBS};
            submission_time += static_cast<double>(
                rand()
                    % static_cast<int>(
                        SUBMISSION_TIME_DELTA_MAX
                        - SUBMISSION_TIME_DELTA_MIN
                    ) + static_cast<int>(SUBMISSION_TIME_DELTA_MIN)
            ) / SUBMISSION_TIME_DELTA_DIVIDEND;

            auto const lifetime{static_cast<double>(
                rand()
                    % static_cast<int>(LIFETIME_MAX - LIFETIME_MIN)
                    + static_cast<int>(LIFETIME_MIN)
            ) / LIFETIME_DIVIDEND};

            auto const mem_size{static_cast<uint16_t>(
                rand()
                    % static_cast<int>(maxSize - MEM_SIZE_MIN)
                    + static_cast<int>(MEM_SIZE_MIN)
            )};

            jdtTable[idx] = Job{
                .submissionTime{submission_time},
                .lifetime{lifetime},
                .memSize{mem_size},
            };
        }

        jdtIn += cnt;
        jdtIn %= MAX_JOBS;
        jdtCount += cnt;

        return cnt;
    }

// ================================================================================== //

} // end of namespace group
