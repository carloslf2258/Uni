#!/usr/bin/python3

import hashlib
import os
import sys
import socket
import json
import base64
from common_comm import send_dict, recv_dict, sendrecv_dict

from Crypto.Cipher import AES
from Crypto.Hash import SHA256

def encrypt_intvalue(cipherkey, data):
    # Encrypt an integer value with AES, returning a base64 encoded string
    cipher = AES.new(cipherkey, AES.MODE_ECB)
    data = cipher.encrypt(bytes("%16d" % (data), "utf8"))
    return str(base64.b64encode(data), "utf8")

def decrypt_intvalue(cipherkey, data):
    cipher = AES.new(cipherkey, AES.MODE_ECB)
    data = cipher.decrypt(base64.b64decode(data))
    return int(data.decode("utf8"))


# verify if response from server is valid or is an error message and act accordingly - já está implementada
def validate_response(client_sock, response):
    if not response["status"]:
        print(response["error"])
        client_sock.close()
        sys.exit(3)


def quit_action(client_sock):
    # Send the QUIT operation to the server
    quitRQ = {'op': 'QUIT'}
    quitOP = sendrecv_dict(client_sock, quitRQ)
    validate_response(client_sock, quitOP)
    client_sock.close()
    sys.exit(4)

def stop_action(client_sock, lst, cipher):
    stopRQ = {'op': 'STOP'}
    stopOP = sendrecv_dict(client_sock, stopRQ)
    validate_response(client_sock, stopOP)
    # Print the min, max and sent values
    print("INFO", f"Numbers: {lst}")
    print(f"Minimum: {stopOP['value'] if cipher is None else decrypt_intvalue(cipher,stopOP['value'])}")
    
    
# NUMBER ACTION
def number_action(client_sock, number, lst, cipher=None):
    # Adiciona o número à lista de números enviados
    lst.append(int(number))
    # Envia a operação NUMBER ao servidor com o número escolhido
    if cipher is None:
        numberRQ = {'op': 'NUMBER', 'number': number}
    else:
        numberRQ = {'op': 'NUMBER', 'number': str(base64.b64encode(bytes(number, "utf8")), "utf8")}
    sendrecv_dict(client_sock, numberRQ)
    print("Número enviado: ", number)


# Outcomming message structure:
# { op = "START", client_id, [cipher] }
# { op = "QUIT" }
# { op = "NUMBER", number }
# { op = "STOP", [shasum] }
# { op = "GUESS", choice }
#
# Incomming message structure:
# { op = "START", status }
# { op = "QUIT" , status }
# { op = "NUMBER", status }
# { op = "STOP", status, value }
# { op = "GUESS", status, result }

#
# Suport for executing the client pretended behaviour

    
def start(client_sock, client_id, cipher=None):
    # List with numbers sent to the server
    lst = []
    # Send the START operation to the server
    if cipher is None:
        startRQ = {'op': 'START','client_id': client_id,'cipher': cipher}
    else:
        startRQ = {'op': 'START','client_id': client_id,'cipher': str(base64.b64encode(cipher), "utf8")}
    startOP = sendrecv_dict(client_sock, startRQ)
    validate_response(client_sock, startOP)
    while 1:
        # perguntar se quer fechar o sv ou para
        print("Opções disponiveis: QUIT, STOP")
        option = input(print("Escreve uma opção ou um Nº inteiro: "))
        if option.lower() == "quit" or "q":
            # Send the QUIT operation to the server
            quit_action(client_sock)
            break
        elif option.lower() == "stop" or "s":
            # Send the STOP operation to the server
            stop_action(client_sock, lst, cipher)
            break
        else:
            # Send the NUMBER operation to the server
            number_action(client_sock, option, lst, cipher)

def validate_args(args):
    # numero de args
    if len(args) < 3 or len(args) > 4:
        print("ERRO", f"Usage: python3 {args[0]} client_id port (address)")
        sys.exit(1)
    # tipo de args
    if not(args[2].isdigit()):
        print("ERRO : port must be an integer")
        sys.exit(2)
    # Validate if address is valid
    if len(args) == 4:
        # Tries to connect to the server and verify if it is a valid address or ip
        test_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Set timeout to 5 seconds to try to resolve the address and connect
        test_socket.settimeout(5)
        try:
            test_socket.connect((args[3], int(args[2])))
            test_socket.close()
        except:
            # If the address or port is not valid, print error and exit
            test_socket.close()
            print("Erro: O endereço do servidor deve ser um nome DNS ou endereço IPv4 válido")
            sys.exit(2)


def main():
    # Validate the number of arguments and eventually print error message and exit with error. Verify type of of arguments and eventually print error message and exit with error.
    validate_args(sys.argv)
    # Get the hostname of the server
    machine = sys.argv[3] if len(sys.argv) == 4 else "localhost"
    # Get the port of the server
    port = int(sys.argv[2])
    # Get the client_id
    client_id = sys.argv[1]
    # Set cipher key
    cipherkey = os.urandom(16)
    # Create socket and connect to the server
    try:
        client_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_sock.connect((machine, port))
    except:
        print("ERRO", f"Could not connect to {machine}:{port}")
        sys.exit(1)
    # Ask the user if he wants encryption or not
    if input(print("Do you want to use encryption? [Yes/no] ")).lower() == "yes" or "y":
        # Run the client with encryption
        start(client_sock, client_id, cipherkey)
    else:
        # Run the client without encryption
        start(client_sock, client_id)
    # Close the socket
    client_sock.close()
    sys.exit(0)


if __name__ == "__main__":
    main()
