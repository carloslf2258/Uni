# labiaprof
Integrantes:
Carlos Verenzuela (50%) e Pedro Lopes(50%) (Informação abaixo respetivamente).
Nº Mecanográficos: 114597 e 112937

E-mails: carlos.verenzuela@ua.pt e pedro.e.lopes.a@ua.pt


Turmas pertencentes: 4 e 6.

Repositório no Github:
https://github.com/detiuaveiro/trabalho-de-aprofundamento-labi2023-ap-g19



Código para o trabalho de aprofundamento de labi

