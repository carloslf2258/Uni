var map = new L.Map("myMap", {center: [40.633258,-8.659097],zoom: 15});
var osmUrl="http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
var osmAttrib="Map data OpenStreetMap contributors";
var osm = new L.TileLayer(osmUrl, {attribution: osmAttrib});
map.addLayer(osm);

//Mostra a tua posição a cor azul (por baizo do mapa)
function showCoordinates(e){
var s = document.getElementById("coordinates");
s.innerHTML = "Latitude, Longitude = "+e.latlng.lat+", "+e.latlng.lng;
}

map.on("click", showCoordinates);

//Adicionar pontos ao mapa (array)
var pontos = [
L.marker([40.633258, -8.659097]),
L.marker([40.63135149356332, -8.657559156417848])
];
for(let i in pontos) {
pontos[i].addTo(map);
}

//Para aparecer o nome do DETI no mapa
L.marker([40.633258, -8.659097]).bindPopup("LABI@DETI").addTo(map);

//Para ajustar o zoom inicial de forma a ver tds os pontos
var grupo = new L.featureGroup(pontos);
map.fitBounds(grupo.getBounds());

//ICON UA
var iconeUA = L.icon({ iconUrl: "../images/ua.png" });
L.marker([40.633258, -8.659097], {icon: iconeUA}).bindPopup("LABI@DETI").addTo(map);


//Sinalização da reitoria (retangulo vermelho
var reitoria = L.polygon(
[ [40.63102, -8.65793], [40.63149, -8.65731],
[40.63126, -8.65699], [40.63078, -8.65759] ],
{ color: "red" } );
reitoria.bindPopup("Reitoria").addTo(map);
