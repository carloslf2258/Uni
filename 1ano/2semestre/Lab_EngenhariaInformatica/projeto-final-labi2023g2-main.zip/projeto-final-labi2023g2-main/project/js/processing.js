function processImage() {
    var selectedImage = document.getElementById("image-select").value;
    var selectedAlgorithm = document.getElementById("algorithm-select").value;
  
    // Enviar uma solicitação para o servidor com os parâmetros selectedImage e selectedAlgorithm
    // Usar a resposta do servidor para atualizar a imagem processada
    // Exemplo:
    // $.get("/imageproc", { image: selectedImage, algorithm: selectedAlgorithm }, function(response) {
    //   document.getElementById("processed-image").src = response.path;
    // });
  
    // Temporário: Simular resposta do servidor
    var processedImagePath = "path/to/processed/image.jpg";
    document.getElementById("processed-image").src = processedImagePath;
  }
  