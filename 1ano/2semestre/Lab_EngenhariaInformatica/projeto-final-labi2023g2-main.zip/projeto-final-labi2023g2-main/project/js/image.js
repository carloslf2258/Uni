var id;



$(document).ready(

    function () {

        const params = new URLSearchParams(window.location.search);

        id = params.get("id");

        imagecomments();

    });



function imagecomments() {

    $.get("/comments",

        { idimg: id },

        function (response) {

            showimageandinfo(response);

        });

}



function showimageandinfo(response) {

    // response.image is the image information

    // response.comments is the image list comments

    // response.votes is the image votes



    var image = response.image;

    var comments = response.comments;

    var votes = response.votes;


    const imageInfo = document.createElement("div");
    imageInfo.innerHTML = "Image ID: " + image.id + "<br>" +
        "Name: " + image.name + "<br>" +
        "Author: " + image.author + "<br>" +
        "Datetime: " + image.datetime;

    // Criar elemento HTML para exibir a imagem
    const imageElement = document.createElement("img");
    imageElement.src = image.path;
    imageElement.alt = image.name;
    imageElement.style.width = "550px";  // Definir a largura da imagem como 550px
    imageElement.style.height = "450px"; // Definir a altura da imagem como 450px

    

    
    // Adicionar elementos ao elemento com id "showimages"
    $("#imageinfo").append(imageInfo);
    $("#imageinfo").append(imageElement);
    // Create container for image and image information
    




    // Show comments

    var commentsList = document.createElement("ul");

    for (var i = 0; i < comments.length; i++) {

        var comment = comments[i];

        var commentItem = document.createElement("li");

        commentItem.innerHTML = comment.content + " - " + comment.datetime;

        commentsList.appendChild(commentItem);

    }



    // Show votes

    var votesInfo = document.createElement("div");

    votesInfo.innerHTML = "Thumbs Up: " + votes.ups + "<br>" +

        "Thumbs Down: " + votes.downs;



    // Append elements to the page



    var commentsDiv = document.getElementById("comments");
    commentsDiv.innerHTML = "";
    commentsDiv.appendChild(commentsList);

    //adicionar o elemento votesInfo ao elemento com id "votes"
    $("#thumbs_up").append(votes.ups);
    $("#thumbs_down").append(votes.downs);

}



function newcomment() {

    // obtain the user and comment from image page

    var user = document.getElementById("user").value;

    var comment = document.getElementById("comment").value;



    if (user == "" || comment == "") alert("Missing comment and/or username!");

    else {

        $.post("/newcomment",

            { idimg: id, user: user, comment: comment },

            function () { imagecomments(); });

    }

}



function upvote() {

    $.post("/upvote",

        { idimg: id },

        function (response) {

            // update thumbs_up and thumbs_down
            var votes = response.votes;
            var thumbsUpElement = document.getElementById("thumbs_up");

            thumbsUpElement.innerText = "Thumbs Up: " + votes.ups;



            var thumbsDownElement = document.getElementById("thumbs_down");

            thumbsDownElement.innerText = "Thumbs Down: " + response.votes.downs;



        });

}



function downvote() {

    $.post("/downvote",

        { idimg: id },

        function (response) {

            // update thumbs_up and thumbs_down	

            var thumbsUpElement = document.getElementById("thumbs_up");

            thumbsUpElement.innerText = "Thumbs Up: " + response.votes.ups;



            var thumbsDownElement = document.getElementById("thumbs_down");

            thumbsDownElement.innerText = "Thumbs Down: " + response.votes.downs;

        });

}