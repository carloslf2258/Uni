$(document).ready(
	function () {
		imageslist("all");
	});

function imageslist(id) {
	var author;
	if (id == "all") author = "all";
	else {
		author = $("#authorImg").val();
		if (author == "") author = "all";
	}
	$.get("/list",
		{ id: author },
		function (response) {
			showimages(response);
		});
}

function showimages(response) {
	// response.images is the list of dictionaries with the images information
	$("#showimages").html("");
	for (let i = 0; i < response.images.length; i++) {
		const image = response.images[i];

		// Criar elementos HTML para exibir informações da imagem
		const imageInfo = document.createElement("div");
		imageInfo.innerHTML = "Image ID: " + image.id + ", Image Name: " + image.name;

		// Criar elemento HTML para exibir a imagem
		const imageElement = document.createElement("img");
		imageElement.src = image.path;
		imageElement.alt = image.name;
		imageElement.style.width = "550px";  // Definir a largura da imagem como 550px
		imageElement.style.height = "450px"; // Definir a altura da imagem como 450px

		// Adicionar um evento de clique para invocar a função showimagecomments
		imageElement.addEventListener("click", function () {
			showimagecomments(image.id);
		});

		// Adicionar elementos ao elemento com id "showimages"
		$("#showimages").append(imageInfo);
		$("#showimages").append(imageElement);
	}
}

function showimagecomments(id) {
	window.open("../html/image.html?id=" + id, '_blank');
}
