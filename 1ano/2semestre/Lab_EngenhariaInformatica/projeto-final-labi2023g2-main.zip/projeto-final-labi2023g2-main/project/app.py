# encoding=utf-8
#
# Example of a cherrypy application that serves images.
#
# Adrego da Rocha - Abril de 2023
#
# To run: python3 app.py

import os.path
import cherrypy
import json
import hashlib
import sqlite3 as sql
import time

# The absolute path to this file's base directory
baseDir = os.path.abspath(os.path.dirname(__file__))

# Dictionary with this application's static directories configuration
config = {
			"/":		{"tools.staticdir.root": baseDir},
			"/html":	{"tools.staticdir.on": True, "tools.staticdir.dir": "html"},
			"/js":		{"tools.staticdir.on": True, "tools.staticdir.dir": "js"},
			"/css":		{"tools.staticdir.on": True, "tools.staticdir.dir": "css"},
			"/images":	{"tools.staticdir.on": True, "tools.staticdir.dir": "images"},
			"/uploads":	{"tools.staticdir.on": True, "tools.staticdir.dir": "uploads"},
}


class Root(object):
	@cherrypy.expose
	def index(self):
		return open("html/index.html")

	# UpLoad image
	@cherrypy.expose
	def upload(self, myFile, nameImg, authorImg):
		h = hashlib.sha256()

		filename = baseDir + "/uploads/" + myFile.filename
		fileout = open(filename, "wb")
		while True:
			data = myFile.file.read(8192)
			if not data: break
			fileout.write(data)
			h.update(data)
		fileout.close()

		ext = myFile.filename.split(".")[-1]
		# final path of the image and changing the filename
		path = "uploads/" + h.hexdigest() + "." + ext
		os.rename(filename, path)

		# nameImg and authorImg are input parameters of this method
		# obtain the date and time of loading
		datetime = time.strftime('date:%d-%m-%Y time:%H:%M:%S')

		# insert the file information in the images table
		# eventually initialize the votes tables
		print(nameImg)
		db = sql.connect('database.db')
		query = "INSERT INTO images (name, author, path, datetime) VALUES (?, ?, ?, ?)"
		db.execute(query, (nameImg, authorImg, path, datetime))
		# db.execute(query of type INSERT (nameImg, authorImg, path, datetime))
		db.commit()
		db.close()

	# List requested images
	@cherrypy.expose
	def list(self, id):
		db = sql.connect('database.db')
		if (id == "all"):
			# result = db.execute(query of type SELECT for all images)
			result = db.execute("SELECT * FROM images")
		else:
			# result = db.execute(query of type SELECT for all images of the author id)
			result = db.execute("SELECT * FROM images WHERE author=?", (id,))
		rows = result.fetchall()
		db.close()

		# Generate result (list of dictionaries) from rows (list of tuples)
		result = []
		for row in rows:
			image = {
                "id": row[0],
                "name": row[1],
                "author": row[2],
                "path": "../"+row[3],
                "datetime": row[4]
            }
			result.append(image)

		# eventually sort result by image name before return
		result.sort(key=lambda x: x["name"])

		cherrypy.response.headers["Content-Type"] = "application/json"
		return json.dumps({"images": result}).encode("utf-8")

	# List comments
	@cherrypy.expose
	def comments(self, idimg):
		db = sql.connect('database.db')

		image_result = db.execute("SELECT * FROM images WHERE id=?", (idimg,))
		rows_image = image_result.fetchall()
		row_image = rows_image[0]

		imageinfo = {
            "id": row_image[0],
            "name": row_image[1],
            "author": row_image[2],
            "path": "../"+row_image[3],
            "datetime": row_image[4]
        }

		# result = db.execute(query of type SELECT for all comments of the id idimg)
		result = db.execute("SELECT * FROM comments WHERE idimg=?", (idimg,))
		rows = result.fetchall()

		# Generate output dictionary with image comments list
		comments = []
		for row in rows:
			comment = {
                "idimg": row[1],
                "user": row[2],
                "content": row[3],
                "datetime": row[4]
            }
			comments.append(comment)

		result_votes = db.execute("SELECT * FROM votes WHERE idimg=?", (idimg,))
		rows_votes = result_votes.fetchall()
		row_vote= rows_votes[0]

		# Generate output dictionary with image votes
		imagevotes = dict()
		imagevotes["ups"] = row_vote[2]
		imagevotes["downs"] = row_vote[3]

		db.close()

		cherrypy.response.headers["Content-Type"] = "application/json"
		return json.dumps({"image": imageinfo, "comments": comments, "votes": imagevotes}).encode("utf-8")

	# UpLoad comment
	@cherrypy.expose
	def newcomment(self, idimg, user, comment):
			# obtain the date and time of the comment
			datetime = time.strftime('date:%d-%m-%Y time:%H:%M:%S')

			db = sql.connect('database.db')
			query = "INSERT INTO comments (idimg, user, comment, datetime) VALUES (?, ?, ?, ?)"
			db.execute(query, (idimg, user, comment, datetime))
			# db.execute(query of type INSERT (idimg, user, content, datetime))
			db.commit()
			db.close()

    # Increment Up votes
	@cherrypy.expose
	def upvote(self, idimg):
			db = sql.connect('database.db')
			db.execute("UPDATE votes SET ups = ups + 1 WHERE idimg = ?", (idimg,))
			# db.execute(query of type UPDATE thumbs_up + 1 WHERE id = idimg)
			db.commit()
   
			result_votes = db.execute("SELECT * FROM votes WHERE idimg=?", (idimg,))
			rows_votes = result_votes.fetchall()
			row_vote= rows_votes[0]

			# Generate output dictionary with image votes
			imagevotes = dict()
			imagevotes["ups"] = row_vote[2]
			imagevotes["downs"] = row_vote[3]
			db.close()
			cherrypy.response.headers["Content-Type"] = "application/json"
			return json.dumps({ "votes": imagevotes}).encode("utf-8")

    # Increment Down votes
	@cherrypy.expose
	def downvote(self, idimg):
			db = sql.connect('database.db')
			db.execute("UPDATE votes SET downs = downs + 1 WHERE idimg = ?", (idimg,))
			# db.execute(query of type UPDATE thumbs_down + 1 WHERE id = idimg)
			db.commit()
			result_votes = db.execute("SELECT * FROM votes WHERE idimg=?", (idimg,))
			rows_votes = result_votes.fetchall()
			row_vote= rows_votes[0]

			# Generate output dictionary with image votes
			imagevotes = dict()
			imagevotes["ups"] = row_vote[2]
			imagevotes["downs"] = row_vote[3]
			db.close()
			cherrypy.response.headers["Content-Type"] = "application/json"
			return json.dumps({ "votes": imagevotes}).encode("utf-8")

cherrypy.quickstart(Root(), "/", config)
