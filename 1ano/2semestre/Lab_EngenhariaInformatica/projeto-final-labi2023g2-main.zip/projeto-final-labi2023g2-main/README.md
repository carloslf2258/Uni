# labiproj
Repositório template para o projeto final de labi
O diretório report serve para armazenar os ficheiros do relatório latex
O diretório project serve para armazenar os ficheiros do servidor WEB

Autores (informações em ordem respetivamente)
-Nomes: Carlos Verenzuela, Rafael Claro, Pedro Almeida, Pedro Cunha

-Nº Mec: 114597, 88860, 112937, 112960

-E-mails: carlos.verenzuela@ua.pt, Rafael.mclaro@ua.pt, pedro.e.lopes.a@ua.pt, pedromscunha04@ua.pt

-Contribuições dos autores (por ordem):
35%, 35%, 20%, 15%

-Repositório no Github:
https://github.com/detiuaveiro/projeto-final-labi2023g2/tree/main
