//
// Algoritmos e Estruturas de Dados --- 2023/2024
//
// Joaquim Madeira, Joao Manuel Rodrigues - June 2021, Nov 2023
//
// Graph - Using a list of adjacency lists representation
//

#include "SortedList.h"
#include "Graph.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include "instrumentation.h"

struct _Vertex {
  unsigned int id;
  unsigned int inDegree;
  unsigned int outDegree;
  List* edgesList;
};

struct _Edge {
  unsigned int adjVertex;
  double weight;
};

struct _GraphHeader {
  int isDigraph;
  int isComplete;
  int isWeighted;
  unsigned int numVertices;
  unsigned int numEdges;
  List* verticesList;
};

// The comparator for the VERTICES LIST

int graphVerticesComparator(const void* p1, const void* p2) {
  unsigned int v1 = ((struct _Vertex*)p1)->id;
  unsigned int v2 = ((struct _Vertex*)p2)->id;
  int d = v1 - v2;
  return (d > 0) - (d < 0);
}

// The comparator for the EDGES LISTS

int graphEdgesComparator(const void* p1, const void* p2) {
  unsigned int v1 = ((struct _Edge*)p1)->adjVertex;
  unsigned int v2 = ((struct _Edge*)p2)->adjVertex;
  int d = v1 - v2;
  return (d > 0) - (d < 0);
}

Graph* GraphCreate(unsigned int numVertices, int isDigraph, int isWeighted) {
  Graph* g = (Graph*)malloc(sizeof(struct _GraphHeader));
  if (g == NULL) abort();

  g->isDigraph = isDigraph;
  g->isComplete = 0;
  g->isWeighted = isWeighted;

  g->numVertices = numVertices;
  g->numEdges = 0;

  g->verticesList = ListCreate(graphVerticesComparator);

  for (unsigned int i = 0; i < numVertices; i++) {
    struct _Vertex* v = (struct _Vertex*)malloc(sizeof(struct _Vertex));
    if (v == NULL) abort();

    v->id = i;
    v->inDegree = 0;
    v->outDegree = 0;

    v->edgesList = ListCreate(graphEdgesComparator);

    ListInsert(g->verticesList, v);
  }

  assert(g->numVertices == ListGetSize(g->verticesList));

  return g;
}

Graph* GraphCreateComplete(unsigned int numVertices, int isDigraph) {
  Graph* g = GraphCreate(numVertices, isDigraph, 0);

  g->isComplete = 1;

  List* vertices = g->verticesList;
  ListMoveToHead(vertices);
  unsigned int i = 0;
  for (; i < g->numVertices; ListMoveToNext(vertices), i++) {
    struct _Vertex* v = ListGetCurrentItem(vertices);
    List* edges = v->edgesList;
    for (unsigned int j = 0; j < g->numVertices; j++) {
      if (i == j) {
        continue;
      }
      struct _Edge* new = (struct _Edge*)malloc(sizeof(struct _Edge));
      if (new == NULL) abort();
      new->adjVertex = j;
      new->weight = 1;

      ListInsert(edges, new);
    }
    if (g->isDigraph) {
      v->inDegree = g->numVertices - 1;
      v->outDegree = g->numVertices - 1;
    } else {
      v->outDegree = g->numVertices - 1;
    }
  }
  if (g->isDigraph) {
    g->numEdges = numVertices * (numVertices - 1);
  } else {
    g->numEdges = numVertices * (numVertices - 1) / 2;
  }

  return g;
}

void GraphDestroy(Graph** p) {
  assert(*p != NULL);
  Graph* g = *p;

  List* vertices = g->verticesList;
  if (ListIsEmpty(vertices) == 0) {
    ListMoveToHead(vertices);
    unsigned int i = 0;
    for (; i < g->numVertices; ListMoveToNext(vertices), i++) {
      struct _Vertex* v = ListGetCurrentItem(vertices);

      List* edges = v->edgesList;
      if (ListIsEmpty(edges) == 0) {
        ListMoveToHead(edges);
        while (ListMoveToNext(edges) == 0) {
          // Libere a memória diretamente sem armazenar em uma variável
          free(ListRemoveCurrent(edges));
        }
      }
      ListDestroy(&(v->edgesList));
      free(v);
    }
  }

  ListDestroy(&(g->verticesList));
  free(g);

  *p = NULL;
}

//ESBOÇO DE FUNÇÃO GraphCopy

Graph* GraphCopy(const Graph* g) {
  assert(g != NULL);

  // Criar um novo grafo usando GraphCreate com as propriedades do grafo original
  Graph* copy = GraphCreate(g->numVertices, g->isDigraph, g->isWeighted);

  // Iterar sobre os vértices do grafo original
  List* vertices = g->verticesList;
  ListMoveToHead(vertices);
  while (!ListIsAtEnd(vertices)) {
    struct _Vertex* originalVertex = ListGetCurrentItem(vertices);

    // Criar um novo vértice para a cópia
    struct _Vertex* copyVertex = (struct _Vertex*)malloc(sizeof(struct _Vertex));
    if (copyVertex == NULL) {
      fprintf(stderr, "Erro ao alocar memória para cópia do vértice.\n");
      GraphDestroy(&copy); // Liberar memória em caso de erro
      return NULL;
    }

    // Copiar os dados do vértice original para o novo vértice
    *copyVertex = *originalVertex;

    // Inicializar a lista de adjacências do vértice na cópia
    copyVertex->edgesList = ListCreate(graphEdgesComparator);

    // Adicionar o novo vértice à lista de vértices da cópia
    ListInsert(copy->verticesList, copyVertex);

    // Iterar sobre as arestas do vértice original
    List* edgesList = originalVertex->edgesList;
    ListMoveToHead(edgesList);
    while (!ListIsAtEnd(edgesList)) {
      struct _Edge* originalEdge = ListGetCurrentItem(edgesList);

      // Criar uma nova aresta para a cópia
      struct _Edge* copyEdge = (struct _Edge*)malloc(sizeof(struct _Edge));
      if (copyEdge == NULL) {
        fprintf(stderr, "Erro ao alocar memória para cópia da aresta.\n");
        GraphDestroy(&copy); // Liberar memória em caso de erro
        return NULL;
      }

      // Copiar os dados da aresta original para a nova aresta
      *copyEdge = *originalEdge;

      // Adicionar a nova aresta à lista de adjacências do vértice na cópia
      ListInsert(copyVertex->edgesList, copyEdge);

      ListMoveToNext(edgesList);
    }

    ListMoveToNext(vertices);
  }

  // Atualizar o número de arestas na cópia
  copy->numEdges = g->numEdges;

  // Retornar o grafo criado a partir do original
  return copy;
}


//ESBOÇO DE FUNÇÃO GraphFromFile

Graph* GraphFromFile(FILE* f) {
  assert(f != NULL);

  // Variáveis para armazenar dados temporários lidos do arquivo
  unsigned int v, w;
  //double weight;

  // Ler o número de vértices do arquivo
  if (fscanf(f, "%u", &v) != 1) {
    fprintf(stderr, "Erro ao ler o número de vértices do arquivo.\n");
    return NULL;
  }

  // Criar um grafo usando GraphCreate com o número de vértices
  Graph* graph = GraphCreate(v, /* isDigraph = */ 0, /* isWeighted = */ 0);

  // Iterar sobre as linhas do arquivo para ler as arestas e propriedades
  while (fscanf(f, "%u %u", &v, &w) == 2) {
    // Adicionar a aresta ao grafo usando GraphAddEdge
    if (!GraphAddEdge(graph, v, w)) {
      fprintf(stderr, "Erro ao adicionar aresta ao grafo.\n");
      GraphDestroy(&graph); // Liberar memória em caso de erro
      return NULL;
    }
  }

  // Retornar o grafo criado a partir do arquivo
  return graph;
}



// Graph

int GraphIsDigraph(const Graph* g) { return g->isDigraph; }

int GraphIsComplete(const Graph* g) { return g->isComplete; }

int GraphIsWeighted(const Graph* g) { return g->isWeighted; }

unsigned int GraphGetNumVertices(const Graph* g) { return g->numVertices; }

unsigned int GraphGetNumEdges(const Graph* g) { return g->numEdges; }

//
// For a graph
//
double GraphGetAverageDegree(const Graph* g) {
  assert(g->isDigraph == 0);
  return 2.0 * (double)g->numEdges / (double)g->numVertices;
}

static unsigned int _GetMaxDegree(const Graph* g) {
  List* vertices = g->verticesList;
  if (ListIsEmpty(vertices)) return 0;

  unsigned int maxDegree = 0;
  ListMoveToHead(vertices);
  unsigned int i = 0;
  for (; i < g->numVertices; ListMoveToNext(vertices), i++) {
    struct _Vertex* v = ListGetCurrentItem(vertices);
    if (v->outDegree > maxDegree) {
      maxDegree = v->outDegree;
    }
  }
  return maxDegree;
}

//
// For a graph
//
unsigned int GraphGetMaxDegree(const Graph* g) {
  assert(g->isDigraph == 0);
  return _GetMaxDegree(g);
}

//
// For a digraph
//
unsigned int GraphGetMaxOutDegree(const Graph* g) {
  assert(g->isDigraph == 1);
  return _GetMaxDegree(g);
}

// Vertices

//
// returns an array of size (outDegree + 1)
// element 0, stores the number of adjacent vertices
// and is followed by indices of the adjacent vertices
//
unsigned int* GraphGetAdjacentsTo(const Graph* g, unsigned int v) {
  assert(v < g->numVertices);

  // Node in the list of vertices
  List* vertices = g->verticesList;
  ListMove(vertices, v);
  struct _Vertex* vPointer = ListGetCurrentItem(vertices);
  unsigned int numAdjVertices = vPointer->outDegree;

  unsigned int* adjacent =
      (unsigned int*)calloc(1 + numAdjVertices, sizeof(unsigned int));

  if (numAdjVertices > 0) {
    adjacent[0] = numAdjVertices;
    List* adjList = vPointer->edgesList;
    ListMoveToHead(adjList);
    for (unsigned int i = 0; i < numAdjVertices; ListMoveToNext(adjList), i++) {
      struct _Edge* ePointer = ListGetCurrentItem(adjList);
      adjacent[i + 1] = ePointer->adjVertex;
    }
  }

  return adjacent;
}

//
// returns an array of size (outDegree + 1)
// element 0, stores the number of adjacent vertices
// and is followed by the distances to the adjacent vertices
//
double* GraphGetDistancesToAdjacents(const Graph* g, unsigned int v) {
  assert(v < g->numVertices);

  // Node in the list of vertices
  List* vertices = g->verticesList;
  ListMove(vertices, v);
  struct _Vertex* vPointer = ListGetCurrentItem(vertices);
  unsigned int numAdjVertices = vPointer->outDegree;

  double* distance = (double*)calloc(1 + numAdjVertices, sizeof(double));
  //teste//
  if (numAdjVertices > 0) {
    distance[0] = numAdjVertices;
    List* adjList = vPointer->edgesList;
    ListMoveToHead(adjList);
    for (unsigned int i = 0; i < numAdjVertices; ListMoveToNext(adjList), i++) {
      struct _Edge* ePointer = ListGetCurrentItem(adjList);
      distance[i + 1] = ePointer->weight;
    }
  }

  return distance;
}

//
// For a graph
//
unsigned int GraphGetVertexDegree(Graph* g, unsigned int v) {
  assert(g->isDigraph == 0);
  assert(v < g->numVertices);

  ListMove(g->verticesList, v);
  struct _Vertex* p = ListGetCurrentItem(g->verticesList);

  return p->outDegree;
}

//
// done
//
// For a digraph
//
unsigned int GraphGetVertexOutDegree(Graph* g, unsigned int v) {
  assert(g->isDigraph == 1);
  assert(v < g->numVertices);

  ListMove(g->verticesList, v);
  struct _Vertex* p = ListGetCurrentItem(g->verticesList);

  return p->outDegree;
}

//
// For a digraph
//
unsigned int GraphGetVertexInDegree(Graph* g, unsigned int v) {
  assert(g->isDigraph == 1);
  assert(v < g->numVertices);

  ListMove(g->verticesList, v);
  struct _Vertex* p = ListGetCurrentItem(g->verticesList);

  return p->inDegree;
}

// Edges

static int _addEdge(Graph* g, unsigned int v, unsigned int w, double weight) {
  struct _Edge* edge = (struct _Edge*)malloc(sizeof(struct _Edge));
  edge->adjVertex = w;
  edge->weight = weight;

  ListMove(g->verticesList, v);
  struct _Vertex* vertex = ListGetCurrentItem(g->verticesList);
  int result = ListInsert(vertex->edgesList, edge);

  if (result == -1) {
    return 0;
  } else {
    g->numEdges++;
    vertex->outDegree++;

    ListMove(g->verticesList, w);
    struct _Vertex* destVertex = ListGetCurrentItem(g->verticesList);
    destVertex->inDegree++;
  }

  if (g->isDigraph == 0) {
    // Bidirectional edge
    struct _Edge* edge = (struct _Edge*)malloc(sizeof(struct _Edge));
    edge->adjVertex = v;
    edge->weight = weight;

    ListMove(g->verticesList, w);
    struct _Vertex* vertex = ListGetCurrentItem(g->verticesList);
    result = ListInsert(vertex->edgesList, edge);

    if (result == -1) {
      return 0;
    } else {
      // g->numEdges++; // Do not count the same edge twice on a undirected
      // graph !!
      vertex->outDegree++;
    }
  }

  return 1;
}



int GraphAddEdge(Graph* g, unsigned int v, unsigned int w) {
  assert(g->isWeighted == 0);
  assert(v != w);
  assert(v < g->numVertices);
  assert(w < g->numVertices);

  return _addEdge(g, v, w, 1.0);
}

int GraphAddWeightedEdge(Graph* g, unsigned int v, unsigned int w,
                         double weight) {
  assert(g->isWeighted == 1);
  assert(v != w);
  assert(v < g->numVertices);
  assert(w < g->numVertices);

  return _addEdge(g, v, w, weight);
}


//ESBOÇO DA FUNÇÃO GraphRemoveEdge
int GraphRemoveEdge(Graph* g, unsigned int v, unsigned int w) {
  assert(g != NULL);

  // Encontrar o vértice v na lista de vértices
  ListMove(g->verticesList, v);
  struct _Vertex* vertexV = ListGetCurrentItem(g->verticesList);

  // Iterar sobre as arestas do vértice v para encontrar a aresta com destino em w
  List* edgesListV = vertexV->edgesList;
  ListMoveToHead(edgesListV);
  while (!ListIsAtEnd(edgesListV)) {
    struct _Edge* edge = ListGetCurrentItem(edgesListV);
    if (edge->adjVertex == w) {
      // Remover a aresta da lista de adjacências do vértice v
      ListRemoveCurrent(edgesListV);
      free(edge);

      // Atualizar as contagens de grau
      vertexV->outDegree--;
      if (!g->isDigraph) {
        // Se o grafo for não direcionado, também atualizar o vértice w
        ListMove(g->verticesList, w);
        struct _Vertex* vertexW = ListGetCurrentItem(g->verticesList);
        vertexW->outDegree--;
      }

      // Atualizar o número de arestas
      g->numEdges--;

      return 1; // Aresta removida com sucesso
    }

    ListMoveToNext(edgesListV);
  }

  return 0; // Aresta não encontrada
}


// CHECKING

//ESBOÇO DA FUNÇÃO GraphCheckInvariants
int GraphCheckInvariants(const Graph* g) {
  assert(g != NULL);

  // Verificar invariáveis gerais do grafo
  if (g->numVertices != ListGetSize(g->verticesList)) {
    printf("Número de vértices incorreto!\n");
    return 0;
  }

  // Iterar sobre os vértices e verificar invariáveis individuais
  List* vertices = g->verticesList;
  ListMoveToHead(vertices);
  unsigned int i = 0;
  for (; i < g->numVertices; ListMoveToNext(vertices), i++) {
    struct _Vertex* v = ListGetCurrentItem(vertices);

    // Verificar invariáveis para o vértice v
    if (v->inDegree + v->outDegree != ListGetSize(v->edgesList)) {
      printf("Inconsistência nos graus do vértice %d!\n", v->id);
      return 0;
    }

    // Iterar sobre as arestas e verificar invariáveis individuais
    List* edges = v->edgesList;
    ListMoveToHead(edges);
    unsigned int j = 0;
    for (; j < ListGetSize(edges); ListMoveToNext(edges), j++) {
      struct _Edge* e = ListGetCurrentItem(edges);
      // Invariáveis para a aresta e
    // 1. Existência de Vértices Conectados
      if (e->adjVertex >= g->numVertices) {
        printf("Identificador de vértice inválido para a aresta na posição %d do vértice %d!\n", j, v->id);
        return 0;
      }
    }
  }
  // Verificar se o número de arestas é consistente com os graus dos vértices
  unsigned int totalEdges = 0;
  ListMoveToHead(vertices);
  for (i = 0; i < g->numVertices; ListMoveToNext(vertices), i++) {
    struct _Vertex* v = ListGetCurrentItem(vertices);
    totalEdges += ListGetSize(v->edgesList);
  }

  if (totalEdges / 2 != g->numEdges) {
    printf("Número de arestas incorreto!\n");
    return 0;
  }

  // Se todas as verificações passaram, retornar 1 (invariáveis mantidas)
  return 1;
}


// DISPLAYING on the console

void GraphDisplay(const Graph* g) {
  printf("---\n");
  if (g->isWeighted) {
    printf("Weighted ");
  }
  if (g->isComplete) {
    printf("COMPLETE ");
  }
  if (g->isDigraph) {
    printf("Digraph\n");
    printf("Max Out-Degree = %d\n", GraphGetMaxOutDegree(g));
  } else {
    printf("Graph\n");
    printf("Max Degree = %d\n", GraphGetMaxDegree(g));
  }
  printf("Vertices = %2d | Edges = %2d\n", g->numVertices, g->numEdges);

  List* vertices = g->verticesList;
  ListMoveToHead(vertices);
  unsigned int i = 0;
  for (; i < g->numVertices; ListMoveToNext(vertices), i++) {
    printf("%2d ->", i);
    struct _Vertex* v = ListGetCurrentItem(vertices);
    if (ListIsEmpty(v->edgesList)) {
      printf("\n");
    } else {
      List* edges = v->edgesList;
      unsigned int i = 0;
      ListMoveToHead(edges);
      for (; i < ListGetSize(edges); ListMoveToNext(edges), i++) {
        struct _Edge* e = ListGetCurrentItem(edges);
        if (g->isWeighted) {
          printf("   %2d(%4.2f)", e->adjVertex, e->weight);
        } else {
          printf("   %2d", e->adjVertex);
        }
      }
      printf("\n");
    }
  }
  printf("---\n");
}

void GraphListAdjacents(const Graph* g, unsigned int v) {
  printf("---\n");

  unsigned int* array = GraphGetAdjacentsTo(g, v);

  printf("Vertex %d has %d adjacent vertices -> ", v, array[0]);

  for (unsigned int i = 1; i <= array[0]; i++) {
    printf("%d ", array[i]);
  }

  printf("\n");

  free(array);

  printf("---\n");
}
